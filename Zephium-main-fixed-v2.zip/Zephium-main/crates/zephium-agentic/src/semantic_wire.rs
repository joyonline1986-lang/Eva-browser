//! Hostile decoder for the fixed semantic-runtime wire schema.
//!
//! The page/runtime payload is untrusted even though it arrives through an
//! isolated world. The native adapter supplies context, frame, origin,
//! invocation, and expected snapshot generation out of band; page bytes can
//! only describe bounded allowlisted node semantics.

use std::collections::BTreeSet;
use std::fmt;

use serde::Deserialize;
use thiserror::Error;

use crate::semantic::{SemanticNodeInput, SemanticNodeKey};
use crate::{
    SemanticCompleteness, SemanticFrameJoin, SemanticHeadingLevel, SemanticInvocationId,
    SemanticOperationClass, SemanticOperations, SemanticRect, SemanticRole, SemanticSensitivity,
    SemanticSnapshot, SemanticSnapshotGeneration, SemanticState, SemanticStates, SemanticText,
    SemanticTruncation, SemanticTrust, SemanticValueSummary, MAX_SEMANTIC_DEPTH,
    MAX_SEMANTIC_NAME_BYTES, MAX_SEMANTIC_NODES, MAX_SEMANTIC_TEXT_BYTES,
    MAX_SEMANTIC_TOTAL_TEXT_BYTES, MAX_SEMANTIC_VALUE_BYTES,
};

/// Exact production semantic wire schema version.
pub const SEMANTIC_WIRE_VERSION: u16 = 1;
/// Maximum encoded bytes accepted from one frame/runtime invocation.
pub const MAX_SEMANTIC_WIRE_BYTES: usize = 256 * 1024;

const CREDENTIAL_LABELS: &[&str] = &[
    "password",
    "passcode",
    "one-time code",
    "verification code",
    "security code",
    "api key",
    "access token",
    "secret key",
    "private key",
    "credit card",
    "card number",
    "cvv",
    "cvc",
];

/// Trusted out-of-band authority for one hostile frame payload.
#[derive(Clone, Eq, PartialEq)]
pub struct SemanticDecodeContext {
    invocation: SemanticInvocationId,
    frame: SemanticFrameJoin,
    generation: SemanticSnapshotGeneration,
}

impl SemanticDecodeContext {
    /// Binds expected native invocation, frame authority, and snapshot generation.
    pub const fn new(
        invocation: SemanticInvocationId,
        frame: SemanticFrameJoin,
        generation: SemanticSnapshotGeneration,
    ) -> Self {
        Self {
            invocation,
            frame,
            generation,
        }
    }

    /// Exact expected native invocation.
    pub const fn invocation(&self) -> SemanticInvocationId {
        self.invocation
    }

    /// Exact native-attested frame authority.
    pub const fn frame(&self) -> &SemanticFrameJoin {
        &self.frame
    }

    /// Exact expected snapshot generation.
    pub const fn generation(&self) -> SemanticSnapshotGeneration {
        self.generation
    }
}

impl fmt::Debug for SemanticDecodeContext {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("SemanticDecodeContext")
            .field("invocation", &self.invocation)
            .field("frame", &self.frame)
            .field("generation", &self.generation)
            .finish()
    }
}

/// Closed refusal from the hostile semantic wire decoder.
#[derive(Clone, Copy, Debug, Eq, Error, PartialEq)]
pub enum SemanticDecodeError {
    /// Encoded input exceeded the fixed byte ceiling.
    #[error("semantic wire byte ceiling exceeded")]
    WireLimit,
    /// JSON shape, field type, enum, or unknown/duplicate field was invalid.
    #[error("semantic wire payload is malformed")]
    Malformed,
    /// Payload version does not exactly match the fixed runtime.
    #[error("semantic wire version mismatch")]
    VersionMismatch,
    /// Payload invocation does not match native authority.
    #[error("semantic invocation mismatch")]
    InvocationMismatch,
    /// Payload snapshot generation does not match native authority.
    #[error("semantic snapshot generation mismatch")]
    GenerationMismatch,
    /// Node cohort exceeded the fixed ceiling.
    #[error("semantic node ceiling exceeded")]
    NodeLimit,
    /// Internal node key was zero or duplicated.
    #[error("semantic node identity is invalid")]
    NodeIdentity,
    /// Parent index was forward, self-referential, or otherwise invalid.
    #[error("semantic node parent is invalid")]
    Parent,
    /// Derived tree depth exceeded the fixed ceiling.
    #[error("semantic tree depth ceiling exceeded")]
    DepthLimit,
    /// Page-derived text exceeded a field or total ceiling.
    #[error("semantic text ceiling exceeded")]
    TextLimit,
    /// Role, value summary, states, and operation inventory disagree.
    #[error("semantic node contract is incompatible")]
    NodeContract,
    /// Bounded semantic domain contract refused the decoded value.
    #[error("semantic domain contract refused decoded value")]
    Contract,
}

/// Decodes one complete bounded frame snapshot from hostile fixed-runtime bytes.
pub fn decode_semantic_snapshot(
    context: SemanticDecodeContext,
    bytes: &[u8],
) -> Result<SemanticSnapshot, SemanticDecodeError> {
    if bytes.len() > MAX_SEMANTIC_WIRE_BYTES {
        return Err(SemanticDecodeError::WireLimit);
    }
    let raw: RawSnapshot =
        serde_json::from_slice(bytes).map_err(|_| SemanticDecodeError::Malformed)?;
    if raw.version != SEMANTIC_WIRE_VERSION {
        return Err(SemanticDecodeError::VersionMismatch);
    }
    if raw.invocation != context.invocation.get() {
        return Err(SemanticDecodeError::InvocationMismatch);
    }
    if raw.generation != context.generation.get() {
        return Err(SemanticDecodeError::GenerationMismatch);
    }
    if raw.nodes.len() > MAX_SEMANTIC_NODES {
        return Err(SemanticDecodeError::NodeLimit);
    }

    let approval_nonce = match raw.approval_nonce.as_deref() {
        Some(value) => Some(
            crate::semantic_approval::SemanticApprovalIdentity::nonce(value)
                .ok_or(SemanticDecodeError::NodeIdentity)?,
        ),
        None => None,
    };
    let mut approval_keys = BTreeSet::new();
    let mut keys = BTreeSet::new();
    let mut depths = Vec::<u8>::with_capacity(raw.nodes.len());
    let mut nodes = Vec::with_capacity(raw.nodes.len());
    let mut wire_text_bytes = 0_usize;
    let mut retained_text_bytes = 0_usize;
    for (index, raw_node) in raw.nodes.into_iter().enumerate() {
        let key = SemanticNodeKey::new(raw_node.key).ok_or(SemanticDecodeError::NodeIdentity)?;
        if !keys.insert(raw_node.key) {
            return Err(SemanticDecodeError::NodeIdentity);
        }
        let parent = match raw_node.parent {
            Some(parent) => {
                let parent_index = usize::from(parent);
                if parent_index >= index {
                    return Err(SemanticDecodeError::Parent);
                }
                Some(parent)
            }
            None => None,
        };
        let depth = match parent {
            Some(parent) => depths[usize::from(parent)]
                .checked_add(1)
                .ok_or(SemanticDecodeError::DepthLimit)?,
            None => 0,
        };
        if usize::from(depth) > MAX_SEMANTIC_DEPTH {
            return Err(SemanticDecodeError::DepthLimit);
        }
        depths.push(depth);

        let role = raw_node.role.into();
        let heading_level = match (role, raw_node.heading_level) {
            (SemanticRole::Heading, Some(level)) => {
                Some(SemanticHeadingLevel::new(level).ok_or(SemanticDecodeError::NodeContract)?)
            }
            (SemanticRole::Heading, None) | (_, Some(_)) => {
                return Err(SemanticDecodeError::NodeContract);
            }
            (_, None) => None,
        };
        let landmark_kind = match (role, raw_node.landmark_kind) {
            (SemanticRole::Landmark, kind) => kind,
            (_, None) => None,
            _ => return Err(SemanticDecodeError::NodeContract),
        };
        let states = SemanticStates::from_bits(raw_node.states)
            .map_err(|_| SemanticDecodeError::NodeContract)?;
        let operations = SemanticOperations::from_bits(raw_node.operations)
            .map_err(|_| SemanticDecodeError::NodeContract)?;
        validate_operations(role, states, operations)?;
        if role == SemanticRole::Button
            && operations.contains(SemanticOperationClass::Scroll)
            && raw_node.activation != Some(6)
        {
            return Err(SemanticDecodeError::NodeContract);
        }
        let fill_support = raw_node.fill_support.map(decode_fill_support).transpose()?;
        let editable_structure = raw_node
            .editable_structure
            .map(|(child_count, child_kinds, editable_parent)| {
                if child_count > 129
                    || child_kinds > 7
                    || (child_count == 0) != (child_kinds == 0)
                    || child_kinds.count_ones() > u32::from(child_count.min(128))
                    || !matches!(
                        role,
                        SemanticRole::Textbox | SemanticRole::Searchbox | SemanticRole::Combobox
                    )
                {
                    return Err(SemanticDecodeError::NodeContract);
                }
                use crate::SemanticFillSupport::*;
                let consistent = match fill_support {
                    // A rich editor's paragraphs are element children.
                    Some(Supported) => child_count <= 128 && child_kinds & 4 == 0,
                    Some(EditableAncestor) => editable_parent,
                    Some(ChildLimit) => child_count == 129,
                    Some(ElementChild) => child_kinds & 2 != 0,
                    Some(OtherChild) => child_kinds & 4 != 0,
                    Some(ReadOnly | Disabled) => true,
                    _ => false,
                };
                if !consistent {
                    return Err(SemanticDecodeError::NodeContract);
                }
                Ok(crate::SemanticEditableStructure {
                    child_count,
                    child_kinds,
                    editable_parent,
                })
            })
            .transpose()?;
        if let Some(support) = fill_support {
            if !matches!(
                role,
                SemanticRole::Textbox | SemanticRole::Searchbox | SemanticRole::Combobox
            ) || (support == crate::SemanticFillSupport::Supported)
                != operations.contains(SemanticOperationClass::Fill)
            {
                return Err(SemanticDecodeError::NodeContract);
            }
        }

        let mut raw_name =
            validate_optional_text(raw_node.name, MAX_SEMANTIC_NAME_BYTES, &mut wire_text_bytes)?;
        let mut raw_text =
            validate_optional_text(raw_node.text, MAX_SEMANTIC_TEXT_BYTES, &mut wire_text_bytes)?;
        let raw_destination = validate_optional_text(
            raw_node.link_destination,
            crate::semantic::MAX_SEMANTIC_LINK_DESTINATION_BYTES,
            &mut wire_text_bytes,
        )?;
        if raw_destination.is_some() && role != SemanticRole::Link {
            return Err(SemanticDecodeError::NodeContract);
        }
        let raw_image = validate_optional_text(
            raw_node.image_source,
            crate::semantic::MAX_SEMANTIC_LINK_DESTINATION_BYTES,
            &mut wire_text_bytes,
        )?;
        if raw_image.is_some() && role != SemanticRole::Image {
            return Err(SemanticDecodeError::NodeContract);
        }
        let (mut value, value_was_secret) =
            decode_value(role, raw_node.value, &mut wire_text_bytes)?;

        let mut sensitivity: SemanticSensitivity = raw_node.sensitivity.into();
        let declared_secret = sensitivity == SemanticSensitivity::Secret;
        let name_was_secret = raw_name
            .as_ref()
            .is_some_and(|name| looks_like_secret_value(name.as_str()));
        if role == SemanticRole::Password
            || raw_name.as_ref().is_some_and(|name| {
                role_accepts_text_value(role) && has_credential_label(name.as_str())
            })
            || name_was_secret
            || value_was_secret
        {
            sensitivity = SemanticSensitivity::Secret;
        }
        if raw_text
            .as_ref()
            .is_some_and(|text| looks_like_secret_value(text.as_str()))
        {
            raw_text = Some(SemanticText::redacted());
            sensitivity = SemanticSensitivity::Secret;
        }
        let retain_name_bytes = !declared_secret && !name_was_secret;
        if raw_name.is_some() && !retain_name_bytes {
            raw_name = Some(SemanticText::redacted());
        }
        if sensitivity == SemanticSensitivity::Secret {
            if matches!(value, Some(SemanticValueSummary::Text(_))) {
                value = Some(SemanticValueSummary::Redacted);
            }
            if raw_text.is_some() {
                raw_text = Some(SemanticText::redacted());
            }
            if role == SemanticRole::Password && value.is_none() {
                value = Some(SemanticValueSummary::Redacted);
            }
        }

        // Only public, credential-free document links enter model context.
        let link_destination = raw_destination
            .filter(|_| sensitivity == SemanticSensitivity::Public)
            .and_then(|value| public_destination(value.as_str()));
        let image_source = raw_image
            .filter(|_| sensitivity == SemanticSensitivity::Public)
            .and_then(|value| public_destination(value.as_str()));
        retained_text_bytes = retained_text_bytes
            .checked_add(
                image_source
                    .as_ref()
                    .map_or(0, |target| target.as_url().as_str().len()),
            )
            .ok_or(SemanticDecodeError::TextLimit)?;
        retained_text_bytes = retained_text_bytes
            .checked_add(
                link_destination
                    .as_ref()
                    .map_or(0, |target| target.as_url().as_str().len()),
            )
            .ok_or(SemanticDecodeError::TextLimit)?;
        retained_text_bytes = retained_text_bytes
            .checked_add(if retain_name_bytes {
                raw_name.as_ref().map_or(0, SemanticText::len)
            } else {
                0
            })
            .and_then(|total| {
                total.checked_add(
                    raw_text
                        .as_ref()
                        .filter(|_| sensitivity != SemanticSensitivity::Secret)
                        .map_or(0, SemanticText::len),
                )
            })
            .and_then(|total| {
                total.checked_add(match value.as_ref() {
                    Some(SemanticValueSummary::Text(text)) => text.len(),
                    _ => 0,
                })
            })
            .ok_or(SemanticDecodeError::TextLimit)?;

        let geometry = raw_node
            .rect
            .map(|rect| SemanticRect::try_new(rect.x, rect.y, rect.width, rect.height))
            .transpose()
            .map_err(|_| SemanticDecodeError::NodeContract)?;
        let approval_identity = match raw_node.approval_identity {
            Some(id) if approval_keys.insert(id) => Some(
                crate::semantic_approval::SemanticApprovalIdentity::new(
                    approval_nonce.ok_or(SemanticDecodeError::NodeIdentity)?,
                    id,
                )
                .ok_or(SemanticDecodeError::NodeIdentity)?,
            ),
            Some(_) => return Err(SemanticDecodeError::NodeIdentity),
            None => None,
        };
        nodes.push(SemanticNodeInput {
            key,
            approval_identity,
            parent,
            depth,
            role,
            heading_level,
            landmark_kind,
            link_destination,
            image_source,
            name: raw_name,
            text: raw_text,
            value,
            states,
            operations,
            activation: raw_node
                .activation
                .map(|code| match code {
                    1 => Ok(crate::SemanticActivation::Ordinary),
                    2 => Ok(crate::SemanticActivation::Submit),
                    3 => Ok(crate::SemanticActivation::Reset),
                    4 => Ok(crate::SemanticActivation::Navigation),
                    5 => Ok(crate::SemanticActivation::Form),
                    6 => Ok(crate::SemanticActivation::Disclosure),
                    _ => Err(SemanticDecodeError::NodeContract),
                })
                .transpose()?,
            form: raw_node
                .form
                .map(|bits| {
                    crate::SemanticFormFacts::decode(bits).ok_or(SemanticDecodeError::NodeContract)
                })
                .transpose()?,
            fill_support,
            editable_structure,
            fields_complete: raw_node.fields_complete,
            sensitivity,
            trust: SemanticTrust::UntrustedPage,
            geometry,
        });
    }

    let page_dialog_sample = raw.page_dialog_sample;
    if matches!(raw.completeness, RawCompleteness::Complete)
        && nodes.iter().any(|node| node.fields_complete == Some(false))
    {
        return Err(SemanticDecodeError::NodeContract);
    }
    if matches!(raw.completeness, RawCompleteness::FieldLimit)
        && nodes.iter().any(|node| node.fields_complete == Some(true))
        && !nodes.iter().any(|node| node.fields_complete == Some(false))
    {
        return Err(SemanticDecodeError::NodeContract);
    }
    if let Some(sample) = &page_dialog_sample {
        sample.validate()?;
    }
    let mut snapshot = SemanticSnapshot::try_new(
        context.invocation,
        context.frame,
        context.generation,
        raw.completeness.into(),
        nodes,
        retained_text_bytes,
    )
    .map_err(|_| SemanticDecodeError::Contract)?;
    if let Some(sample) = &raw.scroll_sample {
        sample.validate()?;
    }
    snapshot.media = crate::semantic_media::decode(raw.media, &snapshot)?;
    snapshot.scroll_sample = raw.scroll_sample;
    snapshot.page_dialog_sample = page_dialog_sample;
    Ok(snapshot)
}

fn validate_optional_text(
    value: Option<String>,
    field_limit: usize,
    total: &mut usize,
) -> Result<Option<SemanticText>, SemanticDecodeError> {
    let Some(value) = value else {
        return Ok(None);
    };
    if value.len() > field_limit {
        return Err(SemanticDecodeError::TextLimit);
    }
    *total = total
        .checked_add(value.len())
        .ok_or(SemanticDecodeError::TextLimit)?;
    if *total > MAX_SEMANTIC_TOTAL_TEXT_BYTES {
        return Err(SemanticDecodeError::TextLimit);
    }
    SemanticText::try_new(value, field_limit)
        .map(Some)
        .map_err(|_| SemanticDecodeError::NodeContract)
}

fn decode_value(
    role: SemanticRole,
    value: Option<RawValue>,
    total: &mut usize,
) -> Result<(Option<SemanticValueSummary>, bool), SemanticDecodeError> {
    let Some(value) = value else {
        return Ok((None, false));
    };
    let (value, secret) = match value {
        RawValue::Text { value } => {
            if !role_accepts_text_value(role) {
                return Err(SemanticDecodeError::NodeContract);
            }
            if value.len() > MAX_SEMANTIC_VALUE_BYTES {
                return Err(SemanticDecodeError::TextLimit);
            }
            *total = total
                .checked_add(value.len())
                .ok_or(SemanticDecodeError::TextLimit)?;
            if *total > MAX_SEMANTIC_TOTAL_TEXT_BYTES {
                return Err(SemanticDecodeError::TextLimit);
            }
            if role == SemanticRole::Password || looks_like_secret_value(&value) {
                (SemanticValueSummary::Redacted, true)
            } else {
                let value = crate::SemanticValueText::try_new(value, MAX_SEMANTIC_VALUE_BYTES)
                    .map_err(|_| SemanticDecodeError::NodeContract)?;
                (SemanticValueSummary::Text(value), false)
            }
        }
        RawValue::Redacted => (SemanticValueSummary::Redacted, true),
        RawValue::Boolean { value } => {
            if !matches!(role, SemanticRole::Checkbox | SemanticRole::Radio) {
                return Err(SemanticDecodeError::NodeContract);
            }
            (SemanticValueSummary::Boolean(value), false)
        }
        RawValue::Ordinal { value } => {
            if !matches!(
                role,
                SemanticRole::Combobox
                    | SemanticRole::Listbox
                    | SemanticRole::Option
                    | SemanticRole::Slider
                    | SemanticRole::Progress
            ) {
                return Err(SemanticDecodeError::NodeContract);
            }
            (SemanticValueSummary::Ordinal(value), false)
        }
    };
    Ok((Some(value), secret))
}

fn validate_operations(
    role: SemanticRole,
    states: SemanticStates,
    operations: SemanticOperations,
) -> Result<(), SemanticDecodeError> {
    if states.contains(SemanticState::Disabled) && !operations.is_empty() {
        return Err(SemanticDecodeError::NodeContract);
    }
    let allowed = allowed_operations(role)?;
    if operations.bits() & !allowed.bits() != 0 {
        return Err(SemanticDecodeError::NodeContract);
    }
    Ok(())
}

fn allowed_operations(role: SemanticRole) -> Result<SemanticOperations, SemanticDecodeError> {
    use SemanticOperationClass::{Click, Fill, Press, Scroll, Select};
    let operations: &[SemanticOperationClass] = match role {
        SemanticRole::Button => &[Click, Press, Scroll],
        SemanticRole::Link
        | SemanticRole::Checkbox
        | SemanticRole::Radio
        | SemanticRole::Option
        | SemanticRole::Slider
        | SemanticRole::Tab
        | SemanticRole::MenuItem => &[Click, Press],
        SemanticRole::Textbox
        | SemanticRole::Password
        | SemanticRole::Searchbox
        | SemanticRole::Spinbutton => &[Click, Fill, Press],
        SemanticRole::Combobox => &[Click, Fill, Select, Press],
        SemanticRole::Listbox => &[Select, Press, Scroll],
        SemanticRole::Group
        | SemanticRole::Document
        | SemanticRole::Landmark
        | SemanticRole::List
        | SemanticRole::Table => &[Scroll],
        // Only when the page made the item clickable itself.
        SemanticRole::ListItem | SemanticRole::Row | SemanticRole::Cell => &[Click],
        SemanticRole::Heading
        | SemanticRole::Paragraph
        | SemanticRole::Dialog
        | SemanticRole::CellHeader
        | SemanticRole::Image
        | SemanticRole::Progress
        | SemanticRole::Status
        | SemanticRole::FrameBoundary => &[],
    };
    SemanticOperations::try_new(operations).map_err(|_| SemanticDecodeError::NodeContract)
}

const fn role_accepts_text_value(role: SemanticRole) -> bool {
    matches!(
        role,
        SemanticRole::Textbox
            | SemanticRole::Password
            | SemanticRole::Searchbox
            | SemanticRole::Combobox
            | SemanticRole::Spinbutton
    )
}

fn has_credential_label(value: &str) -> bool {
    let normalized = value.to_ascii_lowercase();
    CREDENTIAL_LABELS
        .iter()
        .any(|label| normalized.contains(label))
}

fn is_sensitive_url_parameter_name(value: &str) -> bool {
    let normalized: String = value
        .chars()
        .filter(|character| character.is_ascii_alphanumeric())
        .flat_map(char::to_lowercase)
        .collect();
    matches!(
        normalized.as_str(),
        "token"
            | "accesstoken"
            | "refreshtoken"
            | "idtoken"
            | "authtoken"
            | "auth"
            | "authorization"
            | "authcode"
            | "oauthcode"
            | "code"
            | "state"
            | "apikey"
            | "key"
            | "secret"
            | "secretkey"
            | "clientsecret"
            | "signature"
            | "sig"
            | "session"
            | "sessionid"
            | "sessiontoken"
            | "jwt"
            | "assertion"
            | "credential"
            | "credentials"
            | "password"
            | "passcode"
            | "onetimecode"
            | "verificationcode"
            | "ticket"
    )
}

/// Whether an address's fragment, if any, is an app's own routing rather
/// than state that could carry a credential.
pub fn plain_url_fragment(target: &crate::ContextNavigationTarget) -> bool {
    !target
        .as_url()
        .fragment()
        .is_some_and(fragment_contains_sensitive_data)
}

fn fragment_contains_sensitive_data(value: &str) -> bool {
    let Some(decoded) = percent_decode_url_component(value) else {
        return true;
    };
    if decoded.contains('%') || has_credential_label(&decoded) || looks_like_secret_value(&decoded)
    {
        return true;
    }
    contains_sensitive_embedded_url_state(&decoded)
}

fn contains_sensitive_embedded_url_state(value: &str) -> bool {
    contains_sensitive_embedded_url_state_at_depth(value, 0)
}

fn contains_sensitive_embedded_url_state_at_depth(value: &str, depth: u8) -> bool {
    const MAX_NESTED_URL_STATE_DEPTH: u8 = 3;

    let decoded = match percent_decode_url_component(value) {
        Some(decoded) => decoded,
        None => return true,
    };
    if depth == MAX_NESTED_URL_STATE_DEPTH {
        // Reaching the fixed parsing budget with either another encoded layer
        // or another assignment is ambiguous URL state. Fail closed instead of
        // treating a credential label one level deeper as public.
        return decoded != value
            || decoded
                .split(['?', '#', '&', ';'])
                .any(|component| component.contains('='));
    }
    decoded.split(['?', '#', '&', ';']).any(|component| {
        component.split_once('=').is_some_and(|(key, nested)| {
            is_sensitive_url_parameter_name(key)
                || has_credential_label(key)
                || looks_like_secret_value(key)
                || looks_like_secret_value(nested)
                || (depth < MAX_NESTED_URL_STATE_DEPTH
                    && (contains_sensitive_embedded_url_state_at_depth(key, depth + 1)
                        || contains_sensitive_embedded_url_state_at_depth(nested, depth + 1)))
        })
    })
}

/// Shared final disclosure boundary for page-derived or trusted-checkpoint URLs.
/// A canonical page address as the model may see it. An address whose query
/// or fragment carries opaque or credential-like state (a store's tracking
/// blob, a session id) loses those parameters and keeps the rest, so a
/// product link stays the product's own page instead of disappearing; an
/// address whose user, host or path itself looks secret stays omitted.
pub(crate) fn public_destination(value: &str) -> Option<crate::ContextNavigationTarget> {
    let target = crate::ContextNavigationTarget::parse(value).ok()?;
    if target.as_url().as_str() == value
        && !looks_like_secret_value(value)
        && model_safe_public_url(&target)
    {
        return Some(target);
    }
    let mut url = target.as_url().clone();
    if !matches!(url.scheme(), "http" | "https")
        || !url.username().is_empty()
        || url.password().is_some()
        || looks_like_secret_value(url.path())
    {
        return None;
    }
    let kept: Vec<(String, String)> = url
        .query_pairs()
        .filter(|(key, value)| {
            !(is_sensitive_url_parameter_name(key.as_ref())
                || has_credential_label(key.as_ref())
                || looks_like_secret_value(key.as_ref())
                || looks_like_secret_value(value.as_ref())
                || value.contains('%')
                || contains_sensitive_embedded_url_state(key.as_ref())
                || contains_sensitive_embedded_url_state(value.as_ref()))
        })
        .map(|(key, value)| (key.into_owned(), value.into_owned()))
        .collect();
    if kept.is_empty() {
        url.set_query(None);
    } else {
        url.query_pairs_mut().clear().extend_pairs(kept);
    }
    if url.fragment().is_some_and(fragment_contains_sensitive_data) {
        url.set_fragment(None);
    }
    let repaired = crate::ContextNavigationTarget::parse(url.as_str()).ok()?;
    (repaired.as_url().as_str() == url.as_str()
        && !looks_like_secret_value(url.as_str())
        && model_safe_public_url(&repaired))
    .then_some(repaired)
}

pub(crate) fn model_safe_public_url(target: &crate::ContextNavigationTarget) -> bool {
    let url = target.as_url();
    matches!(url.scheme(), "http" | "https")
        && url.username().is_empty()
        && url.password().is_none()
        && !looks_like_secret_value(url.as_str())
        && !url.query().is_some_and(contains_encoded_percent)
        && !url.query_pairs().any(|(key, value)| {
            is_sensitive_url_parameter_name(key.as_ref())
                || has_credential_label(key.as_ref())
                || looks_like_secret_value(key.as_ref())
                || looks_like_secret_value(value.as_ref())
                || value.contains('%')
                || contains_sensitive_embedded_url_state(key.as_ref())
                || contains_sensitive_embedded_url_state(value.as_ref())
        })
        && !url.fragment().is_some_and(fragment_contains_sensitive_data)
}

fn contains_encoded_percent(value: &str) -> bool {
    value
        .as_bytes()
        .windows(3)
        .any(|window| window[0] == b'%' && window[1] == b'2' && matches!(window[2], b'5'))
}

fn percent_decode_url_component(value: &str) -> Option<String> {
    let bytes = value.as_bytes();
    let mut decoded = Vec::with_capacity(bytes.len());
    let mut index = 0;
    while index < bytes.len() {
        if bytes[index] == b'%' {
            let pair = bytes.get(index + 1..index + 3)?;
            let byte = hex_digit(pair[0])?
                .checked_mul(16)?
                .checked_add(hex_digit(pair[1])?)?;
            decoded.push(byte);
            index += 3;
        } else {
            decoded.push(bytes[index]);
            index += 1;
        }
    }
    String::from_utf8(decoded).ok()
}

const fn hex_digit(value: u8) -> Option<u8> {
    match value {
        b'0'..=b'9' => Some(value - b'0'),
        b'a'..=b'f' => Some(value - b'a' + 10),
        b'A'..=b'F' => Some(value - b'A' + 10),
        _ => None,
    }
}

pub(crate) fn looks_like_secret_value(value: &str) -> bool {
    crate::contains_recognized_secret(value)
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct RawSnapshot {
    #[serde(rename = "ap", default)]
    approval_nonce: Option<String>,
    #[serde(rename = "m", default)]
    media: Vec<crate::semantic_media::RawMedia>,
    #[serde(rename = "j", default)]
    scroll_sample: Option<ScrollSample>,
    #[serde(rename = "u", default)]
    page_dialog_sample: Option<PageDialogSample>,
    #[serde(rename = "v")]
    version: u16,
    #[serde(rename = "i")]
    invocation: u64,
    #[serde(rename = "g")]
    generation: u64,
    #[serde(rename = "c")]
    completeness: RawCompleteness,
    #[serde(rename = "n")]
    nodes: Vec<RawNode>,
}

/// Content-free independently sampled dialog identities, never model context.
#[derive(Clone, Eq, PartialEq, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct PageDialogSample {
    pub a: u64,
    pub i: u64,
    pub g: u64,
    pub before: Vec<u64>,
    pub after: Vec<u64>,
}
impl PageDialogSample {
    fn validate(&self) -> Result<(), SemanticDecodeError> {
        if self.a == 0 || self.i == 0 || self.g == 0 {
            return Err(SemanticDecodeError::NodeIdentity);
        }
        for keys in [&self.before, &self.after] {
            if keys.len() > 16
                || keys.contains(&0)
                || keys.iter().copied().collect::<BTreeSet<_>>().len() != keys.len()
            {
                return Err(SemanticDecodeError::NodeIdentity);
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod page_dialog_sample_tests {
    use super::*;
    #[test]
    fn samples_reject_ambiguous_or_unbounded_identities() {
        for (before, after) in [
            (vec![0], vec![1]),
            (vec![1, 1], vec![2]),
            (vec![1], vec![2, 2]),
            ((1..=17).collect(), vec![]),
            (vec![], (1..=17).collect()),
        ] {
            assert!(PageDialogSample {
                a: 1,
                i: 1,
                g: 1,
                before,
                after
            }
            .validate()
            .is_err());
        }
        assert!(PageDialogSample {
            a: 1,
            i: 1,
            g: 1,
            before: vec![],
            after: vec![1]
        }
        .validate()
        .is_ok());
        assert!(serde_json::from_str::<PageDialogSample>(
            r#"{"a":1,"i":1,"g":1,"before":[],"after":[1],"success":true}"#
        )
        .is_err());
    }
}

#[derive(Deserialize)]
#[serde(rename_all = "snake_case")]
enum RawCompleteness {
    Complete,
    NodeLimit,
    TextLimit,
    FieldLimit,
    DepthLimit,
    InspectionLimit,
    WireLimit,
    ScopeBoundary,
    UnsupportedFrame,
}

impl From<RawCompleteness> for SemanticCompleteness {
    fn from(value: RawCompleteness) -> Self {
        match value {
            RawCompleteness::Complete => Self::Complete,
            RawCompleteness::NodeLimit => Self::Truncated(SemanticTruncation::NodeLimit),
            RawCompleteness::TextLimit => Self::Truncated(SemanticTruncation::TextLimit),
            RawCompleteness::FieldLimit => Self::Truncated(SemanticTruncation::FieldLimit),
            RawCompleteness::DepthLimit => Self::Truncated(SemanticTruncation::DepthLimit),
            RawCompleteness::InspectionLimit => {
                Self::Truncated(SemanticTruncation::InspectionLimit)
            }
            RawCompleteness::WireLimit => Self::Truncated(SemanticTruncation::WireLimit),
            RawCompleteness::ScopeBoundary => Self::Truncated(SemanticTruncation::ScopeBoundary),
            RawCompleteness::UnsupportedFrame => {
                Self::Truncated(SemanticTruncation::UnsupportedFrame)
            }
        }
    }
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct RawNode {
    #[serde(rename = "ai", default)]
    approval_identity: Option<u16>,
    #[serde(rename = "k")]
    key: u64,
    #[serde(rename = "p", default)]
    parent: Option<u16>,
    #[serde(rename = "r")]
    role: RawRole,
    #[serde(rename = "l", default)]
    heading_level: Option<u8>,
    #[serde(rename = "lm", default)]
    landmark_kind: Option<crate::SemanticLandmarkKind>,
    #[serde(rename = "u", default)]
    link_destination: Option<String>,
    #[serde(rename = "m", default)]
    image_source: Option<String>,
    #[serde(rename = "n", default)]
    name: Option<String>,
    #[serde(rename = "t", default)]
    text: Option<String>,
    #[serde(rename = "v", default)]
    value: Option<RawValue>,
    #[serde(rename = "s", default)]
    states: u8,
    #[serde(rename = "o", default)]
    operations: u8,
    #[serde(rename = "ak", default)]
    activation: Option<u8>,
    #[serde(rename = "ff", default)]
    form: Option<u8>,
    #[serde(rename = "fs", default)]
    fill_support: Option<u8>,
    #[serde(rename = "es", default)]
    editable_structure: Option<(u16, u8, bool)>,
    #[serde(rename = "fc", default)]
    fields_complete: Option<bool>,
    #[serde(rename = "q", default)]
    sensitivity: RawSensitivity,
    #[serde(rename = "b", default)]
    rect: Option<RawRect>,
}

fn decode_fill_support(code: u8) -> Result<crate::SemanticFillSupport, SemanticDecodeError> {
    use crate::SemanticFillSupport::*;
    Ok(match code {
        1 => Supported,
        2 => MissingExplicitEditable,
        3 => NativeNotEditable,
        4 => UnsupportedTag,
        5 => EditableAncestor,
        6 => ChildLimit,
        7 => ElementChild,
        8 => OtherChild,
        9 => NativeReadFailed,
        10 => ReadOnly,
        11 => Disabled,
        12 => UnsupportedControl,
        _ => return Err(SemanticDecodeError::NodeContract),
    })
}

#[derive(Clone, Copy, Deserialize)]
#[serde(rename_all = "snake_case")]
enum RawRole {
    Group,
    Document,
    Landmark,
    Heading,
    Paragraph,
    Link,
    Button,
    Textbox,
    Password,
    Searchbox,
    Checkbox,
    Radio,
    Combobox,
    Listbox,
    Option,
    Spinbutton,
    Slider,
    Tab,
    MenuItem,
    Dialog,
    List,
    ListItem,
    Table,
    Row,
    CellHeader,
    Cell,
    Image,
    Progress,
    Status,
    FrameBoundary,
}

impl From<RawRole> for SemanticRole {
    fn from(value: RawRole) -> Self {
        match value {
            RawRole::Group => Self::Group,
            RawRole::Document => Self::Document,
            RawRole::Landmark => Self::Landmark,
            RawRole::Heading => Self::Heading,
            RawRole::Paragraph => Self::Paragraph,
            RawRole::Link => Self::Link,
            RawRole::Button => Self::Button,
            RawRole::Textbox => Self::Textbox,
            RawRole::Password => Self::Password,
            RawRole::Searchbox => Self::Searchbox,
            RawRole::Checkbox => Self::Checkbox,
            RawRole::Radio => Self::Radio,
            RawRole::Combobox => Self::Combobox,
            RawRole::Listbox => Self::Listbox,
            RawRole::Option => Self::Option,
            RawRole::Spinbutton => Self::Spinbutton,
            RawRole::Slider => Self::Slider,
            RawRole::Tab => Self::Tab,
            RawRole::MenuItem => Self::MenuItem,
            RawRole::Dialog => Self::Dialog,
            RawRole::List => Self::List,
            RawRole::ListItem => Self::ListItem,
            RawRole::Table => Self::Table,
            RawRole::Row => Self::Row,
            RawRole::CellHeader => Self::CellHeader,
            RawRole::Cell => Self::Cell,
            RawRole::Image => Self::Image,
            RawRole::Progress => Self::Progress,
            RawRole::Status => Self::Status,
            RawRole::FrameBoundary => Self::FrameBoundary,
        }
    }
}

#[derive(Default, Deserialize)]
#[serde(rename_all = "snake_case")]
enum RawSensitivity {
    #[default]
    Public,
    Sensitive,
    Secret,
}

impl From<RawSensitivity> for SemanticSensitivity {
    fn from(value: RawSensitivity) -> Self {
        match value {
            RawSensitivity::Public => Self::Public,
            RawSensitivity::Sensitive => Self::Sensitive,
            RawSensitivity::Secret => Self::Secret,
        }
    }
}

#[derive(Deserialize)]
#[serde(tag = "k", rename_all = "snake_case", deny_unknown_fields)]
enum RawValue {
    Text { value: String },
    Redacted,
    Boolean { value: bool },
    Ordinal { value: u16 },
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct RawRect {
    x: i32,
    y: i32,
    #[serde(rename = "w")]
    width: u32,
    #[serde(rename = "h")]
    height: u32,
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{
        ContextCapabilities, ContextCapability, ContextId, ContextIdentity, ContextKind,
        ContextOperationId, ContextRegistry, ContextRunId, ContextSettlement, FrameGeneration,
        FrameId, SemanticFrameTrust, SemanticOrigin,
    };
    use serde_json::json;
    use zephium_core::ids::ProfileId;

    #[test]
    fn destinations_lose_opaque_state_and_keep_the_page() {
        let amazon = "https://www.amazon.com/LEGO-Technic-Chevrolet-Corvette-Stingray/dp/B0DFTPRHFK/ref=sr_1_1?dib=eyJ2IjoiMSJ9.Yk3c9Hn0pQ2wXZ7aB_cD.e5fG6hI7jK8lM9nO&dib_tag=se&keywords=lego+technic&qid=1760000000&sr=8-1";
        assert_eq!(
            public_destination(amazon).map(|target| target.as_url().to_string()),
            Some("https://www.amazon.com/LEGO-Technic-Chevrolet-Corvette-Stingray/dp/B0DFTPRHFK/ref=sr_1_1?dib_tag=se&keywords=lego+technic&qid=1760000000&sr=8-1".to_owned())
        );
        for (value, expected) in [
            (
                "https://shop.example.test/item/42?session_id=abcdef123456&color=blue",
                Some("https://shop.example.test/item/42?color=blue"),
            ),
            (
                "https://shop.example.test/item/42?token=sk_live_12345678901234567890",
                Some("https://shop.example.test/item/42"),
            ),
            (
                "https://books.toscrape.com/catalogue/a-light-in-the-attic_1000/index.html",
                Some("https://books.toscrape.com/catalogue/a-light-in-the-attic_1000/index.html"),
            ),
            ("https://user:pass@shop.example.test/item", None),
            (
                "https://shop.example.test/sk_live_12345678901234567890/item",
                None,
            ),
            ("javascript:alert(1)", None),
        ] {
            assert_eq!(
                public_destination(value).map(|target| target.as_url().to_string()),
                expected.map(str::to_owned),
                "{value}"
            );
        }
    }

    fn decode_context() -> SemanticDecodeContext {
        let identity = ContextIdentity::new(
            ContextId::from_raw(1),
            ContextRunId::from_raw(2),
            ProfileId::from(3),
            ContextKind::Owned,
        );
        let capabilities = ContextCapabilities::try_new(
            ContextKind::Owned,
            &[ContextCapability::Observe, ContextCapability::Act],
        )
        .expect("capabilities");
        let mut registry = ContextRegistry::new();
        registry.reserve(identity, capabilities).expect("reserve");
        let construction = registry
            .begin_context(
                identity.id(),
                ContextOperationId::new(1).expect("operation"),
            )
            .expect("construct");
        registry
            .settle_construction(identity.id(), construction, ContextSettlement::Applied)
            .expect("settle");
        let join = registry.join(identity.id()).expect("join");
        let frame = SemanticFrameJoin::try_new(
            join,
            FrameId::MAIN,
            FrameGeneration::INITIAL,
            SemanticOrigin::parse("https://example.test/private").expect("origin"),
            SemanticFrameTrust::SameOrigin,
        )
        .expect("frame");
        SemanticDecodeContext::new(
            SemanticInvocationId::new(7).expect("invocation"),
            frame,
            SemanticSnapshotGeneration::new(9).expect("generation"),
        )
    }

    fn payload(nodes: serde_json::Value) -> Vec<u8> {
        serde_json::to_vec(&json!({
            "v": SEMANTIC_WIRE_VERSION,
            "i": 7,
            "g": 9,
            "c": "complete",
            "n": nodes,
        }))
        .expect("encode")
    }

    #[test]
    fn approval_wire_rejects_malformed_zero_duplicate_or_unjoined_identity() {
        let base = json!({"v":1,"i":7,"g":9,"c":"complete","ap":"000102030405060708090a0b0c0d0e0f","n":[
            {"k":1,"r":"button","n":"Save","o":9,"ai":1},
            {"k":2,"r":"button","n":"Save","o":9,"ai":2}
        ]});
        let decode = |value: &serde_json::Value| {
            decode_semantic_snapshot(decode_context(), &serde_json::to_vec(value).unwrap())
        };
        assert!(decode(&base).unwrap().nodes()[0]
            .approval_identity()
            .is_some());
        for nonce in [
            "",
            "00000000000000000000000000000000",
            "000102030405060708090A0B0C0D0E0F",
            "000102030405060708090a0b0c0d0e0f00",
        ] {
            let mut bad = base.clone();
            bad["ap"] = nonce.into();
            assert!(decode(&bad).is_err());
        }
        for id in [0, 2049] {
            let mut bad = base.clone();
            bad["n"][0]["ai"] = id.into();
            assert!(decode(&bad).is_err());
        }
        let mut duplicate = base.clone();
        duplicate["n"][1]["ai"] = 1.into();
        assert!(decode(&duplicate).is_err());
        let mut missing = base.clone();
        missing.as_object_mut().unwrap().remove("ap");
        assert!(decode(&missing).is_err());
        for node in missing["n"].as_array_mut().unwrap() {
            node.as_object_mut().unwrap().remove("ai");
        }
        assert!(
            decode(&missing)
                .unwrap()
                .nodes()
                .iter()
                .all(|node| node.approval_identity().is_none()),
            "legacy observations have no approval proof"
        );
    }

    #[test]
    fn media_associations_are_bounded_local_references_and_never_secret_pixels() {
        let base = json!({"v":1,"i":7,"g":9,"c":"complete","n":[
            {"k":1,"r":"document"},
            {"k":2,"p":0,"r":"image","b":{"x":0,"y":0,"w":160,"h":110}},
            {"k":3,"p":0,"r":"heading","l":2,"n":"Alpha"}
        ],"m":[{"k":2,"t":"image","r":[3],"l":true}]});
        let read = |value: &serde_json::Value| {
            decode_semantic_snapshot(decode_context(), &serde_json::to_vec(value).unwrap())
        };
        let mut snapshot = read(&base).unwrap();
        assert_eq!(snapshot.media().len(), 1);
        assert_eq!(
            snapshot.media()[0].reference(),
            snapshot.nodes()[1].reference()
        );
        assert_eq!(
            snapshot.media()[0].related(),
            &[snapshot.nodes()[2].reference()]
        );
        snapshot.retain_model_prefix(2);
        assert!(
            snapshot.media()[0].related().is_empty(),
            "truncated-away text cannot remain a row association"
        );
        let mut secret = base.clone();
        secret["n"][1]["q"] = json!("secret");
        assert!(read(&secret).unwrap().media().is_empty());
        for invalid in [
            json!([4]),
            json!([3, 3]),
            json!([1, 2, 3, 4, 5, 6, 7, 8, 9]),
        ] {
            let mut value = base.clone();
            value["m"][0]["r"] = invalid;
            assert!(read(&value).is_err());
        }
        let mut value = base.clone();
        value["m"][0]["t"] = json!("guessed_url");
        assert!(read(&value).is_err());
        let mut value = base.clone();
        value["m"] = json!(vec![base["m"][0].clone(); 49]);
        assert!(read(&value).is_err());
    }

    #[test]
    fn local_field_completeness_is_explicit_consistent_and_not_inferred() {
        for (status, fields, succeeds) in [
            ("complete", json!([true, true]), true),
            ("complete", json!([true, false]), false),
            ("field_limit", json!([true, false]), true),
            ("field_limit", json!([true, true]), false),
            ("field_limit", json!([true, null]), false),
            ("field_limit", json!([null, null]), true),
            ("field_limit", json!([false, false]), true),
            ("field_limit", json!(["true", false]), false),
        ] {
            let mut nodes = json!([{"k":1,"r":"button","n":"short","o":1},
                {"k":2,"r":"button","n":"x".repeat(512),"o":1}]);
            for index in 0..2 {
                if !fields[index].is_null() {
                    nodes[index]["fc"] = fields[index].clone();
                }
            }
            let raw = serde_json::to_vec(&json!({"v":1,"i":7,"g":9,"c":status,"n":nodes})).unwrap();
            let decoded = decode_semantic_snapshot(decode_context(), &raw);
            assert_eq!(decoded.is_ok(), succeeds, "{status}/{fields}");
            if status == "field_limit" && succeeds {
                let snapshot = decoded.unwrap();
                assert_eq!(
                    snapshot.has_complete_node_fields(snapshot.nodes()[0].key()),
                    fields[0] == true
                );
            }
        }
    }

    #[test]
    fn editable_structure_is_bounded_closed_and_not_private_fill_authority() {
        for (shape, support, operations) in [
            (json!([1, 1, false]), 1, 2),
            (json!([0, 0, false]), 1, 2),
            (json!([1, 1, true]), 5, 0),
            (json!([1, 1, true]), 1, 2),
            (json!([1, 2, true]), 5, 0),
            (json!([2, 3, true]), 5, 0),
            (json!([129, 1, false]), 6, 0),
            // A rich editor's paragraphs: element children the fill replaces
            // through the browser's editing.
            (json!([1, 2, false]), 1, 2),
            (json!([3, 3, true]), 1, 2),
        ] {
            let snapshot = decode_semantic_snapshot(
                decode_context(),
                &payload(json!([{"k":1,"r":"textbox","fs":support,"o":operations,"es":shape}])),
            )
            .unwrap();
            let structure = snapshot.nodes()[0].editable_structure().unwrap();
            assert_eq!(structure.child_count(), shape[0].as_u64().unwrap() as u16);
            assert_eq!(structure.editable_parent(), shape[2].as_bool().unwrap());
            assert_eq!(structure.truncated(), structure.child_count() == 129);
        }
        for shape in [
            json!([130, 1, true]),
            json!([1, 8, true]),
            json!([0, 1, true]),
            json!([1, 3, true]),
            json!([1, 0, true]),
            json!([1, 1]),
            json!([1, 1, true, "text"]),
        ] {
            assert!(decode_semantic_snapshot(
                decode_context(),
                &payload(json!([{"k":1,"r":"textbox","fs":5,"es":shape}]))
            )
            .is_err());
        }
        for shape in [
            json!([1, 4, false]),
            json!([1, 6, false]),
            json!([129, 1, false]),
        ] {
            assert!(
                decode_semantic_snapshot(
                    decode_context(),
                    &payload(json!([{"k":1,"r":"textbox","fs":1,"o":2,"es":shape}]))
                )
                .is_err(),
                "structure cannot promote other children or an unbounded host to Fill"
            );
        }
    }

    #[test]
    fn editable_combobox_capabilities_and_diagnostics_decode_without_changing_role() {
        for node in [
            json!({"k":1,"r":"combobox","fs":1,"o":11,"v":{"k":"text","value":"query"}}),
            json!({"k":1,"r":"combobox","fs":1,"o":11,"es":[1,1,false]}),
            json!({"k":1,"r":"combobox","fs":10,"o":9,"v":{"k":"text","value":"readonly"}}),
            json!({"k":1,"r":"combobox","fs":2,"o":13,"v":{"k":"ordinal","value":0}}),
        ] {
            let snapshot = decode_semantic_snapshot(decode_context(), &payload(json!([node])))
                .expect("combobox capabilities");
            assert_eq!(snapshot.nodes()[0].role(), SemanticRole::Combobox);
        }
        for node in [
            json!({"k":1,"r":"combobox","fs":2,"o":11}),
            json!({"k":1,"r":"combobox","fs":1,"o":13}),
            json!({"k":1,"r":"combobox","fs":1,"o":11,"es":[1,4,false]}),
        ] {
            assert!(decode_semantic_snapshot(decode_context(), &payload(json!([node]))).is_err());
        }
    }

    #[test]
    fn fill_support_is_closed_consistent_and_not_action_authority() {
        for code in 1..=12 {
            let bytes =
                payload(json!([{"k":1,"r":"textbox","fs":code,"o":if code == 1 {2} else {0}}]));
            let snapshot = decode_semantic_snapshot(decode_context(), &bytes).unwrap();
            assert_eq!(
                snapshot.nodes()[0].fill_support(),
                Some(decode_fill_support(code).unwrap())
            );
        }
        for node in [
            json!({"k":1,"r":"textbox","fs":0}),
            json!({"k":1,"r":"textbox","fs":13}),
            json!({"k":1,"r":"textbox","fs":"page-authored reason"}),
            json!({"k":1,"r":"textbox","fs":1,"o":0}),
            json!({"k":1,"r":"textbox","fs":7,"o":2}),
            json!({"k":1,"r":"button","fs":7}),
        ] {
            assert!(decode_semantic_snapshot(decode_context(), &payload(json!([node]))).is_err());
        }
    }

    #[test]
    fn valid_payload_decodes_deterministically_with_opaque_reference() {
        let bytes = payload(json!([
            {"k": 1, "r": "document", "o": 16},
            {
                "k": 2,
                "p": 0,
                "r": "button",
                "n": "Save changes",
                "s": 64,
                "o": 1,
                "b": {"x": 10, "y": 20, "w": 120, "h": 30}
            },
            {"k": 3, "p": 0, "r": "heading", "l": 2}
        ]));
        let snapshot = decode_semantic_snapshot(decode_context(), &bytes).expect("snapshot");
        assert_eq!(snapshot.nodes().len(), 3);
        assert_eq!(snapshot.nodes()[1].parent(), Some(0));
        assert_eq!(snapshot.nodes()[1].depth(), 1);
        assert_eq!(snapshot.nodes()[1].reference().model_token(), "@a2");
        assert_eq!(
            snapshot.nodes()[2]
                .heading_level()
                .expect("heading level")
                .get(),
            2
        );
        assert_eq!(snapshot.total_text_bytes(), 12);
    }

    #[test]
    fn landmark_subtypes_are_optional_closed_descriptions_not_names_or_roles() {
        let bytes = payload(serde_json::json!([
            {"k":1,"r":"document"},
            {"k":2,"p":0,"r":"landmark","lm":"main"},
            {"k":3,"p":0,"r":"landmark","lm":"navigation"},
            {"k":4,"p":0,"r":"landmark"}
        ]));
        let snapshot = decode_semantic_snapshot(decode_context(), &bytes).unwrap();
        assert_eq!(
            snapshot.nodes()[1].landmark_kind(),
            Some(crate::SemanticLandmarkKind::Main)
        );
        assert_eq!(
            snapshot.nodes()[2].landmark_kind(),
            Some(crate::SemanticLandmarkKind::Navigation)
        );
        assert_eq!(snapshot.nodes()[3].landmark_kind(), None);
        assert!(snapshot
            .nodes()
            .iter()
            .all(|node| node.name().is_none() && node.operations().is_empty()));
        for (role, kind) in [
            ("button", "main"),
            ("landmark", "arbitrary page label"),
            ("landmark", ""),
        ] {
            let bytes = payload(serde_json::json!([{"k":1,"r":role,"lm":kind}]));
            assert!(decode_semantic_snapshot(decode_context(), &bytes).is_err());
        }
    }

    #[test]
    fn link_destinations_are_exact_public_bounded_data_not_arbitrary_urls() {
        let good = "https://example.test/docs/next";
        let query = "https://example.test/docs?q=public";
        let fragment = "https://example.test/docs#section";
        let public_fragment_state = "https://example.test/docs#q=public&section=1";
        for (destination, sensitivity, retained) in [
            (good, "public", true),
            (query, "public", true),
            (fragment, "public", true),
            (public_fragment_state, "public", true),
            (good, "sensitive", false),
            (good, "secret", false),
            ("https://example.test/docs?token=secret", "public", false),
            (
                "https://example.test/docs?access%5Ftoken=short",
                "public",
                false,
            ),
            (
                "https://example.test/docs?code=Qm9VT3F2cW1ROGxobTVoQ2c",
                "public",
                false,
            ),
            (
                "https://example.test/docs?state=c2lnbmVkLW9hdXRoLXN0YXRl",
                "public",
                false,
            ),
            (
                "https://example.test/docs?q=sk%2Dlive%2Dcredentialvalue",
                "public",
                false,
            ),
            (
                "https://example.test/docs#access%5Ftoken=short",
                "public",
                false,
            ),
            (
                "https://example.test/docs#q=ghp%5Fabcdefghijklmnop",
                "public",
                false,
            ),
            (
                "https://example.test/docs#access_token%3Dshortsecret",
                "public",
                false,
            ),
            (
                "https://example.test/docs?access_token%3Dshortsecret",
                "public",
                false,
            ),
            (
                "https://example.test/docs#q=token=shortsecret",
                "public",
                false,
            ),
            (
                "https://example.test/docs#q=a=b=c=token=shortsecret",
                "public",
                false,
            ),
            (
                "https://example.test/docs?q=a=b=c=d=token=shortsecret",
                "public",
                false,
            ),
            (
                "https://example.test/docs?return=https%3A%2F%2Fother.test%2F%23token%3Dshortsecret",
                "public",
                false,
            ),
            (
                "https://example.test/docs#q=public&access_token=shortsecret",
                "public",
                false,
            ),
            (
                "https://example.test/docs?q=public%26access_token%3Dshortsecret",
                "public",
                false,
            ),
            (
                "https://example.test/docs?q%253Daccess_token%253Dshortsecret",
                "public",
                false,
            ),
            ("https://user:secret@example.test/docs", "public", false),
            ("javascript:alert(1)", "public", false),
            ("about:blank", "public", false),
            ("/docs/next", "public", false),
            ("https://EXAMPLE.test/docs/next", "public", false),
            ("https://example.test/sk-secret-key-value", "public", false),
        ] {
            let snapshot = decode_semantic_snapshot(
                decode_context(),
                &payload(json!([
                    {"k":1,"r":"link","u":destination,"q":sensitivity}
                ])),
            )
            .unwrap();
            let kept = snapshot.nodes()[0]
                .link_destination()
                .map(|target| target.as_url().to_string());
            if retained {
                assert_eq!(kept.as_deref(), Some(destination), "{destination}");
            } else if let Some(kept) = &kept {
                // Opaque or credential-like state is removed, never the page.
                assert!(
                    sensitivity == "public" && kept.starts_with("https://example.test/docs"),
                    "{destination} -> {kept}"
                );
                for marker in ["secret", "short", "Qm9V", "c2ln", "credential", "ghp", "token"] {
                    assert!(!kept.contains(marker), "{destination} -> {kept}");
                }
            }
            assert_eq!(
                snapshot.total_text_bytes(),
                kept.as_ref().map_or(0, |kept| kept.len() as u32)
            );
            assert!(!format!("{snapshot:?}").contains("example.test"));
        }
        for (destination, sensitivity) in [
            (good, "sensitive"),
            (good, "secret"),
            ("https://user:secret@example.test/docs", "public"),
            ("javascript:alert(1)", "public"),
            ("about:blank", "public"),
            ("/docs/next", "public"),
            ("https://example.test/sk-secret-key-value", "public"),
        ] {
            let snapshot = decode_semantic_snapshot(
                decode_context(),
                &payload(json!([
                    {"k":1,"r":"link","u":destination,"q":sensitivity}
                ])),
            )
            .unwrap();
            assert!(
                snapshot.nodes()[0].link_destination().is_none(),
                "{destination}"
            );
        }
        assert_eq!(
            decode_semantic_snapshot(
                decode_context(),
                &payload(json!([
                    {"k":1,"r":"paragraph","u":good}
                ]))
            ),
            Err(SemanticDecodeError::NodeContract)
        );
        assert_eq!(
            decode_semantic_snapshot(
                decode_context(),
                &payload(json!([
                    {"k":1,"r":"link","u":"x".repeat(crate::semantic::MAX_SEMANTIC_LINK_DESTINATION_BYTES + 1)}
                ]))
            ),
            Err(SemanticDecodeError::TextLimit)
        );
    }

    #[test]
    fn field_inspection_and_wire_truncation_are_preserved() {
        for (wire, expected) in [
            (
                "field_limit",
                SemanticCompleteness::Truncated(SemanticTruncation::FieldLimit),
            ),
            (
                "inspection_limit",
                SemanticCompleteness::Truncated(SemanticTruncation::InspectionLimit),
            ),
            (
                "wire_limit",
                SemanticCompleteness::Truncated(SemanticTruncation::WireLimit),
            ),
        ] {
            let bytes = serde_json::to_vec(&json!({
                "v": SEMANTIC_WIRE_VERSION,
                "i": 7,
                "g": 9,
                "c": wire,
                "n": []
            }))
            .expect("encode");
            assert_eq!(
                decode_semantic_snapshot(decode_context(), &bytes)
                    .expect("snapshot")
                    .completeness(),
                expected
            );
        }
    }

    #[test]
    fn unknown_fields_and_wrong_authority_fail_closed() {
        let unknown = serde_json::to_vec(&json!({
            "v": 1, "i": 7, "g": 9, "c": "complete", "n": [], "eval": "alert(1)"
        }))
        .expect("encode");
        assert_eq!(
            decode_semantic_snapshot(decode_context(), &unknown),
            Err(SemanticDecodeError::Malformed)
        );
        let wrong_invocation = serde_json::to_vec(&json!({
            "v": 1, "i": 8, "g": 9, "c": "complete", "n": []
        }))
        .expect("encode");
        assert_eq!(
            decode_semantic_snapshot(decode_context(), &wrong_invocation),
            Err(SemanticDecodeError::InvocationMismatch)
        );
        let wrong_generation = serde_json::to_vec(&json!({
            "v": 1, "i": 7, "g": 10, "c": "complete", "n": []
        }))
        .expect("encode");
        assert_eq!(
            decode_semantic_snapshot(decode_context(), &wrong_generation),
            Err(SemanticDecodeError::GenerationMismatch)
        );
        for duplicate in [
            br#"{"v":1,"i":7,"i":7,"g":9,"c":"complete","n":[]}"#.as_slice(),
            br#"{"v":1,"i":7,"g":9,"c":"complete","n":[{"k":1,"r":"button","r":"button"}]}"#
                .as_slice(),
        ] {
            assert_eq!(
                decode_semantic_snapshot(decode_context(), duplicate),
                Err(SemanticDecodeError::Malformed)
            );
        }
    }

    #[test]
    fn secret_values_are_redacted_before_entering_snapshot() {
        let bytes = payload(json!([
            {
                "k": 1,
                "r": "textbox",
                "n": "API key",
                "v": {"k": "text", "value": "sk-super-secret-value"},
                "o": 2
            },
            {
                "k": 2,
                "r": "paragraph",
                "t": "eyJheader.payloadpayload.signaturesignature"
            },
            {
                "k": 3,
                "r": "button",
                "n": "ghp_private-name-value"
            },
            {
                "k": 4,
                "r": "textbox",
                "n": "Ordinary field",
                "v": {"k": "text", "value": format!("{} sk-super-secret-value", "x".repeat(1024))},
                "o": 2
            },
            {
                "k": 5,
                "r": "textbox",
                "n": format!("{} api key", "x".repeat(500)),
                "v": {"k": "text", "value": "must-not-cross"},
                "o": 2
            }
        ]));
        let snapshot = decode_semantic_snapshot(decode_context(), &bytes).expect("snapshot");
        assert_eq!(
            snapshot.nodes()[0].sensitivity(),
            SemanticSensitivity::Secret
        );
        assert_eq!(
            snapshot.nodes()[0].value(),
            Some(&SemanticValueSummary::Redacted)
        );
        assert_eq!(
            snapshot.nodes()[1].text().expect("redacted text").as_str(),
            "[redacted]"
        );
        assert_eq!(
            snapshot.nodes()[2].name().expect("redacted name").as_str(),
            "[redacted]"
        );
        assert_eq!(
            snapshot.nodes()[3].value(),
            Some(&SemanticValueSummary::Redacted),
            "secret beyond the model preview boundary was exposed"
        );
        assert_eq!(
            snapshot.nodes()[4].value(),
            Some(&SemanticValueSummary::Redacted)
        );
        assert_eq!(
            snapshot.nodes()[4].sensitivity(),
            SemanticSensitivity::Secret
        );
        assert_eq!(
            snapshot.nodes()[2].sensitivity(),
            SemanticSensitivity::Secret
        );
        assert_eq!(
            snapshot.total_text_bytes(),
            ("API key".len() + "Ordinary field".len() + 500 + " api key".len()) as u32
        );
        let debug = format!("{snapshot:?} {:?}", snapshot.nodes());
        assert!(!debug.contains("sk-super"));
        assert!(!debug.contains("eyJheader"));
        assert!(!debug.contains("ghp_private"));
    }

    #[test]
    fn embedded_tokens_and_authorization_values_are_detected() {
        for value in [
            "token: sk-super-secret-value",
            "Authorization: Bearer abcdefghijklmnop",
            "credential=(github_pat_abcdefghijklmnop)",
            "key=AKIAABCDEFGHIJKLMNOP",
            "prefix eyJheader.payloadpayload.signaturesignature suffix",
        ] {
            assert!(looks_like_secret_value(value), "missed secret form");
        }
        for value in ["basic settings", "task-list", "ordinary visible text"] {
            assert!(!looks_like_secret_value(value), "false positive");
        }
    }

    #[test]
    fn password_values_are_redacted_even_if_runtime_claims_public() {
        let bytes = payload(json!([{
            "k": 1,
            "r": "password",
            "n": "Password",
            "q": "public",
            "v": {"k": "text", "value": "not-pattern-matched"},
            "o": 2
        }]));
        let snapshot = decode_semantic_snapshot(decode_context(), &bytes).expect("snapshot");
        assert_eq!(
            snapshot.nodes()[0].value(),
            Some(&SemanticValueSummary::Redacted)
        );
        assert_eq!(
            snapshot.nodes()[0].sensitivity(),
            SemanticSensitivity::Secret
        );
    }

    #[test]
    fn duplicate_keys_forward_parents_and_excess_depth_are_rejected() {
        assert_eq!(
            decode_semantic_snapshot(
                decode_context(),
                &payload(json!([
                    {"k": 1, "r": "group"},
                    {"k": 1, "r": "group"}
                ])),
            ),
            Err(SemanticDecodeError::NodeIdentity)
        );
        assert_eq!(
            decode_semantic_snapshot(
                decode_context(),
                &payload(json!([{"k": 1, "p": 0, "r": "group"}])),
            ),
            Err(SemanticDecodeError::Parent)
        );
        let mut nodes = Vec::new();
        for index in 0..=MAX_SEMANTIC_DEPTH + 1 {
            let parent = index.checked_sub(1);
            nodes.push(json!({"k": index + 1, "p": parent, "r": "group"}));
        }
        assert_eq!(
            decode_semantic_snapshot(decode_context(), &payload(json!(nodes))),
            Err(SemanticDecodeError::DepthLimit)
        );
    }

    #[test]
    fn role_state_value_and_operation_contradictions_are_rejected() {
        for nodes in [
            json!([{"k": 1, "r": "paragraph", "o": 1}]),
            json!([{"k": 1, "r": "button", "s": 8, "o": 1}]),
            json!([{"k": 1, "r": "button", "v": {"k": "text", "value": "x"}}]),
            json!([{"k": 1, "r": "heading"}]),
            json!([{"k": 1, "r": "heading", "l": 7}]),
            json!([{"k": 1, "r": "button", "l": 2}]),
            json!([{"k": 1, "r": "button", "o": 128}]),
            json!([{"k": 1, "r": "button", "o": 16}]),
            json!([{"k": 1, "r": "button", "o": 25, "ak": 2}]),
            json!([{"k": 1, "r": "button", "s": 128}]),
        ] {
            assert_eq!(
                decode_semantic_snapshot(decode_context(), &payload(nodes)),
                Err(SemanticDecodeError::NodeContract)
            );
        }
    }

    #[test]
    fn page_clickable_items_admit_click_and_nothing_more() {
        for role in ["row", "cell", "list_item"] {
            let snapshot = decode_semantic_snapshot(
                decode_context(),
                &payload(json!([{"k": 1, "r": role, "o": 1}])),
            )
            .expect("clickable item");
            assert_eq!(
                snapshot.nodes()[0].operations(),
                SemanticOperations::try_new(&[SemanticOperationClass::Click]).unwrap()
            );
            for operations in [2, 4, 8, 16] {
                assert_eq!(
                    decode_semantic_snapshot(
                        decode_context(),
                        &payload(json!([{"k": 1, "r": role, "o": operations}])),
                    ),
                    Err(SemanticDecodeError::NodeContract)
                );
            }
        }
        assert_eq!(
            decode_semantic_snapshot(
                decode_context(),
                &payload(json!([{"k": 1, "r": "cell_header", "o": 1}])),
            ),
            Err(SemanticDecodeError::NodeContract)
        );
    }

    #[test]
    fn form_facts_decode_closed_bits_only() {
        let snapshot = decode_semantic_snapshot(
            decode_context(),
            &payload(json!([{"k": 1, "r": "button", "n": "Search", "o": 1, "ak": 2, "ff": 13}])),
        )
        .expect("snapshot");
        let form = snapshot.nodes()[0].form().expect("form facts");
        assert_eq!(form.method(), crate::SemanticFormMethod::Get);
        assert!(form.same_origin() && form.search());
        for bits in [0, 16, 64] {
            assert_eq!(
                decode_semantic_snapshot(
                    decode_context(),
                    &payload(json!([{"k": 1, "r": "button", "o": 1, "ak": 2, "ff": bits}])),
                ),
                Err(SemanticDecodeError::NodeContract)
            );
        }
    }

    #[test]
    fn page_content_digest_ignores_keys_and_focus_but_not_text() {
        let digest = |nodes| {
            crate::semantic_action::page_digest(
                &decode_semantic_snapshot(decode_context(), &payload(nodes)).expect("snapshot"),
            )
        };
        let before = digest(json!([
            {"k": 1, "r": "document"},
            {"k": 2, "p": 0, "r": "paragraph", "t": "3 results"}
        ]));
        let rekeyed = digest(json!([
            {"k": 7, "r": "document"},
            {"k": 9, "p": 0, "r": "paragraph", "t": "3 results"}
        ]));
        let changed = digest(json!([
            {"k": 1, "r": "document"},
            {"k": 2, "p": 0, "r": "paragraph", "t": "12 results"}
        ]));
        assert_eq!(before, rekeyed);
        assert_ne!(before, changed);
    }

    #[test]
    fn wire_node_field_and_total_text_limits_are_enforced() {
        let oversized_wire = vec![b' '; MAX_SEMANTIC_WIRE_BYTES + 1];
        assert_eq!(
            decode_semantic_snapshot(decode_context(), &oversized_wire),
            Err(SemanticDecodeError::WireLimit)
        );
        assert_eq!(
            decode_semantic_snapshot(
                decode_context(),
                &payload(json!([{
                    "k": 1,
                    "r": "paragraph",
                    "t": "x".repeat(MAX_SEMANTIC_TEXT_BYTES + 1)
                }])),
            ),
            Err(SemanticDecodeError::TextLimit)
        );
        assert_eq!(
            decode_semantic_snapshot(
                decode_context(),
                &payload(json!([{
                    "k": 1,
                    "r": "textbox",
                    "v": {
                        "k": "text",
                        "value": format!(
                            "{} sk-super-secret-value",
                            "x".repeat(MAX_SEMANTIC_VALUE_BYTES + 1)
                        )
                    },
                    "o": 10
                }])),
            ),
            Err(SemanticDecodeError::TextLimit),
            "Rust must not accept an over-limit raw value that bypassed runtime redaction"
        );
        for invalid in ["safe\0suffix", "safe\rsuffix", "safe\u{202e}suffix"] {
            assert_eq!(
                decode_semantic_snapshot(
                    decode_context(),
                    &payload(json!([{
                        "k": 1,
                        "r": "textbox",
                        "v": {"k": "text", "value": invalid},
                        "o": 10
                    }])),
                ),
                Err(SemanticDecodeError::NodeContract),
                "invalid exact value crossed the Rust boundary"
            );
        }
        let unpaired_surrogate = br#"{"v":1,"i":7,"g":9,"c":"complete","n":[{"k":1,"r":"textbox","v":{"k":"text","value":"safe\ud800suffix"},"o":10}]}"#;
        assert_eq!(
            decode_semantic_snapshot(decode_context(), unpaired_surrogate),
            Err(SemanticDecodeError::Malformed),
            "unpaired surrogate crossed the Rust boundary"
        );
        let nodes = (0..=MAX_SEMANTIC_NODES)
            .map(|index| json!({"k": index + 1, "r": "group"}))
            .collect::<Vec<_>>();
        assert_eq!(
            decode_semantic_snapshot(decode_context(), &payload(json!(nodes))),
            Err(SemanticDecodeError::NodeLimit)
        );
    }

    #[test]
    fn decoder_and_snapshot_debug_never_emit_hostile_page_strings() {
        let bytes = payload(json!([{
            "k": 1,
            "r": "button",
            "n": "private-user-content",
            "o": 1
        }]));
        let snapshot = decode_semantic_snapshot(decode_context(), &bytes).expect("snapshot");
        let debug = format!("{snapshot:?} {:?}", snapshot.nodes());
        assert!(!debug.contains("private-user-content"));
        assert!(!debug.contains("example.test"));
        assert!(!debug.contains("ProfileId"));
    }
}

#[derive(Clone, Eq, PartialEq, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct ScrollSample {
    pub a: u64,
    pub i: u64,
    pub g: u64,
    pub t: u64,
    pub before: [i64; 2],
    pub after: [i64; 2],
    pub visible: Option<bool>,
}
impl ScrollSample {
    fn validate(&self) -> Result<(), SemanticDecodeError> {
        if [self.a, self.i, self.g, self.t].contains(&0)
            || self
                .before
                .iter()
                .chain(&self.after)
                .any(|n| n.unsigned_abs() > crate::MAX_SEMANTIC_SCROLL_COORDINATE)
        {
            return Err(SemanticDecodeError::NodeIdentity);
        }
        Ok(())
    }
}
