use super::*;

fn initial() -> AgentWorkRecord {
    let mut bytes = [0; AGENT_WORK_RECORD_BYTES];
    bytes[0] = 1;
    bytes[1] = 1;
    bytes[2] = 63;
    bytes[15] = 1;
    bytes[31] = 1;
    bytes[47] = 2;
    bytes[63] = 3;
    AgentWorkRecord::decode(bytes).unwrap()
}

#[test]
fn every_disposition_pair_has_closed_transition_grammar() {
    use AgentWorkDisposition::*;
    let dispositions = [
        Admitted,
        Running,
        NeedsApproval,
        RecoveryRequired,
        Interrupted,
        Succeeded,
        FreshAdmissionRequired,
        Rejected,
        FailedClosed,
        Failed,
        Cancelled,
        WaitingForHuman,
    ];
    for from in dispositions {
        let mut bytes = *initial().as_bytes();
        bytes[1] = from as u8;
        bytes[2] = if matches!(from, Succeeded | Failed | Cancelled | WaitingForHuman) {
            0
        } else {
            63
        };
        if from == WaitingForHuman {
            bytes[3] = 1;
            bytes[7] = 1;
        }
        let record = AgentWorkRecord::decode(bytes).unwrap();
        for to in dispositions {
            let allowed = matches!(
                (from, to),
                (Admitted, Running | RecoveryRequired | FailedClosed)
                    | (Running, NeedsApproval | RecoveryRequired | FailedClosed)
                    | (
                        NeedsApproval | Interrupted | RecoveryRequired,
                        FreshAdmissionRequired | Rejected | FailedClosed
                    )
            );
            assert_eq!(record.transition(to).is_ok(), allowed, "{from:?} -> {to:?}");
        }
    }
}

#[test]
fn review_is_one_use_and_never_clears_execution_debt() {
    let review = initial()
        .transition(AgentWorkDisposition::Running)
        .unwrap()
        .transition(AgentWorkDisposition::NeedsApproval)
        .unwrap();
    for decision in [
        AgentWorkDisposition::FreshAdmissionRequired,
        AgentWorkDisposition::Rejected,
    ] {
        let next = AgentWorkJournalMutation::transition(review, decision)
            .unwrap()
            .next();
        assert_eq!(next.debt(), AgentWorkDebt::UNKNOWN);
        assert!(next.disposition().is_terminal());
        assert!(AgentWorkJournalMutation::transition(next, decision).is_err());
        assert!(AgentWorkJournalMutation::transition(next, AgentWorkDisposition::Running).is_err());
        assert!(next.is_successor_of(review));
    }
}

#[test]
fn proof_closed_review_preserves_debt_and_terminal_cas_without_replay() {
    let running = initial().transition(AgentWorkDisposition::Running).unwrap();
    // Decoding tests persisted grammar only, never mints proof-bearing mutation.
    let mut bytes = *running.as_bytes();
    bytes[1] = AgentWorkDisposition::NeedsApproval as u8;
    bytes[2] = 0;
    bytes[8..16].copy_from_slice(&(running.revision() + 1).to_be_bytes());
    let review = AgentWorkRecord::decode(bytes).unwrap();
    assert!(review.is_successor_of(running));
    assert!(!review.is_successor_of(initial()));
    assert_ne!(
        AgentWorkJournalMutation::transition(running, AgentWorkDisposition::NeedsApproval)
            .unwrap()
            .next(),
        review
    );
    for decision in [
        AgentWorkDisposition::FreshAdmissionRequired,
        AgentWorkDisposition::Rejected,
        AgentWorkDisposition::FailedClosed,
    ] {
        let terminal = AgentWorkJournalMutation::transition(review, decision)
            .unwrap()
            .next();
        assert_eq!(terminal.debt(), AgentWorkDebt::NONE);
        assert_eq!(
            AgentWorkRecord::decode(*terminal.as_bytes()),
            Some(terminal)
        );
        assert!(terminal.is_successor_of(review));
        assert!(terminal.disposition().is_terminal());
        assert!(terminal.transition(decision).is_err());
        assert!(terminal.transition(AgentWorkDisposition::Running).is_err());
        assert_eq!(
            terminal
                .interrupted(AgentWorkIncarnation::generate())
                .unwrap(),
            terminal
        );
    }
    let restart = review
        .interrupted(AgentWorkIncarnation::generate())
        .unwrap();
    assert_eq!(restart.disposition(), AgentWorkDisposition::Interrupted);
    assert_eq!(restart.debt(), AgentWorkDebt::UNKNOWN);
}

#[test]
fn unsuccessful_closed_facts_are_immutable_and_cannot_mint_mutation_authority() {
    let running = initial().transition(AgentWorkDisposition::Running).unwrap();
    for disposition in [
        AgentWorkDisposition::Failed,
        AgentWorkDisposition::Cancelled,
        AgentWorkDisposition::WaitingForHuman,
    ] {
        let mut bytes = *running.as_bytes();
        bytes[1] = disposition as u8;
        bytes[2] = 0;
        if disposition == AgentWorkDisposition::WaitingForHuman {
            bytes[3] = 1;
            bytes[7] = 1;
        }
        bytes[8..16].copy_from_slice(&(running.revision() + 1).to_be_bytes());
        let terminal = AgentWorkRecord::decode(bytes).unwrap();
        assert!(terminal.is_successor_of(running));
        assert!(!terminal.is_successor_of(initial()));
        assert_eq!(terminal.debt(), AgentWorkDebt::NONE);
        assert_eq!(
            terminal.human_handoff().map(AgentWorkHumanHandoff::reason),
            (disposition == AgentWorkDisposition::WaitingForHuman)
                .then_some(AgentBrowserHumanReason::SignIn)
        );
        assert_eq!(
            terminal.interrupted(AgentWorkIncarnation::generate()),
            Ok(terminal)
        );
        assert!(AgentWorkJournalMutation::transition(running, disposition).is_err());
        assert!(terminal.transition(AgentWorkDisposition::Running).is_err());
        assert!(terminal
            .transition(AgentWorkDisposition::FailedClosed)
            .is_err());
        bytes[2] = AgentWorkDebt::UNKNOWN.bits();
        assert!(AgentWorkRecord::decode(bytes).is_none());
    }
}

#[test]
fn human_handoff_metadata_is_exact_bounded_and_validated() {
    let handoff = AgentWorkHumanHandoff::try_new(
        AgentBrowserHumanReason::HumanChallenge,
        SemanticObservationId::new(42).unwrap(),
    )
    .unwrap();
    assert_eq!(handoff.reason(), AgentBrowserHumanReason::HumanChallenge);
    assert_eq!(handoff.observation(), 42);

    let running = initial().transition(AgentWorkDisposition::Running).unwrap();
    let mut bytes = *running.as_bytes();
    bytes[1] = AgentWorkDisposition::WaitingForHuman as u8;
    bytes[2] = AgentWorkDebt::NONE.bits();
    bytes[3] = handoff.reason_byte();
    bytes[4..8].copy_from_slice(&handoff.observation().to_be_bytes());
    bytes[8..16].copy_from_slice(&(running.revision() + 1).to_be_bytes());
    let terminal = AgentWorkRecord::decode(bytes).unwrap();
    assert_eq!(terminal.human_handoff(), Some(handoff));
    assert!(terminal.is_successor_of(running));

    for corrupt in [0, 8] {
        let mut bytes = *terminal.as_bytes();
        bytes[3] = corrupt;
        assert!(AgentWorkRecord::decode(bytes).is_none());
    }
    let mut missing_observation = *terminal.as_bytes();
    missing_observation[4..8].fill(0);
    assert!(AgentWorkRecord::decode(missing_observation).is_none());
}

#[test]
fn restart_fences_incomplete_state_without_reopening_terminal_state() {
    let prior = initial().transition(AgentWorkDisposition::Running).unwrap();
    let owner = AgentWorkIncarnation::generate();
    let recovered = prior.interrupted(owner).unwrap();
    assert_eq!(recovered.disposition(), AgentWorkDisposition::Interrupted);
    assert_eq!(recovered.revision(), prior.revision() + 1);
    assert_eq!(recovered.incarnation(), owner);
    assert_eq!(recovered.debt(), AgentWorkDebt::UNKNOWN);
    assert!(!recovered.is_successor_of(prior));
    assert_eq!(recovered.interrupted(owner), Ok(recovered));
    let terminal = recovered
        .transition(AgentWorkDisposition::Rejected)
        .unwrap();
    assert_eq!(
        terminal.interrupted(AgentWorkIncarnation::generate()),
        Ok(terminal)
    );
}

#[test]
fn corrupt_versions_reserved_fields_and_zero_or_contradictory_state_fail_closed() {
    for (offset, value) in [
        (0, 0),
        (0, 2),
        (1, 0),
        (1, 13),
        (2, 64),
        (3, 1),
        (7, 1),
        (15, 0),
        (31, 0),
        (2, 0),
    ] {
        let mut bytes = *initial().as_bytes();
        bytes[offset] = value;
        assert!(AgentWorkRecord::decode(bytes).is_none(), "offset {offset}");
    }
    let mut bytes = *initial().as_bytes();
    bytes[1] = AgentWorkDisposition::Succeeded as u8;
    assert!(AgentWorkRecord::decode(bytes).is_none());
}

#[test]
fn overflow_and_foreign_cas_are_refused() {
    let prior = initial();
    let next = prior.transition(AgentWorkDisposition::Running).unwrap();
    let mut bytes = *next.as_bytes();
    bytes[63] = 4;
    assert!(!AgentWorkRecord::decode(bytes)
        .unwrap()
        .is_successor_of(prior));
    let mut bytes = *prior.as_bytes();
    bytes[8..16].copy_from_slice(&u64::MAX.to_be_bytes());
    assert_eq!(
        AgentWorkRecord::decode(bytes)
            .unwrap()
            .transition(AgentWorkDisposition::Running),
        Err(AgentWorkJournalError::Capacity)
    );
}

#[test]
fn debug_projection_is_content_free_and_omits_durable_identifiers() {
    assert_eq!(
        format!("{:?}", initial()),
        "AgentWorkRecord { revision: 1, disposition: Admitted, debt: AgentWorkDebt(63), .. }"
    );
    assert_eq!(
        format!("{:?}", initial().incarnation()),
        "AgentWorkIncarnation([redacted])"
    );
}

#[test]
fn inventory_keeps_every_obligation_and_only_a_window_of_clean_history() {
    let run = |key: u16, disposition: AgentWorkDisposition, debt: AgentWorkDebt| {
        let mut bytes = *initial().as_bytes();
        bytes[1] = disposition as u8;
        bytes[2] = debt.bits();
        bytes[62..64].copy_from_slice(&key.to_be_bytes());
        AgentWorkRecord::decode(bytes).unwrap()
    };
    let mut inventory = Vec::new();
    for key in 0..2000 {
        let clean = run(key, AgentWorkDisposition::Failed, AgentWorkDebt::NONE);
        assert!(clean.is_clean_terminal());
        assert!(remember_agent_work_record(&mut inventory, clean));
    }
    assert_eq!(inventory.len(), RETAINED_CLEAN_AGENT_WORK_RUNS);
    assert_eq!(inventory[0].key()[30..], (2000 - 256_u16).to_be_bytes());
    for key in 3000..3000 + MAX_DURABLE_AGENT_WORK_RUNS as u16 {
        let debt = run(key, AgentWorkDisposition::Rejected, AgentWorkDebt::UNKNOWN);
        assert!(!debt.is_clean_terminal());
        assert!(remember_agent_work_record(&mut inventory, debt));
    }
    assert!(!remember_agent_work_record(&mut inventory, initial()));
    assert!(remember_agent_work_record(
        &mut inventory,
        run(9000, AgentWorkDisposition::Succeeded, AgentWorkDebt::NONE)
    ));
    assert_eq!(
        outstanding_agent_work_runs(&inventory),
        MAX_DURABLE_AGENT_WORK_RUNS
    );
    assert_eq!(inventory.len(), MAX_AGENT_WORK_INVENTORY);
}
