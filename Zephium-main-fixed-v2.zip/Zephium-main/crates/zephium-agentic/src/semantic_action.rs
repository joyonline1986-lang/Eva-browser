//! Bounded pre-policy semantic action proposals and exact snapshot binding.
//!
//! This module deliberately stops before policy authorization or native input.
//! It turns a small closed model-facing vocabulary into content-redacted guards
//! over one exact observation and current frame cohort. A later policy layer
//! must mint execution authority; these values alone cannot cause an effect.

use std::fmt;
use std::num::{NonZeroU32, NonZeroU64};

use serde::Serialize;
use sha2::{Digest, Sha256};
use thiserror::Error;

use crate::semantic::SemanticNodeKey;
use crate::semantic_wire::looks_like_secret_value;
use crate::{
    ContextJoin, FrameId, SemanticActivation, SemanticFrameJoin, SemanticInvocationId,
    SemanticObservation, SemanticObservationGeneration, SemanticObservationId,
    SemanticOperationClass, SemanticOperations, SemanticRect, SemanticReferenceError,
    SemanticReferenceId, SemanticRole, SemanticSensitivity, SemanticSnapshot,
    SemanticSnapshotGeneration, SemanticState, SemanticStates, SemanticTrust, SemanticValueSummary,
    MAX_SEMANTIC_FRAMES,
};

/// Maximum sequential actions proposed in one model turn.
pub const MAX_SEMANTIC_ACTIONS_PER_BATCH: usize = 8;
/// Maximum UTF-8 bytes in one fixed text-replacement action.
pub const MAX_SEMANTIC_ACTION_TEXT_BYTES: usize = 4 * 1024;
/// Maximum aggregate UTF-8 bytes carried by one action batch.
pub const MAX_SEMANTIC_ACTION_BATCH_TEXT_BYTES: usize = 16 * 1024;
/// Maximum settle budget for one action.
pub const MAX_SEMANTIC_ACTION_SETTLE_MILLIS: u32 = 30_000;
/// Maximum aggregate settle budget for one batch.
pub const MAX_SEMANTIC_ACTION_BATCH_SETTLE_MILLIS: u32 = 60_000;
/// Maximum quiet interval in a mutation-quiet wait.
pub const MAX_SEMANTIC_MUTATION_QUIET_MILLIS: u32 = 1_000;

/// Nonzero shell-minted identity for one exact bounded action batch.
#[derive(Clone, Copy, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct SemanticActionBatchId(NonZeroU64);

impl SemanticActionBatchId {
    /// Constructs a nonzero process-local action-batch identity.
    pub const fn new(value: u64) -> Option<Self> {
        match NonZeroU64::new(value) {
            Some(value) => Some(Self(value)),
            None => None,
        }
    }

    /// Returns the process-local correlation value to trusted orchestration.
    pub const fn get(self) -> u64 {
        self.0.get()
    }
}

impl fmt::Debug for SemanticActionBatchId {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("SemanticActionBatchId([redacted])")
    }
}

/// Exact bounded text replacement carried only to a fixed fill recipe after policy.
#[derive(Clone, Eq, PartialEq)]
pub struct SemanticActionText(String);

impl SemanticActionText {
    /// Applies hard character/size bounds and refuses recognized secret forms.
    ///
    /// This heuristic refusal is defense in depth, not data classification.
    /// Deterministic provenance/source-to-sink policy remains mandatory before
    /// execution. Empty text is a valid clear operation.
    pub fn try_new(value: String) -> Result<Self, SemanticActionTextError> {
        if value.len() > MAX_SEMANTIC_ACTION_TEXT_BYTES {
            return Err(SemanticActionTextError::Limit);
        }
        if value.chars().any(invalid_action_character) {
            return Err(SemanticActionTextError::InvalidCharacter);
        }
        if looks_like_secret_value(&value) {
            return Err(SemanticActionTextError::Secret);
        }
        Ok(Self(value))
    }

    /// Returns exact replacement text only to trusted policy/native adapters.
    ///
    /// This value is plain text, never HTML, a selector, JavaScript, a property
    /// path, or a native handle. It must not be logged or traced.
    pub fn as_str(&self) -> &str {
        &self.0
    }

    /// Exact UTF-8 byte count used for aggregate batch admission.
    pub fn len(&self) -> usize {
        self.0.len()
    }

    /// Whether this action intentionally clears the target.
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

impl fmt::Debug for SemanticActionText {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("SemanticActionText")
            .field("bytes", &self.0.len())
            .field("content", &"[redacted]")
            .finish()
    }
}

fn invalid_action_character(character: char) -> bool {
    (character.is_control() && !matches!(character, '\t' | '\n'))
        || matches!(
            character,
            '\u{00ad}'
                | '\u{061c}'
                | '\u{180e}'
                | '\u{200b}'..='\u{200f}'
                | '\u{202a}'..='\u{202e}'
                | '\u{2060}'..='\u{2064}'
                | '\u{2066}'..='\u{206f}'
                | '\u{feff}'
                | '\u{fff9}'..='\u{fffb}'
                | '\u{e0001}'
                | '\u{e0020}'..='\u{e007f}'
        )
}

/// Refusal while constructing fixed fill text.
#[derive(Clone, Copy, Debug, Eq, Error, PartialEq)]
pub enum SemanticActionTextError {
    /// Text exceeded the fixed per-action byte ceiling.
    #[error("semantic action text exceeds its byte ceiling")]
    Limit,
    /// Text contained a control or invisible directional formatting character.
    #[error("semantic action text contains a forbidden character")]
    InvalidCharacter,
    /// Text matched a credential, token, authorization, or private-key form.
    #[error("semantic action text resembles a secret")]
    Secret,
}

/// Closed model-proposable semantic operation class.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SemanticActionKind {
    /// Activate one observed control.
    Click,
    /// Replace text in one observed editable control.
    Fill,
    /// Select one observed option within an observed select-like control.
    Select,
    /// Dispatch one fixed key recipe to an observed control.
    Press,
    /// Scroll one observed document or region through a fixed recipe.
    Scroll,
}

impl SemanticActionKind {
    /// Snapshot operation capability required by this action class.
    pub const fn operation(self) -> SemanticOperationClass {
        match self {
            Self::Click => SemanticOperationClass::Click,
            Self::Fill => SemanticOperationClass::Fill,
            Self::Select => SemanticOperationClass::Select,
            Self::Press => SemanticOperationClass::Press,
            Self::Scroll => SemanticOperationClass::Scroll,
        }
    }
}

/// Fixed key recipes; arbitrary key strings and chords are impossible.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SemanticPressKey {
    /// Enter/Return.
    Enter,
    /// Escape.
    Escape,
    /// Space.
    Space,
    /// Tab in the ordinary forward direction.
    Tab,
    /// Up arrow.
    ArrowUp,
    /// Down arrow.
    ArrowDown,
    /// Left arrow.
    ArrowLeft,
    /// Right arrow.
    ArrowRight,
    /// Home.
    Home,
    /// End.
    End,
    /// Page up.
    PageUp,
    /// Page down.
    PageDown,
    /// Backspace.
    Backspace,
    /// Forward delete.
    Delete,
}

/// Closed scroll direction.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SemanticScrollDirection {
    /// Move toward smaller vertical coordinates.
    Up,
    /// Move toward larger vertical coordinates.
    Down,
    /// Move toward smaller horizontal coordinates.
    Left,
    /// Move toward larger horizontal coordinates.
    Right,
}

/// Closed scroll magnitude; arbitrary pixel deltas are impossible.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SemanticScrollAmount {
    /// One engine-defined line step.
    Line,
    /// Half of the current visible extent.
    HalfPage,
    /// One current visible extent.
    Page,
    /// Minimum movement needed to expose the target region.
    IntoView,
}

/// Small model-facing intent containing only opaque references and fixed data.
#[derive(Clone, Eq, PartialEq)]
pub enum SemanticActionIntent {
    /// Activate one observed target.
    Click {
        /// Opaque current target reference.
        target: SemanticReferenceId,
    },
    /// Replace the target's safe text.
    Fill {
        /// Opaque current target reference.
        target: SemanticReferenceId,
        /// Bounded plain replacement text.
        value: SemanticActionText,
    },
    /// Select an observed option within an observed select-like target.
    Select {
        /// Opaque combobox/listbox reference.
        target: SemanticReferenceId,
        /// Opaque option reference from the same frame and snapshot.
        option: SemanticReferenceId,
    },
    /// Dispatch one fixed key recipe.
    Press {
        /// Opaque current target reference.
        target: SemanticReferenceId,
        /// Fixed key recipe.
        key: SemanticPressKey,
    },
    /// Scroll one observed region using fixed direction and magnitude.
    Scroll {
        /// Opaque current scroll-region reference.
        target: SemanticReferenceId,
        /// Fixed direction.
        direction: SemanticScrollDirection,
        /// Fixed magnitude.
        amount: SemanticScrollAmount,
    },
}

impl SemanticActionIntent {
    /// Closed action class.
    pub const fn kind(&self) -> SemanticActionKind {
        match self {
            Self::Click { .. } => SemanticActionKind::Click,
            Self::Fill { .. } => SemanticActionKind::Fill,
            Self::Select { .. } => SemanticActionKind::Select,
            Self::Press { .. } => SemanticActionKind::Press,
            Self::Scroll { .. } => SemanticActionKind::Scroll,
        }
    }

    /// Primary target reference.
    pub const fn target(&self) -> SemanticReferenceId {
        match self {
            Self::Click { target }
            | Self::Fill { target, .. }
            | Self::Select { target, .. }
            | Self::Press { target, .. }
            | Self::Scroll { target, .. } => *target,
        }
    }
}

impl fmt::Debug for SemanticActionIntent {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut value = formatter.debug_struct("SemanticActionIntent");
        value
            .field("kind", &self.kind())
            .field("target", &self.target());
        match self {
            Self::Fill { value: text, .. } => {
                value.field("text", text);
            }
            Self::Select { option, .. } => {
                value.field("option", option);
            }
            Self::Press { key, .. } => {
                value.field("key", key);
            }
            Self::Scroll {
                direction, amount, ..
            } => {
                value.field("direction", direction).field("amount", amount);
            }
            Self::Click { .. } => {}
        }
        value.finish()
    }
}

/// Declared effect boundary. This declaration is untrusted until policy admits it.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SemanticEffectClass {
    /// Read-only page exploration with no durable write.
    Read,
    /// Reversible local page/form state not yet committed externally.
    LocalWrite,
    /// A durable write to an external service.
    ExternalWrite,
    /// A message, comment, email, or other communication.
    Communication,
    /// A purchase, paid subscription, or financial commitment.
    Purchase,
    /// A deletion or other destructive effect.
    Destructive,
    /// Upload, download, clipboard, popup, permission, credential, or OS boundary.
    CapabilityBoundary,
}

impl SemanticEffectClass {
    const fn requires_single_action(self) -> bool {
        matches!(
            self,
            Self::ExternalWrite
                | Self::Communication
                | Self::Purchase
                | Self::Destructive
                | Self::CapabilityBoundary
        )
    }
}

/// Whether a browser dialog must appear or disappear.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SemanticDialogState {
    /// A dialog is present.
    Present,
    /// A previously present dialog is absent.
    Absent,
}

/// Bounded quiet interval used only by a typed settle condition.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct SemanticMutationQuietPeriod(NonZeroU32);

impl SemanticMutationQuietPeriod {
    /// Validates a nonzero interval no longer than one second.
    pub const fn try_new(millis: u32) -> Result<Self, SemanticActionContractError> {
        match NonZeroU32::new(millis) {
            Some(value) if millis <= MAX_SEMANTIC_MUTATION_QUIET_MILLIS => Ok(Self(value)),
            _ => Err(SemanticActionContractError::QuietPeriod),
        }
    }

    /// Exact interval in milliseconds.
    pub const fn millis(self) -> u32 {
        self.0.get()
    }
}

/// One typed settle condition under the action's absolute deadline.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SemanticWaitCondition {
    /// Observe immediately after backend completion without an idle heuristic.
    Immediate,
    /// Wait for one exact native navigation commitment.
    NavigationCommitted,
    /// Wait for the current document to reach the adapter's fixed ready state.
    DocumentReady,
    /// Wait for the primary target to gain or lose one allowlisted state.
    TargetState {
        /// Allowlisted state.
        state: SemanticState,
        /// Required presence.
        present: bool,
    },
    /// Wait for the native-attested committed URL to change.
    UrlChanged,
    /// Wait for bounded semantic title state to change.
    TitleChanged,
    /// Wait for a browser/page dialog boundary.
    Dialog(SemanticDialogState),
    /// Wait for a semantic projection change.
    SemanticChange,
    /// Wait for bounded mutation quiet, never network idle.
    MutationQuiet(SemanticMutationQuietPeriod),
    /// Wait for an independently sampled scroll-position change.
    ScrollPositionChanged,
}

/// Independent effect proof required after the settle condition.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SemanticVerification {
    /// A previously absent visible DOM dialog appeared in the action frame.
    /// Requires bounded independent whole-frame samples before dispatch and
    /// after settlement; target focus or a scoped projection diff is not proof.
    PageDialogOpened,
    /// A previously present visible DOM dialog disappeared from the action frame.
    /// Requires the same bounded independent adjacent samples as opening proof.
    PageDialogClosed,
    /// Primary target gained or lost one allowlisted state.
    TargetState {
        /// Allowlisted state.
        state: SemanticState,
        /// Required presence.
        present: bool,
    },
    /// Safe target value exactly matches the bounded fill input.
    TargetValueMatchesInput,
    /// Safe target value changed from its pre-action value after a fixed key recipe.
    TargetValueChanged,
    /// Target selection exactly matches the bound option.
    TargetSelectionMatchesOption,
    /// Target selection changed after a fixed key recipe.
    TargetSelectionChanged,
    /// One exact navigation committed under the current context authority.
    NavigationCommitted,
    /// Dialog state matches the declared state.
    Dialog(SemanticDialogState),
    /// Scroll position changed without claiming unrelated page effects.
    ScrollPositionChanged,
    /// The action frame's content changed somewhere: a click whose effect
    /// lands elsewhere on the page. Proves a change, not which one.
    PageChanged,
}

/// Bounded per-action settle budget; execution converts it to one absolute deadline.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct SemanticSettleBudget(NonZeroU32);

impl SemanticSettleBudget {
    /// Validates a nonzero per-action budget at or below thirty seconds.
    pub const fn try_new(millis: u32) -> Result<Self, SemanticActionContractError> {
        match NonZeroU32::new(millis) {
            Some(value) if millis <= MAX_SEMANTIC_ACTION_SETTLE_MILLIS => Ok(Self(value)),
            _ => Err(SemanticActionContractError::SettleBudget),
        }
    }

    /// Exact relative budget used to derive an executor-owned absolute deadline.
    pub const fn millis(self) -> u32 {
        self.0.get()
    }
}

/// One model proposal. It is not policy or execution authority.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SemanticActionProposal {
    intent: SemanticActionIntent,
    effect: SemanticEffectClass,
    wait: SemanticWaitCondition,
    verification: SemanticVerification,
    settle_budget: SemanticSettleBudget,
}

impl SemanticActionProposal {
    /// Validates operation, settle, and verification compatibility.
    pub fn try_new(
        intent: SemanticActionIntent,
        effect: SemanticEffectClass,
        wait: SemanticWaitCondition,
        verification: SemanticVerification,
        settle_budget: SemanticSettleBudget,
    ) -> Result<Self, SemanticActionContractError> {
        if !verification_matches(intent.kind(), verification)
            || !wait_matches(wait, verification)
            || (matches!(
                verification,
                SemanticVerification::PageDialogOpened | SemanticVerification::PageDialogClosed
            ) && !matches!(
                effect,
                SemanticEffectClass::Read | SemanticEffectClass::LocalWrite
            ))
            || matches!(
                wait,
                SemanticWaitCondition::MutationQuiet(quiet)
                    if quiet.millis() > settle_budget.millis()
            )
        {
            #[cfg(feature = "probe-harness")]
            crate::probe_evidence_path::trace(format_args!("action-contract: kind={:?} effect={effect:?} wait={wait:?} verification={verification:?} settle_ms={}", intent.kind(), settle_budget.millis()));
            return Err(SemanticActionContractError::OutcomeContract);
        }
        Ok(Self {
            intent,
            effect,
            wait,
            verification,
            settle_budget,
        })
    }

    /// Proposed fixed action intent.
    pub const fn intent(&self) -> &SemanticActionIntent {
        &self.intent
    }

    /// Untrusted declared effect boundary.
    pub const fn effect(&self) -> SemanticEffectClass {
        self.effect
    }

    /// Typed settle condition.
    pub const fn wait(&self) -> SemanticWaitCondition {
        self.wait
    }

    /// Required independent verification.
    pub const fn verification(&self) -> SemanticVerification {
        self.verification
    }

    /// Per-action time budget.
    pub const fn settle_budget(&self) -> SemanticSettleBudget {
        self.settle_budget
    }
}

fn verification_matches(kind: SemanticActionKind, verification: SemanticVerification) -> bool {
    match kind {
        SemanticActionKind::Click => matches!(
            verification,
            SemanticVerification::PageDialogOpened
                | SemanticVerification::PageDialogClosed
                | SemanticVerification::PageChanged
                | SemanticVerification::TargetState { .. }
                | SemanticVerification::NavigationCommitted
                | SemanticVerification::Dialog(_)
        ),
        SemanticActionKind::Fill => verification == SemanticVerification::TargetValueMatchesInput,
        SemanticActionKind::Select => {
            verification == SemanticVerification::TargetSelectionMatchesOption
        }
        SemanticActionKind::Press => matches!(
            verification,
            SemanticVerification::TargetState { .. }
                | SemanticVerification::TargetValueChanged
                | SemanticVerification::TargetSelectionChanged
                | SemanticVerification::NavigationCommitted
                | SemanticVerification::PageChanged
                | SemanticVerification::Dialog(_)
        ),
        SemanticActionKind::Scroll => verification == SemanticVerification::ScrollPositionChanged,
    }
}

fn wait_matches(wait: SemanticWaitCondition, verification: SemanticVerification) -> bool {
    match verification {
        SemanticVerification::PageDialogOpened | SemanticVerification::PageDialogClosed => {
            matches!(
                wait,
                SemanticWaitCondition::Immediate | SemanticWaitCondition::MutationQuiet(_)
            )
        }
        SemanticVerification::PageChanged => matches!(
            wait,
            SemanticWaitCondition::Immediate
                | SemanticWaitCondition::SemanticChange
                | SemanticWaitCondition::MutationQuiet(_)
        ),
        SemanticVerification::NavigationCommitted => matches!(
            wait,
            SemanticWaitCondition::NavigationCommitted
                | SemanticWaitCondition::DocumentReady
                | SemanticWaitCondition::UrlChanged
        ),
        SemanticVerification::Dialog(state) => wait == SemanticWaitCondition::Dialog(state),
        SemanticVerification::TargetState { state, present } => {
            matches!(
                wait,
                SemanticWaitCondition::Immediate
                    | SemanticWaitCondition::SemanticChange
                    | SemanticWaitCondition::MutationQuiet(_)
            ) || wait == SemanticWaitCondition::TargetState { state, present }
        }
        SemanticVerification::ScrollPositionChanged => matches!(
            wait,
            SemanticWaitCondition::Immediate | SemanticWaitCondition::ScrollPositionChanged
        ),
        SemanticVerification::TargetValueMatchesInput
        | SemanticVerification::TargetValueChanged
        | SemanticVerification::TargetSelectionChanged
        | SemanticVerification::TargetSelectionMatchesOption => matches!(
            wait,
            SemanticWaitCondition::Immediate
                | SemanticWaitCondition::SemanticChange
                | SemanticWaitCondition::MutationQuiet(_)
                | SemanticWaitCondition::TargetState { .. }
        ),
    }
}

/// Refusal while constructing a proposed action outcome contract.
#[derive(Clone, Copy, Debug, Eq, Error, PartialEq)]
pub enum SemanticActionContractError {
    /// Mutation-quiet interval was zero or over the hard bound.
    #[error("semantic mutation quiet period is invalid")]
    QuietPeriod,
    /// Per-action settle budget was zero or over the hard bound.
    #[error("semantic action settle budget is invalid")]
    SettleBudget,
    /// Action kind, wait, and independent verification disagree.
    #[error("semantic action outcome contract is incompatible")]
    OutcomeContract,
}

#[derive(Clone, Eq, PartialEq)]
struct BoundNode {
    reference: SemanticReferenceId,
    node_key: SemanticNodeKey,
    frame: SemanticFrameJoin,
    snapshot: SemanticSnapshotGeneration,
    role: SemanticRole,
    value: Option<crate::SemanticValueSummary>,
    states: SemanticStates,
    operations: SemanticOperations,
    sensitivity: SemanticSensitivity,
    trust: SemanticTrust,
    geometry: Option<SemanticRect>,
    structural_digest: [u8; 32],
    page_dialog_ancestor: Option<SemanticNodeKey>,
    fields_complete: bool,
}

impl fmt::Debug for BoundNode {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("BoundNode")
            .field("reference", &self.reference)
            .field("node_key", &self.node_key)
            .field("frame", &self.frame)
            .field("snapshot", &self.snapshot)
            .field("role", &self.role)
            .field("has_value", &self.value.is_some())
            .field("states", &self.states)
            .field("operations", &self.operations)
            .field("sensitivity", &self.sensitivity)
            .field("trust", &self.trust)
            .field("geometry", &self.geometry)
            .field("structural_digest", &"[redacted]")
            .field("inside_page_dialog", &self.page_dialog_ancestor.is_some())
            .finish()
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
enum BoundActionIntent {
    Click {
        target: BoundNode,
    },
    Fill {
        target: BoundNode,
        value: SemanticActionText,
    },
    Select {
        target: BoundNode,
        option: Box<BoundNode>,
    },
    Press {
        target: BoundNode,
        key: SemanticPressKey,
    },
    Scroll {
        target: BoundNode,
        direction: SemanticScrollDirection,
        amount: SemanticScrollAmount,
    },
}

impl BoundActionIntent {
    const fn kind(&self) -> SemanticActionKind {
        match self {
            Self::Click { .. } => SemanticActionKind::Click,
            Self::Fill { .. } => SemanticActionKind::Fill,
            Self::Select { .. } => SemanticActionKind::Select,
            Self::Press { .. } => SemanticActionKind::Press,
            Self::Scroll { .. } => SemanticActionKind::Scroll,
        }
    }

    const fn target(&self) -> &BoundNode {
        match self {
            Self::Click { target }
            | Self::Fill { target, .. }
            | Self::Select { target, .. }
            | Self::Press { target, .. }
            | Self::Scroll { target, .. } => target,
        }
    }
}

/// One observation-bound action. It still carries no policy execution permit.
#[derive(Clone, Eq, PartialEq)]
pub struct SemanticBoundAction {
    batch: SemanticActionBatchId,
    source_observation: SemanticObservationId,
    source_observation_generation: SemanticObservationGeneration,
    ordinal: u8,
    intent: BoundActionIntent,
    effect: SemanticEffectClass,
    wait: SemanticWaitCondition,
    verification: SemanticVerification,
    settle_budget: SemanticSettleBudget,
}

impl SemanticBoundAction {
    pub(crate) const fn target_key(&self) -> SemanticNodeKey {
        self.intent.target().node_key
    }

    /// Exact model-proposed batch that owns this action.
    pub const fn batch(&self) -> SemanticActionBatchId {
        self.batch
    }

    /// Observation whose opaque references were consumed at binding.
    pub const fn source_observation(&self) -> SemanticObservationId {
        self.source_observation
    }

    /// Progressive observation generation consumed at binding.
    pub const fn source_observation_generation(&self) -> SemanticObservationGeneration {
        self.source_observation_generation
    }

    /// One-based position in the exact batch.
    pub const fn ordinal(&self) -> u8 {
        self.ordinal
    }

    /// Closed action class.
    pub const fn kind(&self) -> SemanticActionKind {
        self.intent.kind()
    }

    /// Original opaque target reference.
    pub const fn target_reference(&self) -> SemanticReferenceId {
        self.intent.target().reference
    }

    /// Bound exact action frame.
    pub const fn frame(&self) -> &SemanticFrameJoin {
        &self.intent.target().frame
    }

    /// Exact source snapshot generation.
    pub const fn snapshot_generation(&self) -> SemanticSnapshotGeneration {
        self.intent.target().snapshot
    }

    /// Target role observed when the proposal was bound.
    pub const fn target_role(&self) -> SemanticRole {
        self.intent.target().role
    }

    /// Target states observed when the proposal was bound.
    pub const fn target_states(&self) -> SemanticStates {
        self.intent.target().states
    }

    /// Sensitivity of the exact target at observation binding.
    pub const fn target_sensitivity(&self) -> SemanticSensitivity {
        self.intent.target().sensitivity
    }

    /// Trust of the exact target at observation binding.
    pub const fn target_trust(&self) -> SemanticTrust {
        self.intent.target().trust
    }

    /// Geometry presence/value observed for later native revalidation.
    pub const fn target_geometry(&self) -> Option<SemanticRect> {
        self.intent.target().geometry
    }

    /// Declared effect boundary, still requiring policy admission.
    pub const fn effect(&self) -> SemanticEffectClass {
        self.effect
    }

    /// Typed settle condition.
    pub const fn wait(&self) -> SemanticWaitCondition {
        self.wait
    }

    /// Independent post-settle verification requirement.
    pub const fn verification(&self) -> SemanticVerification {
        self.verification
    }

    /// Per-action deadline budget.
    pub const fn settle_budget(&self) -> SemanticSettleBudget {
        self.settle_budget
    }

    /// Bounded fill text when this is a fill action.
    pub const fn fill_text(&self) -> Option<&SemanticActionText> {
        match &self.intent {
            BoundActionIntent::Fill { value, .. } => Some(value),
            _ => None,
        }
    }

    /// Exact option reference when this is a select action.
    pub const fn option_reference(&self) -> Option<SemanticReferenceId> {
        match &self.intent {
            BoundActionIntent::Select { option, .. } => Some(option.reference),
            _ => None,
        }
    }

    /// Fixed key recipe when this is a press action.
    pub const fn press_key(&self) -> Option<SemanticPressKey> {
        match &self.intent {
            BoundActionIntent::Press { key, .. } => Some(*key),
            _ => None,
        }
    }

    /// Fixed direction and magnitude when this is a scroll action.
    pub const fn scroll_recipe(&self) -> Option<(SemanticScrollDirection, SemanticScrollAmount)> {
        match &self.intent {
            BoundActionIntent::Scroll {
                direction, amount, ..
            } => Some((*direction, *amount)),
            _ => None,
        }
    }

    /// Revalidates stable identity and structural semantics in a fresh snapshot.
    ///
    /// This does not prove visibility, occlusion, policy, or backend success;
    /// those remain mandatory later pipeline stages.
    pub fn revalidate(
        &self,
        current: &SemanticSnapshot,
    ) -> Result<(), SemanticActionRevalidationError> {
        let (target_index, _) = revalidate_node(
            self.intent.target(),
            current,
            Some(self.kind().operation()),
            matches!(self.intent, BoundActionIntent::Fill { .. }),
        )?;
        if self.verification == SemanticVerification::PageDialogClosed {
            let Some(dialog_key) = self.intent.target().page_dialog_ancestor else {
                return Err(SemanticActionRevalidationError::TargetChanged);
            };
            let Some(dialog_index) = current
                .nodes()
                .iter()
                .position(|node| node.key() == dialog_key && node.role() == SemanticRole::Dialog)
            else {
                return Err(SemanticActionRevalidationError::TargetChanged);
            };
            if !is_descendant(current, target_index, dialog_index) {
                return Err(SemanticActionRevalidationError::TargetChanged);
            }
        }
        if let BoundActionIntent::Select { option, .. } = &self.intent {
            let (option_index, option_node) = revalidate_node(option, current, None, false)
                .map_err(|_| SemanticActionRevalidationError::SelectionTarget)?;
            if option_node.role() != SemanticRole::Option
                || !is_descendant(current, option_index, target_index)
            {
                return Err(SemanticActionRevalidationError::SelectionTarget);
            }
        }
        Ok(())
    }

    /// Revalidates and checkpoints this action against its actual pre-execution snapshot.
    ///
    /// A batch must prepare one action at a time after the prior action has
    /// settled and verified. The returned value still carries no policy permit
    /// or native execution authority.
    pub fn prepare(
        &self,
        current: &SemanticSnapshot,
    ) -> Result<SemanticPreparedAction, SemanticActionPreparationError> {
        if !self.intent.target().fields_complete
            || !(current.has_complete_node_fields(self.target_key())
                || (self.kind() == SemanticActionKind::Scroll
                    && complete_scroll_target(current, self.target_key()))
                || (self.kind() == SemanticActionKind::Click
                    && self.effect() == SemanticEffectClass::Read
                    && matches!(
                        self.verification(),
                        SemanticVerification::TargetState {
                            state: SemanticState::Expanded,
                            ..
                        }
                    )
                    && complete_disclosure_target(current, self.target_key())))
            || matches!(&self.intent, BoundActionIntent::Select { option, .. }
                if !option.fields_complete || !current.has_complete_node_fields(option.node_key))
        {
            return Err(SemanticActionPreparationError::IncompleteSnapshot);
        }
        self.revalidate(current)
            .map_err(SemanticActionPreparationError::Revalidation)?;
        let target = current
            .nodes()
            .iter()
            .find(|node| node.key() == self.target_key())
            .ok_or(SemanticActionPreparationError::Revalidation(
                SemanticActionRevalidationError::TargetMissing,
            ))?;
        let option_states = match &self.intent {
            BoundActionIntent::Select { option, .. } => Some(
                current
                    .nodes()
                    .iter()
                    .find(|node| node.key() == option.node_key)
                    .ok_or(SemanticActionPreparationError::Revalidation(
                        SemanticActionRevalidationError::SelectionTarget,
                    ))?
                    .states(),
            ),
            _ => None,
        };
        validate_prepared_baseline(self, target.value(), target.states(), option_states)?;
        // Exact Fill verification needs an observed starting value. Refuse
        // unknown state here, before policy authorization or native mutation.
        if self.verification() == SemanticVerification::TargetValueMatchesInput {
            exact_fill_value(target.value())
                .map_err(SemanticActionPreparationError::Revalidation)?;
        }

        let target_value = target.value().cloned();
        let target_states = target.states();
        let target_geometry = target.geometry();
        let target_runtime_descriptor = runtime_descriptor(target);
        let option_runtime_descriptor = match &self.intent {
            BoundActionIntent::Select { option, .. } => Some(runtime_descriptor(
                current
                    .nodes()
                    .iter()
                    .find(|node| node.key() == option.node_key)
                    .ok_or(SemanticActionPreparationError::Revalidation(
                        SemanticActionRevalidationError::SelectionTarget,
                    ))?,
            )),
            _ => None,
        };
        let checkpoint_invocation = current.invocation();
        let checkpoint_snapshot = current.generation();
        let mut guard = prepared_guard(
            self,
            checkpoint_invocation,
            checkpoint_snapshot,
            target_value.as_ref(),
            target_states,
            option_states,
        );
        let option_identity = match &self.intent {
            BoundActionIntent::Select { option, .. } => current
                .nodes()
                .iter()
                .find(|node| node.key() == option.node_key)
                .and_then(|node| node.approval_identity()),
            _ => None,
        };
        let approval_binding = crate::SemanticApprovalBinding::new(
            target.approval_identity(),
            option_identity,
            self.kind() == SemanticActionKind::Select,
        );
        if let Some(binding) = approval_binding {
            let mut sealed = Sha256::new();
            sealed.update(b"ZEPHIUM-PREPARED-APPROVAL-1\0");
            sealed.update(guard);
            sealed.update(binding.guard_bytes());
            guard = sealed.finalize().into();
        }
        Ok(SemanticPreparedAction {
            action: self.clone(),
            approval_binding,
            checkpoint_invocation,
            checkpoint_snapshot,
            target_value,
            target_states,
            target_geometry,
            option_states,
            target_runtime_descriptor,
            option_runtime_descriptor,
            page_digest: page_digest(current),
            guard,
        })
    }

    pub(crate) fn verification_guard(&self) -> [u8; 32] {
        let mut hasher = Sha256::new();
        hasher.update(b"ZEPHIUM-SEMANTIC-VERIFICATION-GUARD-1\0");
        hasher.update(self.batch.get().to_be_bytes());
        hasher.update(self.source_observation.get().to_be_bytes());
        hasher.update(self.source_observation_generation.get().to_be_bytes());
        hash_frame(&mut hasher, self.frame());
        hasher.update([self.ordinal]);
        hasher.update(self.target_key().get().to_be_bytes());
        hasher.update(self.snapshot_generation().get().to_be_bytes());
        hash_effect(&mut hasher, self.effect);
        hash_wait(&mut hasher, self.wait);
        hash_verification(&mut hasher, self.verification);
        hasher.update(self.settle_budget.millis().to_be_bytes());
        match &self.intent {
            BoundActionIntent::Click { .. } => hasher.update([1]),
            BoundActionIntent::Fill { value, .. } => {
                hasher.update([2]);
                hasher.update((value.len() as u64).to_be_bytes());
                hasher.update(value.as_str().as_bytes());
            }
            BoundActionIntent::Select { option, .. } => {
                hasher.update([3]);
                hasher.update(option.node_key.get().to_be_bytes());
            }
            BoundActionIntent::Press { key, .. } => {
                hasher.update([4, press_key_code(*key)]);
            }
            BoundActionIntent::Scroll {
                direction, amount, ..
            } => {
                hasher.update([
                    5,
                    scroll_direction_code(*direction),
                    scroll_amount_code(*amount),
                ]);
            }
        }
        hasher.finalize().into()
    }
}

/// One structurally revalidated action checkpointed immediately before execution.
///
/// At most the currently executing action needs to be prepared. This keeps the
/// rolling batch state O(1) while preserving the original bound contract.
#[derive(Eq, PartialEq)]
pub struct SemanticPreparedAction {
    action: SemanticBoundAction,
    approval_binding: Option<crate::SemanticApprovalBinding>,
    checkpoint_invocation: SemanticInvocationId,
    checkpoint_snapshot: SemanticSnapshotGeneration,
    target_value: Option<SemanticValueSummary>,
    target_states: SemanticStates,
    target_geometry: Option<SemanticRect>,
    option_states: Option<SemanticStates>,
    target_runtime_descriptor: SemanticActionRuntimeDescriptor,
    option_runtime_descriptor: Option<SemanticActionRuntimeDescriptor>,
    page_digest: [u8; 32],
    guard: [u8; 32],
}

impl SemanticPreparedAction {
    /// Private native target/option continuity at the exact prepared checkpoint.
    /// This is identity evidence, never an authorization by itself.
    pub const fn approval_binding(&self) -> Option<crate::SemanticApprovalBinding> {
        self.approval_binding
    }

    /// Resolves the private native target in the exact prepared checkpoint,
    /// independently of model-facing reference rebasing.
    pub fn target_node<'a>(
        &self,
        snapshot: &'a SemanticSnapshot,
    ) -> Option<&'a crate::SemanticNode> {
        (snapshot.frame() == self.frame()
            && snapshot.invocation() == self.checkpoint_invocation
            && snapshot.generation() == self.checkpoint_snapshot)
            .then(|| {
                snapshot
                    .nodes()
                    .iter()
                    .find(|node| node.key() == self.target_key())
            })
            .flatten()
    }
    /// Resolves the bound selected option in that same exact checkpoint.
    pub fn option_node<'a>(
        &self,
        snapshot: &'a SemanticSnapshot,
    ) -> Option<&'a crate::SemanticNode> {
        self.target_node(snapshot)?;
        let key = self.option_key()?;
        snapshot.nodes().iter().find(|node| node.key() == key)
    }

    /// Content digest of the frame this action was prepared on.
    pub(crate) const fn page_digest(&self) -> [u8; 32] {
        self.page_digest
    }

    /// Whether a snapshot of this action's frame still shows the page as it
    /// was when the action was prepared: roles, names, text, links, values
    /// and states, not keys, geometry or focus.
    pub fn page_unchanged(&self, snapshot: &SemanticSnapshot) -> bool {
        snapshot.frame() == self.frame() && page_digest(snapshot) == self.page_digest
    }

    /// Original observation-bound action contract.
    pub const fn bound_action(&self) -> &SemanticBoundAction {
        &self.action
    }

    /// Exact model-proposed batch that owns this action.
    pub const fn batch(&self) -> SemanticActionBatchId {
        self.action.batch()
    }

    /// Observation whose opaque references were consumed at binding.
    pub const fn source_observation(&self) -> SemanticObservationId {
        self.action.source_observation()
    }

    /// Progressive observation generation consumed at binding.
    pub const fn source_observation_generation(&self) -> SemanticObservationGeneration {
        self.action.source_observation_generation()
    }

    /// One-based position in the exact batch.
    pub const fn ordinal(&self) -> u8 {
        self.action.ordinal()
    }

    /// Closed action class.
    pub const fn kind(&self) -> SemanticActionKind {
        self.action.kind()
    }

    /// Opaque target reference actually bound into this action.
    pub const fn target_reference(&self) -> SemanticReferenceId {
        self.action.target_reference()
    }

    /// Independently checked effect declaration, still not policy authority.
    pub const fn effect(&self) -> SemanticEffectClass {
        self.action.effect()
    }

    /// Sensitivity of the exact target at observation binding.
    pub const fn target_sensitivity(&self) -> SemanticSensitivity {
        self.action.target_sensitivity()
    }

    /// Trust of the exact target at observation binding.
    pub const fn target_trust(&self) -> SemanticTrust {
        self.action.target_trust()
    }

    /// Exact action frame at the pre-execution checkpoint.
    pub const fn frame(&self) -> &SemanticFrameJoin {
        self.action.frame()
    }

    /// Native invocation that produced the pre-execution checkpoint.
    pub const fn checkpoint_invocation(&self) -> SemanticInvocationId {
        self.checkpoint_invocation
    }

    /// Snapshot generation immediately before this action executes.
    pub const fn checkpoint_snapshot(&self) -> SemanticSnapshotGeneration {
        self.checkpoint_snapshot
    }

    /// Typed settle condition.
    pub const fn wait(&self) -> SemanticWaitCondition {
        self.action.wait()
    }

    /// Required independent postcondition.
    pub const fn verification(&self) -> SemanticVerification {
        self.action.verification()
    }

    /// Per-action absolute-deadline budget.
    pub const fn settle_budget(&self) -> SemanticSettleBudget {
        self.action.settle_budget()
    }

    /// Fresh geometry sampled by the exact pre-execution snapshot.
    pub const fn target_geometry(&self) -> Option<SemanticRect> {
        self.target_geometry
    }

    /// Bounded exact fill text, when this is a fill action.
    pub const fn fill_text(&self) -> Option<&SemanticActionText> {
        self.action.fill_text()
    }

    /// Fixed scroll recipe, when this is a scroll action.
    pub const fn scroll_recipe(&self) -> Option<(SemanticScrollDirection, SemanticScrollAmount)> {
        self.action.scroll_recipe()
    }

    pub(crate) const fn target_key(&self) -> SemanticNodeKey {
        self.action.target_key()
    }

    pub(crate) fn has_complete_snapshot_evidence(&self, current: &SemanticSnapshot) -> bool {
        current.has_complete_node_fields(self.target_key())
            && self
                .option_key()
                .is_none_or(|key| current.has_complete_node_fields(key))
    }

    pub(crate) const fn option_key(&self) -> Option<SemanticNodeKey> {
        match &self.action.intent {
            BoundActionIntent::Select { option, .. } => Some(option.node_key),
            _ => None,
        }
    }

    pub(crate) const fn target_value(&self) -> Option<&SemanticValueSummary> {
        self.target_value.as_ref()
    }

    pub(crate) const fn target_states(&self) -> SemanticStates {
        self.target_states
    }

    pub(crate) const fn target_runtime_descriptor(&self) -> &SemanticActionRuntimeDescriptor {
        &self.target_runtime_descriptor
    }

    pub(crate) const fn option_runtime_descriptor(
        &self,
    ) -> Option<&SemanticActionRuntimeDescriptor> {
        self.option_runtime_descriptor.as_ref()
    }

    pub(crate) fn verification_target<'a>(
        &self,
        current: &'a SemanticSnapshot,
    ) -> Result<(usize, &'a crate::SemanticNode), SemanticActionRevalidationError> {
        verification_node_at(
            self.action.intent.target(),
            self.checkpoint_snapshot,
            current,
        )
    }

    /// Returns the exact private form value before and after one fill.
    ///
    /// Both values must be explicitly observed text. Missing values are unknown,
    /// including on eligible fill controls, and cannot prove a value transition.
    pub(crate) fn verification_fill_values<'action, 'snapshot>(
        &'action self,
        current: &'snapshot SemanticSnapshot,
    ) -> Result<(&'action str, &'snapshot str), SemanticActionRevalidationError> {
        if self.kind() != SemanticActionKind::Fill
            || !fill_role(self.bound_action().target_role())
            || self.target_sensitivity() == SemanticSensitivity::Secret
        {
            return Err(SemanticActionRevalidationError::OperationDenied);
        }
        let (_, target) = self.verification_target(current)?;
        if !fill_role(target.role()) || !target.operations().contains(SemanticOperationClass::Fill)
        {
            return Err(SemanticActionRevalidationError::OperationDenied);
        }
        let before = exact_fill_value(self.target_value())?;
        let after = exact_fill_value(target.value())?;
        Ok((before, after))
    }

    pub(crate) fn verification_option<'a>(
        &self,
        current: &'a SemanticSnapshot,
        target_index: usize,
    ) -> Result<(usize, &'a crate::SemanticNode), SemanticActionRevalidationError> {
        let BoundActionIntent::Select { option, .. } = &self.action.intent else {
            return Err(SemanticActionRevalidationError::SelectionTarget);
        };
        let (option_index, option_node) =
            verification_node_at(option, self.checkpoint_snapshot, current)?;
        if option_node.role() != SemanticRole::Option
            || !is_descendant(current, option_index, target_index)
        {
            return Err(SemanticActionRevalidationError::SelectionTarget);
        }
        Ok((option_index, option_node))
    }

    pub(crate) const fn verification_guard(&self) -> [u8; 32] {
        self.guard
    }
}

/// Roles whose fill the exact-value proof can verify; a number field's
/// value reads back as the text that was set.
const fn fill_role(role: SemanticRole) -> bool {
    matches!(
        role,
        SemanticRole::Textbox
            | SemanticRole::Searchbox
            | SemanticRole::Combobox
            | SemanticRole::Spinbutton
    )
}

fn exact_fill_value(
    value: Option<&SemanticValueSummary>,
) -> Result<&str, SemanticActionRevalidationError> {
    match value {
        Some(SemanticValueSummary::Text(value)) => Ok(value.as_str()),
        None => Err(SemanticActionRevalidationError::TargetChanged),
        Some(SemanticValueSummary::Redacted) => {
            Err(SemanticActionRevalidationError::CredentialBoundary)
        }
        Some(SemanticValueSummary::Boolean(_) | SemanticValueSummary::Ordinal(_)) => {
            Err(SemanticActionRevalidationError::TargetChanged)
        }
    }
}

impl fmt::Debug for SemanticPreparedAction {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("SemanticPreparedAction")
            .field("action", &self.action)
            .field("checkpoint_invocation", &self.checkpoint_invocation)
            .field("checkpoint_snapshot", &self.checkpoint_snapshot)
            .field("has_target_value", &self.target_value.is_some())
            .field("target_states", &self.target_states)
            .field("has_target_geometry", &self.target_geometry.is_some())
            .field("has_option_states", &self.option_states.is_some())
            .field("guard", &"[redacted]")
            .finish()
    }
}

impl fmt::Debug for SemanticBoundAction {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("SemanticBoundAction")
            .field("batch", &self.batch)
            .field("source_observation", &self.source_observation)
            .field(
                "source_observation_generation",
                &self.source_observation_generation,
            )
            .field("ordinal", &self.ordinal)
            .field("kind", &self.kind())
            .field("target", self.intent.target())
            .field("effect", &self.effect)
            .field("wait", &self.wait)
            .field("verification", &self.verification)
            .field("settle_budget", &self.settle_budget)
            .field("fill_bytes", &self.fill_text().map(SemanticActionText::len))
            .finish()
    }
}

/// Complete bounded action proposal bound to one exact current observation.
#[derive(Clone, Eq, PartialEq)]
pub struct SemanticActionBatch {
    id: SemanticActionBatchId,
    context: ContextJoin,
    observation: SemanticObservationId,
    observation_generation: SemanticObservationGeneration,
    effect: SemanticEffectClass,
    actions: Vec<SemanticBoundAction>,
    settle_millis: u32,
    text_bytes: usize,
}

impl SemanticActionBatch {
    /// Resolves all opaque references against an exact current frame cohort.
    ///
    /// Successful binding is a pre-policy guard only. It does not authorize or
    /// execute input. The current frame cohort must come from trusted native
    /// lifecycle state and match the observation exactly.
    pub fn bind(
        id: SemanticActionBatchId,
        observation: &SemanticObservation,
        current_frames: &[SemanticFrameJoin],
        proposals: Vec<SemanticActionProposal>,
    ) -> Result<Self, SemanticActionBindingError> {
        if proposals.is_empty() {
            return Err(SemanticActionBindingError::Empty);
        }
        if proposals.len() > MAX_SEMANTIC_ACTIONS_PER_BATCH {
            return Err(SemanticActionBindingError::ActionLimit);
        }
        validate_current_frames(observation, current_frames)?;

        let effect = proposals[0].effect;
        if proposals.iter().any(|proposal| proposal.effect != effect) {
            return Err(SemanticActionBindingError::MixedEffectBoundary);
        }
        if effect.requires_single_action() && proposals.len() != 1 {
            return Err(SemanticActionBindingError::EffectBatchLimit);
        }

        let mut actions = Vec::with_capacity(proposals.len());
        let mut settle_millis = 0_u32;
        let mut text_bytes = 0_usize;
        for (index, proposal) in proposals.into_iter().enumerate() {
            settle_millis = settle_millis
                .checked_add(proposal.settle_budget.millis())
                .ok_or(SemanticActionBindingError::SettleLimit)?;
            if settle_millis > MAX_SEMANTIC_ACTION_BATCH_SETTLE_MILLIS {
                return Err(SemanticActionBindingError::SettleLimit);
            }
            let ordinal =
                u8::try_from(index + 1).map_err(|_| SemanticActionBindingError::ActionLimit)?;
            let intent = bind_intent(
                observation,
                current_frames,
                proposal.intent,
                &mut text_bytes,
            )?;
            validate_bound_verification(&intent, proposal.verification)?;
            validate_verification_baseline(&intent, proposal.verification)?;
            actions.push(SemanticBoundAction {
                batch: id,
                source_observation: observation.request().id(),
                source_observation_generation: observation.request().generation(),
                ordinal,
                intent,
                effect: proposal.effect,
                wait: proposal.wait,
                verification: proposal.verification,
                settle_budget: proposal.settle_budget,
            });
        }

        Ok(Self {
            id,
            context: observation.request().context(),
            observation: observation.request().id(),
            observation_generation: observation.request().generation(),
            effect,
            actions,
            settle_millis,
            text_bytes,
        })
    }

    /// Exact batch identity.
    pub const fn id(&self) -> SemanticActionBatchId {
        self.id
    }

    /// Exact context/document/cancellation authority represented at binding.
    pub const fn context(&self) -> ContextJoin {
        self.context
    }

    /// Observation request whose opaque references were consumed.
    pub const fn observation(&self) -> SemanticObservationId {
        self.observation
    }

    /// Progressive observation generation whose references were consumed.
    pub const fn observation_generation(&self) -> SemanticObservationGeneration {
        self.observation_generation
    }

    /// Homogeneous effect boundary for the complete batch.
    pub const fn effect(&self) -> SemanticEffectClass {
        self.effect
    }

    /// Sequential bound actions.
    pub fn actions(&self) -> &[SemanticBoundAction] {
        &self.actions
    }

    /// Aggregate relative budget from which execution derives one absolute deadline.
    pub const fn settle_millis(&self) -> u32 {
        self.settle_millis
    }

    /// Aggregate exact fill-text bytes.
    pub const fn text_bytes(&self) -> usize {
        self.text_bytes
    }
}

fn validate_bound_verification(
    intent: &BoundActionIntent,
    verification: SemanticVerification,
) -> Result<(), SemanticActionBindingError> {
    let compatible = match (intent, verification) {
        (BoundActionIntent::Press { target, .. }, SemanticVerification::TargetValueChanged) => {
            matches!(
                target.role,
                SemanticRole::Textbox
                    | SemanticRole::Searchbox
                    | SemanticRole::Spinbutton
                    | SemanticRole::Slider
            )
        }
        (BoundActionIntent::Press { target, .. }, SemanticVerification::TargetSelectionChanged) => {
            matches!(
                target.role,
                SemanticRole::Combobox
                    | SemanticRole::Listbox
                    | SemanticRole::Option
                    | SemanticRole::Radio
                    | SemanticRole::Tab
                    | SemanticRole::MenuItem
            )
        }
        (BoundActionIntent::Press { target, key }, SemanticVerification::NavigationCommitted) => {
            matches!(target.role, SemanticRole::Link | SemanticRole::Button)
                && matches!(key, SemanticPressKey::Enter | SemanticPressKey::Space)
        }
        (BoundActionIntent::Press { key, .. }, SemanticVerification::Dialog(_)) => matches!(
            key,
            SemanticPressKey::Enter | SemanticPressKey::Escape | SemanticPressKey::Space
        ),
        (intent, SemanticVerification::PageDialogClosed) => {
            intent.target().page_dialog_ancestor.is_some()
        }
        _ => true,
    };
    if compatible {
        Ok(())
    } else {
        Err(SemanticActionBindingError::OutcomeContract)
    }
}

fn validate_verification_baseline(
    intent: &BoundActionIntent,
    verification: SemanticVerification,
) -> Result<(), SemanticActionBindingError> {
    let already_satisfied = match verification {
        SemanticVerification::TargetState { state, present } => {
            intent.target().states.contains(state) == present
        }
        SemanticVerification::TargetValueMatchesInput => match intent {
            BoundActionIntent::Fill { target, value } => {
                projected_value_matches(target.value.as_ref(), value)
            }
            _ => false,
        },
        SemanticVerification::TargetSelectionMatchesOption => match intent {
            BoundActionIntent::Select { option, .. } => {
                option.states.contains(SemanticState::Selected)
            }
            _ => false,
        },
        SemanticVerification::PageDialogOpened
        | SemanticVerification::PageDialogClosed
        | SemanticVerification::TargetValueChanged
        | SemanticVerification::TargetSelectionChanged
        | SemanticVerification::NavigationCommitted
        | SemanticVerification::Dialog(_)
        | SemanticVerification::PageChanged
        | SemanticVerification::ScrollPositionChanged => false,
    };
    if already_satisfied {
        Err(SemanticActionBindingError::OutcomeAlreadySatisfied)
    } else {
        Ok(())
    }
}

fn validate_prepared_baseline(
    action: &SemanticBoundAction,
    target_value: Option<&SemanticValueSummary>,
    target_states: SemanticStates,
    option_states: Option<SemanticStates>,
) -> Result<(), SemanticActionPreparationError> {
    let already_satisfied = match action.verification() {
        SemanticVerification::TargetState { state, present } => {
            target_states.contains(state) == present
        }
        SemanticVerification::TargetValueMatchesInput => action
            .fill_text()
            .is_some_and(|expected| projected_value_matches(target_value, expected)),
        SemanticVerification::TargetSelectionMatchesOption => {
            option_states.is_some_and(|states| states.contains(SemanticState::Selected))
        }
        SemanticVerification::PageDialogOpened
        | SemanticVerification::PageDialogClosed
        | SemanticVerification::TargetValueChanged
        | SemanticVerification::TargetSelectionChanged
        | SemanticVerification::NavigationCommitted
        | SemanticVerification::Dialog(_)
        | SemanticVerification::PageChanged
        | SemanticVerification::ScrollPositionChanged => false,
    };
    if already_satisfied {
        Err(SemanticActionPreparationError::OutcomeAlreadySatisfied)
    } else {
        Ok(())
    }
}

fn projected_value_matches(
    current: Option<&SemanticValueSummary>,
    expected: &SemanticActionText,
) -> bool {
    match current {
        Some(SemanticValueSummary::Text(current)) => {
            fill_value_matches(current.as_str(), expected.as_str())
        }
        None
        | Some(
            SemanticValueSummary::Redacted
            | SemanticValueSummary::Boolean(_)
            | SemanticValueSummary::Ordinal(_),
        ) => false,
    }
}

/// A field holds the filled text exactly. A multi-line text also matches when
/// only its line breaks are represented differently: a rich editor keeps a
/// block per line, an empty line as a block holding a break, and may add a
/// trailing break or turn a space into a non-breaking one.
pub(crate) fn fill_value_matches(value: &str, expected: &str) -> bool {
    value == expected
        || (value.contains(['\n', '\r']) || expected.contains(['\n', '\r']))
            && value.split_whitespace().eq(expected.split_whitespace())
}

impl fmt::Debug for SemanticActionBatch {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("SemanticActionBatch")
            .field("id", &self.id)
            .field("context", &self.context)
            .field("observation", &self.observation)
            .field("observation_generation", &self.observation_generation)
            .field("effect", &self.effect)
            .field("action_count", &self.actions.len())
            .field("settle_millis", &self.settle_millis)
            .field("text_bytes", &self.text_bytes)
            .finish()
    }
}

fn validate_current_frames(
    observation: &SemanticObservation,
    current_frames: &[SemanticFrameJoin],
) -> Result<(), SemanticActionBindingError> {
    if current_frames.is_empty()
        || current_frames.len() > MAX_SEMANTIC_FRAMES
        || current_frames.len() != observation.frames().len()
    {
        return Err(SemanticActionBindingError::CurrentFrameCohort);
    }
    let context = observation.request().context();
    let mut ids = Vec::<FrameId>::with_capacity(current_frames.len());
    for frame in current_frames {
        if frame.context() != context || ids.contains(&frame.frame()) {
            return Err(SemanticActionBindingError::CurrentFrameCohort);
        }
        ids.push(frame.frame());
    }
    if !ids.contains(&FrameId::MAIN) {
        return Err(SemanticActionBindingError::CurrentFrameCohort);
    }
    for snapshot in observation.frames() {
        current_frame(current_frames, snapshot.frame())?;
    }
    Ok(())
}

fn bind_intent(
    observation: &SemanticObservation,
    current_frames: &[SemanticFrameJoin],
    intent: SemanticActionIntent,
    text_bytes: &mut usize,
) -> Result<BoundActionIntent, SemanticActionBindingError> {
    match intent {
        SemanticActionIntent::Click { target } => Ok(BoundActionIntent::Click {
            target: bind_target(
                observation,
                current_frames,
                target,
                SemanticOperationClass::Click,
            )?,
        }),
        SemanticActionIntent::Fill { target, value } => {
            let target = bind_target(
                observation,
                current_frames,
                target,
                SemanticOperationClass::Fill,
            )?;
            if target.role == SemanticRole::Password
                || target.sensitivity == SemanticSensitivity::Secret
            {
                return Err(SemanticActionBindingError::CredentialBoundary);
            }
            // The exact-value proof compares against the observed value. A
            // field whose value was not observed is refused before anything
            // is typed, not left applied and unverified after.
            if !fill_role(target.role) {
                return Err(SemanticActionBindingError::OutcomeContract);
            }
            if !matches!(target.value, Some(crate::SemanticValueSummary::Text(_))) {
                return Err(SemanticActionBindingError::ValueUnobserved);
            }
            *text_bytes = text_bytes
                .checked_add(value.len())
                .ok_or(SemanticActionBindingError::TextLimit)?;
            if *text_bytes > MAX_SEMANTIC_ACTION_BATCH_TEXT_BYTES {
                return Err(SemanticActionBindingError::TextLimit);
            }
            Ok(BoundActionIntent::Fill { target, value })
        }
        SemanticActionIntent::Select { target, option } => {
            let target_node = bind_target(
                observation,
                current_frames,
                target,
                SemanticOperationClass::Select,
            )?;
            if !matches!(
                target_node.role,
                SemanticRole::Combobox | SemanticRole::Listbox
            ) {
                return Err(SemanticActionBindingError::SelectionTarget);
            }
            let (option_frame, option_index, option_node) = locate_node(observation, option)?;
            let current_frame = current_frame(current_frames, option_frame.frame())?;
            observation
                .resolve_node(option, current_frame)
                .map_err(SemanticActionBindingError::Reference)?;
            let (target_frame, target_index, _) = locate_node(observation, target)?;
            if option_frame.frame() != target_frame.frame()
                || option_node.role() != SemanticRole::Option
                || !is_descendant(option_frame, option_index, target_index)
            {
                return Err(SemanticActionBindingError::SelectionTarget);
            }
            let option_node = bind_node(option_frame, option_node);
            Ok(BoundActionIntent::Select {
                target: target_node,
                option: Box::new(option_node),
            })
        }
        SemanticActionIntent::Press { target, key } => Ok(BoundActionIntent::Press {
            target: bind_target(
                observation,
                current_frames,
                target,
                SemanticOperationClass::Press,
            )?,
            key,
        }),
        SemanticActionIntent::Scroll {
            target,
            direction,
            amount,
        } => {
            let target = bind_target(
                observation,
                current_frames,
                target,
                SemanticOperationClass::Scroll,
            )?;
            if target.role == SemanticRole::Button && amount != SemanticScrollAmount::IntoView {
                return Err(SemanticActionBindingError::OutcomeContract);
            }
            Ok(BoundActionIntent::Scroll {
                target,
                direction,
                amount,
            })
        }
    }
}

fn bind_target(
    observation: &SemanticObservation,
    current_frames: &[SemanticFrameJoin],
    reference: SemanticReferenceId,
    operation: SemanticOperationClass,
) -> Result<BoundNode, SemanticActionBindingError> {
    let (snapshot, _, node) = locate_node(observation, reference)?;
    let current = current_frame(current_frames, snapshot.frame())?;
    observation
        .resolve(reference, current, operation)
        .map_err(SemanticActionBindingError::Reference)?;
    let mut bound = bind_node(snapshot, node);
    if (operation == SemanticOperationClass::Scroll && complete_scroll_target(snapshot, node.key()))
        || (operation == SemanticOperationClass::Click
            && complete_disclosure_target(snapshot, node.key()))
    {
        bound.fields_complete = true;
    }
    Ok(bound)
}

fn current_frame<'a>(
    current_frames: &'a [SemanticFrameJoin],
    expected: &SemanticFrameJoin,
) -> Result<&'a SemanticFrameJoin, SemanticActionBindingError> {
    let Some(current) = current_frames
        .iter()
        .find(|frame| frame.frame() == expected.frame())
    else {
        return Err(SemanticActionBindingError::CurrentFrameMissing);
    };
    if current != expected {
        return Err(SemanticActionBindingError::Reference(
            SemanticReferenceError::Stale,
        ));
    }
    Ok(current)
}

fn locate_node(
    observation: &SemanticObservation,
    reference: SemanticReferenceId,
) -> Result<(&SemanticSnapshot, usize, &crate::SemanticNode), SemanticActionBindingError> {
    for snapshot in observation.frames() {
        if let Some((index, node)) = snapshot
            .nodes()
            .iter()
            .enumerate()
            .find(|(_, node)| node.reference() == reference)
        {
            return Ok((snapshot, index, node));
        }
    }
    Err(SemanticActionBindingError::Reference(
        SemanticReferenceError::Unknown,
    ))
}

fn is_descendant(snapshot: &SemanticSnapshot, mut child: usize, ancestor: usize) -> bool {
    while let Some(parent) = snapshot.nodes()[child].parent().map(usize::from) {
        if parent == ancestor {
            return true;
        }
        child = parent;
    }
    false
}

// Scrolling depends on the captured region, not omitted page descendants.
fn complete_scroll_target(snapshot: &SemanticSnapshot, key: SemanticNodeKey) -> bool {
    snapshot
        .nodes()
        .iter()
        .find(|node| node.key() == key)
        .is_some_and(|node| {
            node.fields_complete() == Some(true)
                && node.geometry().is_some()
                && node.operations().contains(SemanticOperationClass::Scroll)
        })
}

fn complete_disclosure_target(snapshot: &SemanticSnapshot, key: SemanticNodeKey) -> bool {
    snapshot
        .nodes()
        .iter()
        .find(|node| node.key() == key)
        .is_some_and(|node| {
            node.fields_complete() == Some(true)
                && node.geometry().is_some()
                && node.sensitivity() == SemanticSensitivity::Public
                && node.role() == SemanticRole::Button
                && node.activation() == Some(SemanticActivation::Disclosure)
                && node.operations().contains(SemanticOperationClass::Click)
        })
}

fn bind_node(snapshot: &SemanticSnapshot, node: &crate::SemanticNode) -> BoundNode {
    let parent_key = node
        .parent()
        .and_then(|parent| snapshot.nodes().get(usize::from(parent)))
        .map(crate::SemanticNode::key);
    let mut ancestor = node.parent().map(usize::from);
    let mut page_dialog_ancestor = None;
    while let Some(index) = ancestor {
        let Some(parent) = snapshot.nodes().get(index) else {
            break;
        };
        if parent.role() == SemanticRole::Dialog {
            page_dialog_ancestor = Some(parent.key());
            break;
        }
        ancestor = parent.parent().map(usize::from);
    }
    BoundNode {
        reference: node.reference(),
        node_key: node.key(),
        frame: snapshot.frame().clone(),
        snapshot: snapshot.generation(),
        role: node.role(),
        value: node.value().cloned(),
        states: node.states(),
        operations: node.operations(),
        sensitivity: node.sensitivity(),
        trust: node.trust(),
        geometry: node.geometry(),
        structural_digest: structural_digest(node, parent_key.map(|key| key.get())),
        page_dialog_ancestor,
        fields_complete: snapshot.has_complete_node_fields(node.key()),
    }
}

fn verification_node_at<'a>(
    bound: &BoundNode,
    checkpoint: SemanticSnapshotGeneration,
    current: &'a SemanticSnapshot,
) -> Result<(usize, &'a crate::SemanticNode), SemanticActionRevalidationError> {
    if current.frame() != &bound.frame || checkpoint.next() != Some(current.generation()) {
        return Err(SemanticActionRevalidationError::StaleAuthority);
    }
    let Some((index, node)) = current
        .nodes()
        .iter()
        .enumerate()
        .find(|(_, node)| node.key() == bound.node_key)
    else {
        return Err(SemanticActionRevalidationError::TargetMissing);
    };
    if node.role() != bound.role || node.trust() != bound.trust {
        return Err(SemanticActionRevalidationError::TargetChanged);
    }
    if node.role() == SemanticRole::Password
        || node.sensitivity() == SemanticSensitivity::Secret
        || node.sensitivity() != bound.sensitivity
    {
        return Err(SemanticActionRevalidationError::CredentialBoundary);
    }
    Ok((index, node))
}

fn prepared_guard(
    action: &SemanticBoundAction,
    invocation: SemanticInvocationId,
    snapshot: SemanticSnapshotGeneration,
    target_value: Option<&SemanticValueSummary>,
    target_states: SemanticStates,
    option_states: Option<SemanticStates>,
) -> [u8; 32] {
    let mut hasher = Sha256::new();
    hasher.update(b"ZEPHIUM-SEMANTIC-PREPARED-ACTION-GUARD-1\0");
    hasher.update(action.verification_guard());
    hasher.update(invocation.get().to_be_bytes());
    hasher.update(snapshot.get().to_be_bytes());
    hash_value(&mut hasher, target_value);
    hasher.update([target_states.bits()]);
    match option_states {
        Some(states) => hasher.update([1, states.bits()]),
        None => hasher.update([0]),
    }
    hasher.finalize().into()
}

fn hash_value(hasher: &mut Sha256, value: Option<&SemanticValueSummary>) {
    match value {
        None => hasher.update([0]),
        Some(SemanticValueSummary::Text(text)) => {
            hasher.update([1]);
            hasher.update((text.len() as u64).to_be_bytes());
            hasher.update(text.as_str().as_bytes());
        }
        Some(SemanticValueSummary::Redacted) => hasher.update([2]),
        Some(SemanticValueSummary::Boolean(value)) => {
            hasher.update([3, u8::from(*value)]);
        }
        Some(SemanticValueSummary::Ordinal(value)) => {
            hasher.update([4]);
            hasher.update(value.to_be_bytes());
        }
    }
}

fn structural_digest(node: &crate::SemanticNode, parent_key: Option<u64>) -> [u8; 32] {
    let mut hasher = Sha256::new();
    hasher.update(b"ZEPHIUM-SEMANTIC-ACTION-GUARD-1\0");
    hasher.update([role_code(node.role())]);
    hasher.update([node.heading_level().map_or(0, |level| level.get())]);
    if let Some(kind) = node.landmark_kind() {
        hasher.update([0xfa, kind as u8]);
    }
    hasher.update([node.operations().bits()]);
    hasher.update([node.activation().map_or(0, |kind| kind as u8)]);
    hasher.update([sensitivity_code(node.sensitivity())]);
    hasher.update([trust_code(node.trust())]);
    hasher.update(parent_key.unwrap_or(0).to_be_bytes());
    match node.name() {
        Some(name) => {
            hasher.update([1]);
            hasher.update((name.len() as u64).to_be_bytes());
            hasher.update(name.as_str().as_bytes());
        }
        None => hasher.update([0]),
    }
    hasher.finalize().into()
}

fn runtime_descriptor(node: &crate::SemanticNode) -> SemanticActionRuntimeDescriptor {
    let (value_kind, value_text, value_ordinal, value_boolean) = match node.value() {
        None => (0, None, 0, false),
        Some(SemanticValueSummary::Text(value)) => (1, Some(value.as_str()), 0, false),
        Some(SemanticValueSummary::Redacted) => (2, None, 0, false),
        Some(SemanticValueSummary::Boolean(value)) => (3, None, 0, *value),
        Some(SemanticValueSummary::Ordinal(value)) => (4, None, *value, false),
    };
    SemanticActionRuntimeDescriptor {
        activation: node.activation().map(|kind| kind as u8),
        role: role_code(node.role()),
        operations: node.operations().bits(),
        sensitivity: sensitivity_code(node.sensitivity()),
        states: node.states().bits(),
        name: node.name().map(|value| value.as_str().to_owned()),
        value_kind,
        value_text: value_text.map(str::to_owned),
        value_ordinal,
        value_boolean,
    }
}

#[derive(Clone, Eq, PartialEq, Serialize)]
pub(crate) struct SemanticActionRuntimeDescriptor {
    #[serde(rename = "a", skip_serializing_if = "Option::is_none")]
    activation: Option<u8>,
    #[serde(rename = "r")]
    role: u8,
    #[serde(rename = "o")]
    operations: u8,
    #[serde(rename = "q")]
    sensitivity: u8,
    #[serde(rename = "s")]
    states: u8,
    #[serde(rename = "n")]
    name: Option<String>,
    #[serde(rename = "vk")]
    value_kind: u8,
    #[serde(rename = "vt")]
    value_text: Option<String>,
    #[serde(rename = "vo")]
    value_ordinal: u16,
    #[serde(rename = "vb")]
    value_boolean: bool,
}

#[cfg(test)]
impl SemanticActionRuntimeDescriptor {
    pub(crate) fn maximum_text_wire_witness(name: String, value: String) -> Self {
        Self {
            activation: Some(5),
            role: 16,
            operations: 11,
            sensitivity: 2,
            states: 112,
            name: Some(name),
            value_kind: 1,
            value_text: Some(value),
            value_ordinal: 0,
            value_boolean: false,
        }
    }
}

pub(crate) fn hash_frame(hasher: &mut Sha256, frame: &SemanticFrameJoin) {
    let context = frame.context();
    let identity = context.identity();
    hasher.update(identity.id().bytes());
    hasher.update(identity.owner().bytes());
    hasher.update(identity.profile().bytes());
    hasher.update([match identity.kind() {
        crate::ContextKind::Owned => 1,
        crate::ContextKind::BorrowedTab => 2,
        crate::ContextKind::HumanSignInHandoff => 3,
    }]);
    hasher.update(context.context_generation().get().to_be_bytes());
    hasher.update(context.navigation_epoch().get().to_be_bytes());
    hasher.update(context.frame().get().to_be_bytes());
    hasher.update(context.frame_generation().get().to_be_bytes());
    hasher.update(context.cancellation_generation().get().to_be_bytes());
    hasher.update(frame.frame().get().to_be_bytes());
    hasher.update(frame.frame_generation().get().to_be_bytes());
    hasher.update(frame.origin().as_url().as_str().as_bytes());
    hasher.update([match frame.trust() {
        crate::SemanticFrameTrust::SameOrigin => 1,
        crate::SemanticFrameTrust::CrossOriginIsolated => 2,
        crate::SemanticFrameTrust::Unsupported => 3,
    }]);
}

fn hash_effect(hasher: &mut Sha256, effect: SemanticEffectClass) {
    hasher.update([match effect {
        SemanticEffectClass::Read => 1,
        SemanticEffectClass::LocalWrite => 2,
        SemanticEffectClass::ExternalWrite => 3,
        SemanticEffectClass::Communication => 4,
        SemanticEffectClass::Purchase => 5,
        SemanticEffectClass::Destructive => 6,
        SemanticEffectClass::CapabilityBoundary => 7,
    }]);
}

fn hash_wait(hasher: &mut Sha256, wait: SemanticWaitCondition) {
    match wait {
        SemanticWaitCondition::Immediate => hasher.update([1]),
        SemanticWaitCondition::NavigationCommitted => hasher.update([2]),
        SemanticWaitCondition::DocumentReady => hasher.update([3]),
        SemanticWaitCondition::TargetState { state, present } => {
            hasher.update([4, state_code(state), u8::from(present)]);
        }
        SemanticWaitCondition::UrlChanged => hasher.update([5]),
        SemanticWaitCondition::TitleChanged => hasher.update([6]),
        SemanticWaitCondition::Dialog(state) => {
            hasher.update([7, dialog_state_code(state)]);
        }
        SemanticWaitCondition::SemanticChange => hasher.update([8]),
        SemanticWaitCondition::MutationQuiet(quiet) => {
            hasher.update([9]);
            hasher.update(quiet.millis().to_be_bytes());
        }
        SemanticWaitCondition::ScrollPositionChanged => hasher.update([10]),
    }
}

fn hash_verification(hasher: &mut Sha256, verification: SemanticVerification) {
    match verification {
        SemanticVerification::PageDialogOpened => hasher.update([9]),
        SemanticVerification::PageDialogClosed => hasher.update([10]),
        SemanticVerification::TargetState { state, present } => {
            hasher.update([1, state_code(state), u8::from(present)]);
        }
        SemanticVerification::TargetValueMatchesInput => hasher.update([2]),
        SemanticVerification::TargetValueChanged => hasher.update([3]),
        SemanticVerification::TargetSelectionMatchesOption => hasher.update([4]),
        SemanticVerification::TargetSelectionChanged => hasher.update([5]),
        SemanticVerification::NavigationCommitted => hasher.update([6]),
        SemanticVerification::Dialog(state) => {
            hasher.update([7, dialog_state_code(state)]);
        }
        SemanticVerification::ScrollPositionChanged => hasher.update([8]),
        SemanticVerification::PageChanged => hasher.update([11]),
    }
}

/// What a person would see change on the frame: roles, names, text, values,
/// links and states. Keys, geometry and focus are left out, so a re-render
/// with the same content is no change.
pub(crate) fn page_digest(snapshot: &SemanticSnapshot) -> [u8; 32] {
    let mut hasher = Sha256::new();
    hasher.update(b"ZEPHIUM-SEMANTIC-PAGE-CONTENT-1\0");
    let text = |hasher: &mut Sha256, value: Option<&str>| match value {
        Some(value) => {
            hasher.update([1]);
            hasher.update((value.len() as u64).to_be_bytes());
            hasher.update(value.as_bytes());
        }
        None => hasher.update([0]),
    };
    for node in snapshot.nodes() {
        hasher.update(format!("{:?}", node.role()).as_bytes());
        hasher.update([node.depth()]);
        text(&mut hasher, node.name().map(crate::SemanticText::as_str));
        text(&mut hasher, node.text().map(crate::SemanticText::as_str));
        text(
            &mut hasher,
            node.link_destination()
                .map(|target| target.as_url().as_str()),
        );
        match node.value() {
            Some(SemanticValueSummary::Text(value)) => text(&mut hasher, Some(value.as_str())),
            Some(SemanticValueSummary::Boolean(value)) => hasher.update([2, u8::from(*value)]),
            Some(SemanticValueSummary::Ordinal(value)) => {
                hasher.update([3]);
                hasher.update(value.to_be_bytes());
            }
            Some(SemanticValueSummary::Redacted) => hasher.update([4]),
            None => hasher.update([5]),
        }
        hasher.update([node.states().bits() & !SemanticState::Focused.bit()]);
    }
    hasher.finalize().into()
}

const fn state_code(state: SemanticState) -> u8 {
    match state {
        SemanticState::Checked => 1,
        SemanticState::Selected => 2,
        SemanticState::Expanded => 3,
        SemanticState::Disabled => 4,
        SemanticState::Required => 5,
        SemanticState::Invalid => 6,
        SemanticState::Focused => 7,
    }
}

const fn dialog_state_code(state: SemanticDialogState) -> u8 {
    match state {
        SemanticDialogState::Present => 1,
        SemanticDialogState::Absent => 2,
    }
}

const fn press_key_code(key: SemanticPressKey) -> u8 {
    match key {
        SemanticPressKey::Enter => 1,
        SemanticPressKey::Escape => 2,
        SemanticPressKey::Space => 3,
        SemanticPressKey::Tab => 4,
        SemanticPressKey::ArrowUp => 5,
        SemanticPressKey::ArrowDown => 6,
        SemanticPressKey::ArrowLeft => 7,
        SemanticPressKey::ArrowRight => 8,
        SemanticPressKey::Home => 9,
        SemanticPressKey::End => 10,
        SemanticPressKey::PageUp => 11,
        SemanticPressKey::PageDown => 12,
        SemanticPressKey::Backspace => 13,
        SemanticPressKey::Delete => 14,
    }
}

const fn scroll_direction_code(direction: SemanticScrollDirection) -> u8 {
    match direction {
        SemanticScrollDirection::Up => 1,
        SemanticScrollDirection::Down => 2,
        SemanticScrollDirection::Left => 3,
        SemanticScrollDirection::Right => 4,
    }
}

const fn scroll_amount_code(amount: SemanticScrollAmount) -> u8 {
    match amount {
        SemanticScrollAmount::Line => 1,
        SemanticScrollAmount::HalfPage => 2,
        SemanticScrollAmount::Page => 3,
        SemanticScrollAmount::IntoView => 4,
    }
}

fn revalidate_node<'a>(
    bound: &BoundNode,
    current: &'a SemanticSnapshot,
    operation: Option<SemanticOperationClass>,
    deny_credential: bool,
) -> Result<(usize, &'a crate::SemanticNode), SemanticActionRevalidationError> {
    if current.frame() != &bound.frame || current.generation() < bound.snapshot {
        return Err(SemanticActionRevalidationError::StaleAuthority);
    }
    let Some((index, node)) = current
        .nodes()
        .iter()
        .enumerate()
        .find(|(_, node)| node.key() == bound.node_key)
    else {
        return Err(SemanticActionRevalidationError::TargetMissing);
    };
    if node.states().contains(SemanticState::Disabled) {
        return Err(SemanticActionRevalidationError::TargetDisabled);
    }
    if !stable_action_states_match(bound.states, node.states()) {
        #[cfg(feature = "probe-harness")]
        crate::probe_evidence_path::trace(format_args!("action-revalidation: changed=states"));
        return Err(SemanticActionRevalidationError::TargetChanged);
    }
    if operation.is_some_and(|operation| !node.operations().contains(operation)) {
        return Err(SemanticActionRevalidationError::OperationDenied);
    }
    if deny_credential
        && (node.role() == SemanticRole::Password
            || node.sensitivity() == SemanticSensitivity::Secret)
    {
        return Err(SemanticActionRevalidationError::CredentialBoundary);
    }
    let parent_key = node
        .parent()
        .and_then(|parent| current.nodes().get(usize::from(parent)))
        .map(crate::SemanticNode::key)
        .map(SemanticNodeKey::get);
    if structural_digest(node, parent_key) != bound.structural_digest {
        #[cfg(feature = "probe-harness")]
        crate::probe_evidence_path::trace(format_args!(
            "action-revalidation: changed=structure role={:?} operations={}",
            node.role(),
            node.operations().bits()
        ));
        return Err(SemanticActionRevalidationError::TargetChanged);
    }
    Ok((index, node))
}

fn stable_action_states_match(previous: SemanticStates, current: SemanticStates) -> bool {
    [
        SemanticState::Checked,
        SemanticState::Selected,
        SemanticState::Expanded,
        SemanticState::Required,
        SemanticState::Invalid,
    ]
    .into_iter()
    .all(|state| previous.contains(state) == current.contains(state))
}

const fn sensitivity_code(value: SemanticSensitivity) -> u8 {
    match value {
        SemanticSensitivity::Public => 1,
        SemanticSensitivity::Sensitive => 2,
        SemanticSensitivity::Secret => 3,
    }
}

const fn trust_code(value: SemanticTrust) -> u8 {
    match value {
        SemanticTrust::UntrustedPage => 1,
        SemanticTrust::BrowserDerived => 2,
    }
}

const fn role_code(role: SemanticRole) -> u8 {
    match role {
        SemanticRole::Group => 1,
        SemanticRole::Document => 2,
        SemanticRole::Landmark => 3,
        SemanticRole::Heading => 4,
        SemanticRole::Paragraph => 5,
        SemanticRole::Link => 6,
        SemanticRole::Button => 7,
        SemanticRole::Textbox => 8,
        SemanticRole::Password => 9,
        SemanticRole::Searchbox => 10,
        SemanticRole::Checkbox => 11,
        SemanticRole::Radio => 12,
        SemanticRole::Combobox => 13,
        SemanticRole::Listbox => 14,
        SemanticRole::Option => 15,
        SemanticRole::Spinbutton => 16,
        SemanticRole::Slider => 17,
        SemanticRole::Tab => 18,
        SemanticRole::MenuItem => 19,
        SemanticRole::Dialog => 20,
        SemanticRole::List => 21,
        SemanticRole::ListItem => 22,
        SemanticRole::Table => 23,
        SemanticRole::Row => 24,
        SemanticRole::CellHeader => 25,
        SemanticRole::Cell => 26,
        SemanticRole::Image => 27,
        SemanticRole::Progress => 28,
        SemanticRole::Status => 29,
        SemanticRole::FrameBoundary => 30,
    }
}

/// Refusal while binding pre-policy proposals to exact observation authority.
#[derive(Clone, Copy, Debug, Eq, Error, PartialEq)]
pub enum SemanticActionBindingError {
    /// A batch must contain at least one action.
    #[error("semantic action batch is empty")]
    Empty,
    /// Action count exceeded the fixed batch ceiling.
    #[error("semantic action batch exceeds its action ceiling")]
    ActionLimit,
    /// Trusted current-frame input was empty, duplicate, oversized, or cross-context.
    #[error("semantic action current-frame cohort is invalid")]
    CurrentFrameCohort,
    /// Exact current authority for an observed action frame was absent.
    #[error("semantic action current frame is missing")]
    CurrentFrameMissing,
    /// An opaque reference was unknown, stale, or not operation-authorized.
    #[error("semantic action reference binding failed")]
    Reference(SemanticReferenceError),
    /// Password/secret filling requires a separate credential capability.
    #[error("semantic action crosses a credential capability boundary")]
    CredentialBoundary,
    /// Select target/option role, frame, snapshot, or ancestry was incompatible.
    #[error("semantic selection target is invalid")]
    SelectionTarget,
    /// The fill target's current value was not observed (private or
    /// clipped), so no fill of it could be verified; nothing ran.
    #[error("semantic fill target value was not observed")]
    ValueUnobserved,
    /// The exact declared postcondition already held before any effect.
    #[error("semantic action outcome is already satisfied")]
    OutcomeAlreadySatisfied,
    /// Bound target role or fixed key cannot establish the declared postcondition.
    #[error("semantic action bound outcome contract is incompatible")]
    OutcomeContract,
    /// A model proposal conflicts with the host-projected task effect.
    #[error("semantic action effect conflicts with task scope")]
    TaskEffectMismatch(SemanticEffectClass),
    /// The supplied target needs a focused observation before preparation.
    #[error("semantic action target fields are incomplete")]
    TargetIncomplete,
    /// Aggregate replacement text exceeded the fixed batch ceiling.
    #[error("semantic action batch exceeds its text ceiling")]
    TextLimit,
    /// Aggregate settle budgets exceeded the fixed batch ceiling.
    #[error("semantic action batch exceeds its settle ceiling")]
    SettleLimit,
    /// One batch attempted to cross between declared effect classes.
    #[error("semantic action batch crosses an effect boundary")]
    MixedEffectBoundary,
    /// Externally consequential effect classes require one verified action at a time.
    #[error("semantic effect class permits only one action per batch")]
    EffectBatchLimit,
    /// The declared verification or wait needs evidence this host cannot supply.
    #[error("semantic action verification is not supported by this host")]
    UnsupportedVerification,
    /// The trusted task's own policy does not permit this action in this assignment.
    #[error("semantic action is outside the assignment")]
    AssignmentDenied,
    /// The run's operation budget cannot cover another action and its settlement.
    #[error("semantic action budget is exhausted")]
    BudgetExhausted,
    /// The page refused the action at dispatch, before anything ran: its
    /// reference no longer matched the current document.
    #[error("semantic action was rejected at dispatch")]
    DispatchRejected,
    /// The action ran, but the fresh page no longer showed its target, so
    /// its outcome was not observed.
    #[error("semantic action outcome was not observed")]
    Unverified,
    /// The page did not act: the target was covered by another element or
    /// outside the visible area, so nothing was pressed or typed.
    #[error("semantic action target was covered or out of view")]
    TargetCovered,
    /// A step that may commit something reached the page, now or earlier in
    /// the task, and its outcome was not seen: it may already have taken
    /// effect, so it is never issued again.
    #[error("semantic action outcome is unknown")]
    OutcomeUnknown,
    /// A send whose message is not addressed to the recipient the task
    /// names: nothing was issued.
    #[error("semantic action message is not addressed to the requested recipient")]
    WrongRecipient,
}

/// Typed structural refusal before backend visibility/occlusion revalidation.
#[derive(Clone, Copy, Debug, Eq, Error, PartialEq)]
pub enum SemanticActionRevalidationError {
    /// Context, frame document, or snapshot generation moved backward/replaced.
    #[error("semantic action authority is stale")]
    StaleAuthority,
    /// Stable target identity no longer exists in the current bounded snapshot.
    #[error("semantic action target is missing")]
    TargetMissing,
    /// Stable target role, state, parent, name, trust, sensitivity, or operations changed.
    #[error("semantic action target changed materially")]
    TargetChanged,
    /// Current semantics no longer allow the proposed operation class.
    #[error("semantic action operation is no longer allowed")]
    OperationDenied,
    /// Current target is disabled.
    #[error("semantic action target is disabled")]
    TargetDisabled,
    /// Fill target became password/secret and requires a credential capability.
    #[error("semantic action target crossed a credential boundary")]
    CredentialBoundary,
    /// Bound option disappeared, changed, or no longer descends from the target.
    #[error("semantic action selection target changed")]
    SelectionTarget,
}

/// Refusal while checkpointing one bound action immediately before execution.
#[derive(Clone, Copy, Debug, Eq, Error, PartialEq)]
pub enum SemanticActionPreparationError {
    /// Pre-execution semantic evidence must be complete.
    #[error("semantic action preparation snapshot is incomplete")]
    IncompleteSnapshot,
    /// Fresh structural/operation revalidation refused the action.
    #[error("semantic action preparation revalidation failed")]
    Revalidation(SemanticActionRevalidationError),
    /// The declared postcondition already held at the exact checkpoint.
    #[error("semantic action outcome is already satisfied at preparation")]
    OutcomeAlreadySatisfied,
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{
        decode_semantic_snapshot, ContextCapabilities, ContextCapability, ContextId,
        ContextIdentity, ContextKind, ContextOperationId, ContextRegistry, ContextRunId,
        ContextSettlement, FrameGeneration, SemanticDecodeContext, SemanticFrameTrust,
        SemanticInvocationId, SemanticObservationAssembler, SemanticObservationBudget,
        SemanticOrigin, SEMANTIC_WIRE_VERSION,
    };
    use serde_json::json;
    use zephium_core::ids::ProfileId;

    #[test]
    fn a_multi_line_fill_matches_up_to_how_its_line_breaks_are_kept() {
        let typed = "Hi Dana,\n\nThe release is ready.\nThanks, Hayk";
        assert!(fill_value_matches(typed, typed));
        for kept in [
            "Hi Dana,\n\nThe release is ready.\nThanks, Hayk\n",
            "Hi Dana,\n\n\nThe release is ready.\nThanks, Hayk",
            "Hi Dana,\nThe release is ready.\n\nThanks, Hayk",
            "Hi\u{a0}Dana,\n\nThe release is ready.\r\nThanks, Hayk",
        ] {
            assert!(fill_value_matches(kept, typed));
        }
        for wrong in [
            "Hi Dana,\n\nThe release is ready.",
            "Hi Dana,\n\nThe release is ready.\nThanks, Hayk and Sam",
            "Thanks, Hayk\n\nThe release is ready.\nHi Dana,",
            "Hi Dana,\n\nThe release is read y.\nThanks, Hayk",
        ] {
            assert!(!fill_value_matches(wrong, typed));
        }
        assert!(!fill_value_matches("a  b", "a b"));
    }

    fn observation() -> SemanticObservation {
        let identity = ContextIdentity::new(
            ContextId::from_raw(1),
            ContextRunId::from_raw(2),
            ProfileId::from(3),
            ContextKind::Owned,
        );
        let capabilities = ContextCapabilities::try_new(
            ContextKind::Owned,
            &[ContextCapability::Observe, ContextCapability::Act],
        )
        .expect("capabilities");
        let mut registry = ContextRegistry::new();
        registry.reserve(identity, capabilities).expect("reserve");
        let construction = registry
            .begin_context(
                identity.id(),
                ContextOperationId::new(1).expect("operation"),
            )
            .expect("construct");
        registry
            .settle_construction(identity.id(), construction, ContextSettlement::Applied)
            .expect("settle");
        let context = registry.join(identity.id()).expect("join");
        let frame = SemanticFrameJoin::try_new(
            context,
            FrameId::MAIN,
            FrameGeneration::INITIAL,
            SemanticOrigin::parse("https://action-private.example.test/path").expect("origin"),
            SemanticFrameTrust::SameOrigin,
        )
        .expect("frame");
        let bytes = serde_json::to_vec(&json!({
            "v": SEMANTIC_WIRE_VERSION,
            "i": 7,
            "g": 9,
            "c": "complete",
            "n": [
                {"k": 1, "r": "document", "o": 16},
                {"k": 2, "p": 0, "r": "button", "n": "Save private draft", "o": 9,
                 "b": {"x": 10, "y": 10, "w": 100, "h": 30}},
                {"k": 3, "p": 0, "r": "textbox", "n": "Title", "v": {"k": "text", "value": "old"}, "o": 11,
                 "b": {"x": 10, "y": 50, "w": 200, "h": 30}},
                {"k": 4, "p": 0, "r": "password", "n": "Password", "v": {"k": "redacted"}, "o": 11},
                {"k": 5, "p": 0, "r": "combobox", "n": "Priority", "v": {"k": "ordinal", "value": 0}, "o": 13},
                {"k": 6, "p": 4, "r": "option", "n": "High", "v": {"k": "ordinal", "value": 1}, "o": 9},
                {"k": 7, "p": 0, "r": "option", "n": "Detached option", "v": {"k": "ordinal", "value": 2}, "o": 9}
                ,{"k": 8, "p": 0, "r": "spinbutton", "n": "Count", "v": {"k": "text", "value": "1"}, "o": 11,
                 "b": {"x": 10, "y": 90, "w": 120, "h": 30}}
            ]
        }))
        .expect("wire");
        let snapshot = decode_semantic_snapshot(
            SemanticDecodeContext::new(
                SemanticInvocationId::new(7).expect("invocation"),
                frame,
                SemanticSnapshotGeneration::new(9).expect("generation"),
            ),
            &bytes,
        )
        .expect("snapshot");
        let request = crate::SemanticObservationRequest::initial(
            SemanticObservationId::new(1).expect("observation"),
            context,
            SemanticObservationBudget::INITIAL_FILTERED,
        );
        SemanticObservationAssembler::new(request, snapshot)
            .expect("assembler")
            .finish()
            .expect("observation")
    }

    fn frames(observation: &SemanticObservation) -> Vec<SemanticFrameJoin> {
        observation
            .frames()
            .iter()
            .map(|snapshot| snapshot.frame().clone())
            .collect()
    }

    fn current_snapshot(
        observation: &SemanticObservation,
        invocation: u64,
        generation: u64,
        nodes: serde_json::Value,
    ) -> SemanticSnapshot {
        let bytes = serde_json::to_vec(&json!({
            "v": SEMANTIC_WIRE_VERSION,
            "i": invocation,
            "g": generation,
            "c": "complete",
            "n": nodes,
        }))
        .expect("wire");
        decode_semantic_snapshot(
            SemanticDecodeContext::new(
                SemanticInvocationId::new(invocation).expect("invocation"),
                observation.frames()[0].frame().clone(),
                SemanticSnapshotGeneration::new(generation).expect("generation"),
            ),
            &bytes,
        )
        .expect("current snapshot")
    }

    fn proposal(
        intent: SemanticActionIntent,
        effect: SemanticEffectClass,
        verification: SemanticVerification,
    ) -> SemanticActionProposal {
        SemanticActionProposal::try_new(
            intent,
            effect,
            SemanticWaitCondition::Immediate,
            verification,
            SemanticSettleBudget::try_new(250).expect("budget"),
        )
        .expect("proposal")
    }

    #[test]
    fn partial_looks_act_on_targets_with_a_whole_local_witness() {
        let original = observation();
        let frame = original.frames()[0].frame().clone();
        for complete in [true, false] {
            let bytes = serde_json::to_vec(&json!({"v":1,"i":7,"g":9,"c":"node_limit","n":[
                {"k":1,"r":"document","o":16,"fc":complete,"b":{"x":0,"y":0,"w":1280,"h":800}},
                {"k":2,"p":0,"r":"button","o":1,"fc":complete,"b":{"x":10,"y":10,"w":100,"h":30}}
            ]}))
            .unwrap();
            let snapshot = decode_semantic_snapshot(
                SemanticDecodeContext::new(
                    SemanticInvocationId::new(7).unwrap(),
                    frame.clone(),
                    SemanticSnapshotGeneration::new(9).unwrap(),
                ),
                &bytes,
            )
            .unwrap();
            let observation = SemanticObservationAssembler::new(
                crate::SemanticObservationRequest::initial(
                    SemanticObservationId::new(1).unwrap(),
                    frame.context(),
                    SemanticObservationBudget::INITIAL_FILTERED,
                ),
                snapshot,
            )
            .unwrap()
            .finish()
            .unwrap();
            for (intent, verification, accepted) in [
                (
                    SemanticActionIntent::Scroll {
                        target: SemanticReferenceId::new(1).unwrap(),
                        direction: SemanticScrollDirection::Down,
                        amount: SemanticScrollAmount::Page,
                    },
                    SemanticVerification::ScrollPositionChanged,
                    complete,
                ),
                (
                    SemanticActionIntent::Click {
                        target: SemanticReferenceId::new(2).unwrap(),
                    },
                    SemanticVerification::PageDialogOpened,
                    complete,
                ),
            ] {
                let batch = SemanticActionBatch::bind(
                    SemanticActionBatchId::new(1).unwrap(),
                    &observation,
                    std::slice::from_ref(&frame),
                    vec![proposal(intent, SemanticEffectClass::Read, verification)],
                )
                .unwrap();
                assert_eq!(
                    batch.actions()[0].prepare(&observation.frames()[0]).is_ok(),
                    accepted
                );
            }
        }
    }

    #[test]
    fn partial_snapshot_click_requires_a_whole_target() {
        let original = observation();
        let frame = original.frames()[0].frame().clone();
        let expanded = SemanticVerification::TargetState {
            state: SemanticState::Expanded,
            present: true,
        };
        for (complete, activation, effect, verification, accepted) in [
            (true, 6, SemanticEffectClass::Read, expanded, true),
            (false, 6, SemanticEffectClass::Read, expanded, false),
            (true, 1, SemanticEffectClass::Read, expanded, true),
            (false, 1, SemanticEffectClass::Read, expanded, false),
            (true, 6, SemanticEffectClass::LocalWrite, expanded, true),
            (
                true,
                6,
                SemanticEffectClass::Read,
                SemanticVerification::PageDialogOpened,
                true,
            ),
            (
                false,
                6,
                SemanticEffectClass::Read,
                SemanticVerification::PageDialogOpened,
                false,
            ),
            (
                true,
                6,
                SemanticEffectClass::Read,
                SemanticVerification::TargetState {
                    state: SemanticState::Expanded,
                    present: false,
                },
                true,
            ),
        ] {
            let bytes = serde_json::to_vec(&json!({"v":1,"i":7,"g":9,"c":"node_limit","n":[
                {"k":1,"r":"document","o":16,"fc":true},
                {"k":2,"p":0,"r":"button","n":"Specifications","ak":activation,"o":9,
                 "s": if verification == (SemanticVerification::TargetState { state: SemanticState::Expanded, present: false }) { 4 } else { 0 },
                 "fc":complete,"b":{"x":10,"y":10,"w":100,"h":30}}
            ]}))
            .unwrap();
            let snapshot = decode_semantic_snapshot(
                SemanticDecodeContext::new(
                    SemanticInvocationId::new(7).unwrap(),
                    frame.clone(),
                    SemanticSnapshotGeneration::new(9).unwrap(),
                ),
                &bytes,
            )
            .unwrap();
            let observed = SemanticObservationAssembler::new(
                crate::SemanticObservationRequest::initial(
                    SemanticObservationId::new(1).unwrap(),
                    frame.context(),
                    SemanticObservationBudget::INITIAL_FILTERED,
                ),
                snapshot,
            )
            .unwrap()
            .finish()
            .unwrap();
            let batch = SemanticActionBatch::bind(
                SemanticActionBatchId::new(1).unwrap(),
                &observed,
                std::slice::from_ref(&frame),
                vec![proposal(
                    SemanticActionIntent::Click {
                        target: SemanticReferenceId::new(2).unwrap(),
                    },
                    effect,
                    verification,
                )],
            )
            .unwrap();
            assert_eq!(
                batch.actions()[0].prepare(&observed.frames()[0]).is_ok(),
                accepted
            );
        }
    }

    #[test]
    fn runtime_descriptor_matches_the_cross_language_action_golden() {
        let wire = SemanticActionRuntimeDescriptor {
            activation: None,
            role: role_code(SemanticRole::Button),
            operations: SemanticOperations::try_new(&[
                SemanticOperationClass::Click,
                SemanticOperationClass::Press,
            ])
            .expect("operations")
            .bits(),
            sensitivity: sensitivity_code(SemanticSensitivity::Public),
            states: SemanticStates::NONE.bits(),
            name: Some("Save".to_owned()),
            value_kind: 0,
            value_text: None,
            value_ordinal: 0,
            value_boolean: false,
        };
        let encoded = serde_json::to_vec(&wire).expect("descriptor wire");
        assert_eq!(
            encoded,
            br#"{"r":7,"o":9,"q":1,"s":0,"n":"Save","vk":0,"vt":null,"vo":0,"vb":false}"#
        );
    }

    #[test]
    fn binds_all_fixed_action_shapes_to_exact_observation_authority() {
        let observation = observation();
        let current = frames(&observation);

        let click = SemanticActionBatch::bind(
            SemanticActionBatchId::new(1).expect("batch"),
            &observation,
            &current,
            vec![proposal(
                SemanticActionIntent::Click {
                    target: SemanticReferenceId::new(2).expect("reference"),
                },
                SemanticEffectClass::Read,
                SemanticVerification::TargetState {
                    state: SemanticState::Focused,
                    present: true,
                },
            )],
        )
        .expect("click");
        assert_eq!(click.actions()[0].kind(), SemanticActionKind::Click);
        assert_eq!(click.actions()[0].target_role(), SemanticRole::Button);
        assert!(click.actions()[0].target_geometry().is_some());

        let fill_and_press = SemanticActionBatch::bind(
            SemanticActionBatchId::new(2).expect("batch"),
            &observation,
            &current,
            vec![
                proposal(
                    SemanticActionIntent::Fill {
                        target: SemanticReferenceId::new(3).expect("reference"),
                        value: SemanticActionText::try_new("new private title".to_owned())
                            .expect("text"),
                    },
                    SemanticEffectClass::LocalWrite,
                    SemanticVerification::TargetValueMatchesInput,
                ),
                proposal(
                    SemanticActionIntent::Press {
                        target: SemanticReferenceId::new(3).expect("reference"),
                        key: SemanticPressKey::Enter,
                    },
                    SemanticEffectClass::LocalWrite,
                    SemanticVerification::TargetState {
                        state: SemanticState::Focused,
                        present: true,
                    },
                ),
            ],
        )
        .expect("fill and press");
        assert_eq!(fill_and_press.actions().len(), 2);
        assert_eq!(fill_and_press.actions()[1].ordinal(), 2);
        assert_eq!(fill_and_press.text_bytes(), "new private title".len());
        assert_eq!(fill_and_press.settle_millis(), 500);

        let select = SemanticActionBatch::bind(
            SemanticActionBatchId::new(3).expect("batch"),
            &observation,
            &current,
            vec![proposal(
                SemanticActionIntent::Select {
                    target: SemanticReferenceId::new(5).expect("target"),
                    option: SemanticReferenceId::new(6).expect("option"),
                },
                SemanticEffectClass::LocalWrite,
                SemanticVerification::TargetSelectionMatchesOption,
            )],
        )
        .expect("select");
        assert_eq!(
            select.actions()[0].option_reference(),
            SemanticReferenceId::new(6)
        );

        let scroll = SemanticActionBatch::bind(
            SemanticActionBatchId::new(4).expect("batch"),
            &observation,
            &current,
            vec![proposal(
                SemanticActionIntent::Scroll {
                    target: SemanticReferenceId::new(1).expect("document"),
                    direction: SemanticScrollDirection::Down,
                    amount: SemanticScrollAmount::Page,
                },
                SemanticEffectClass::Read,
                SemanticVerification::ScrollPositionChanged,
            )],
        )
        .expect("scroll");
        assert_eq!(scroll.actions()[0].kind(), SemanticActionKind::Scroll);
    }

    #[test]
    fn binds_core_legal_spinbutton_fill_before_platform_compatibility_filtering() {
        let observation = observation();
        let current = frames(&observation);
        let batch = SemanticActionBatch::bind(
            SemanticActionBatchId::new(1).expect("batch"),
            &observation,
            &current,
            vec![proposal(
                SemanticActionIntent::Fill {
                    target: SemanticReferenceId::new(8).expect("spinbutton reference"),
                    value: SemanticActionText::try_new("2".to_owned()).expect("fill text"),
                },
                SemanticEffectClass::LocalWrite,
                SemanticVerification::TargetValueMatchesInput,
            )],
        )
        .expect("spinbutton Fill is legal in the core action contract");

        assert_eq!(batch.actions()[0].kind(), SemanticActionKind::Fill);
        assert_eq!(batch.actions()[0].target_role(), SemanticRole::Spinbutton);
    }

    #[test]
    fn absent_fill_value_never_proves_an_already_satisfied_empty_input() {
        for role in ["textbox", "spinbutton"] {
            absent_fill_value_for_role(role);
        }
    }

    fn absent_fill_value_for_role(role: &str) {
        let template = observation();
        let nodes = |value: Option<&str>| {
            let mut field = json!({"k": 3,"p":0,"r":role,"n":"Title","o":11,
                "b":{"x":10,"y":50,"w":200,"h":30}});
            if let Some(value) = value {
                field["v"] = json!({"k":"text","value":value});
            }
            json!([{"k":1,"r":"document","o":16},field])
        };
        let make_observation = |value| {
            SemanticObservationAssembler::new(
                crate::SemanticObservationRequest::initial(
                    SemanticObservationId::new(2).unwrap(),
                    template.request().context(),
                    SemanticObservationBudget::INITIAL_FILTERED,
                ),
                current_snapshot(&template, 8, 10, nodes(value)),
            )
            .unwrap()
            .finish()
            .unwrap()
        };
        let unknown = make_observation(None);
        let empty = make_observation(Some(""));
        let bind_value = |observation: &SemanticObservation, value: &str| {
            SemanticActionBatch::bind(
                SemanticActionBatchId::new(1).unwrap(),
                observation,
                &frames(observation),
                vec![proposal(
                    SemanticActionIntent::Fill {
                        target: SemanticReferenceId::new(2).unwrap(),
                        value: SemanticActionText::try_new(value.to_owned()).unwrap(),
                    },
                    SemanticEffectClass::LocalWrite,
                    SemanticVerification::TargetValueMatchesInput,
                )],
            )
        };
        assert_eq!(
            bind_value(&unknown, "").unwrap_err(),
            SemanticActionBindingError::ValueUnobserved,
            "unknown starting value refuses before native mutation, without claiming it is empty"
        );
        assert_eq!(
            bind_value(&empty, "").unwrap_err(),
            SemanticActionBindingError::OutcomeAlreadySatisfied
        );
        assert_eq!(
            bind_value(&unknown, "replacement").unwrap_err(),
            SemanticActionBindingError::ValueUnobserved
        );
        let from_empty = bind_value(&empty, "12").unwrap();
        let prepared = from_empty.actions()[0].prepare(&empty.frames()[0]).unwrap();
        let filled = current_snapshot(&empty, 9, 11, nodes(Some("12")));
        assert_eq!(
            prepared.verification_fill_values(&filled).unwrap(),
            ("", "12"),
            "explicitly observed empty values must support exact fill transitions"
        );
    }

    #[test]
    fn prepares_sequential_actions_from_the_rolling_complete_checkpoint() {
        let observation = observation();
        let batch = SemanticActionBatch::bind(
            SemanticActionBatchId::new(1).expect("batch"),
            &observation,
            &frames(&observation),
            vec![
                proposal(
                    SemanticActionIntent::Fill {
                        target: SemanticReferenceId::new(3).expect("reference"),
                        value: SemanticActionText::try_new("new private title".to_owned())
                            .expect("text"),
                    },
                    SemanticEffectClass::LocalWrite,
                    SemanticVerification::TargetValueMatchesInput,
                ),
                proposal(
                    SemanticActionIntent::Press {
                        target: SemanticReferenceId::new(3).expect("reference"),
                        key: SemanticPressKey::Enter,
                    },
                    SemanticEffectClass::LocalWrite,
                    SemanticVerification::TargetState {
                        state: SemanticState::Focused,
                        present: true,
                    },
                ),
            ],
        )
        .expect("batch");

        let first = batch.actions()[0]
            .prepare(&observation.frames()[0])
            .expect("first checkpoint");
        let after_fill = current_snapshot(
            &observation,
            8,
            10,
            json!([
                {"k": 1, "r": "document", "o": 16},
                {"k": 2, "p": 0, "r": "button", "n": "Save private draft", "o": 9,
                 "b": {"x": 10, "y": 10, "w": 100, "h": 30}},
                {"k": 3, "p": 0, "r": "textbox", "n": "Title",
                 "v": {"k": "text", "value": "new private title"}, "o": 11,
                 "b": {"x": 10, "y": 50, "w": 200, "h": 30}},
                {"k": 4, "p": 0, "r": "password", "n": "Password",
                 "v": {"k": "redacted"}, "o": 11},
                {"k": 5, "p": 0, "r": "combobox", "n": "Priority",
                 "v": {"k": "ordinal", "value": 0}, "o": 13},
                {"k": 6, "p": 4, "r": "option", "n": "High",
                 "v": {"k": "ordinal", "value": 1}, "o": 9},
                {"k": 7, "p": 0, "r": "option", "n": "Detached option",
                 "v": {"k": "ordinal", "value": 2}, "o": 9}
            ]),
        );
        let second = batch.actions()[1]
            .prepare(&after_fill)
            .expect("second rolling checkpoint");

        assert_eq!(first.checkpoint_invocation().get(), 7);
        assert_eq!(first.checkpoint_snapshot().get(), 9);
        assert_eq!(second.checkpoint_invocation().get(), 8);
        assert_eq!(second.checkpoint_snapshot().get(), 10);
        assert_ne!(first.verification_guard(), second.verification_guard());
        assert_eq!(
            batch.actions()[0].prepare(&after_fill),
            Err(SemanticActionPreparationError::OutcomeAlreadySatisfied)
        );
        let debug = format!("{second:?}");
        assert!(!debug.contains("new private title"));
    }

    #[test]
    fn text_and_debug_are_bounded_secret_safe_and_content_redacted() {
        assert_eq!(
            SemanticActionText::try_new("sk-super-secret-value".to_owned()),
            Err(SemanticActionTextError::Secret)
        );
        assert_eq!(
            SemanticActionText::try_new("unsafe\u{202e}text".to_owned()),
            Err(SemanticActionTextError::InvalidCharacter)
        );
        assert_eq!(
            SemanticActionText::try_new("carriage\rreturn".to_owned()),
            Err(SemanticActionTextError::InvalidCharacter)
        );
        assert!(SemanticActionText::try_new("tab\tand\nline".to_owned()).is_ok());
        assert_eq!(
            SemanticActionText::try_new("x".repeat(MAX_SEMANTIC_ACTION_TEXT_BYTES + 1)),
            Err(SemanticActionTextError::Limit)
        );
        assert!(SemanticActionText::try_new(String::new())
            .expect("clear")
            .is_empty());

        let observation = observation();
        let batch = SemanticActionBatch::bind(
            SemanticActionBatchId::new(9).expect("batch"),
            &observation,
            &frames(&observation),
            vec![proposal(
                SemanticActionIntent::Fill {
                    target: SemanticReferenceId::new(3).expect("reference"),
                    value: SemanticActionText::try_new("private replacement".to_owned())
                        .expect("text"),
                },
                SemanticEffectClass::LocalWrite,
                SemanticVerification::TargetValueMatchesInput,
            )],
        )
        .expect("batch");
        let debug = format!("{batch:?} {:?}", batch.actions());
        assert!(!debug.contains("private replacement"));
        assert!(!debug.contains("Save private draft"));
        assert!(!debug.contains("action-private"));
        assert!(!debug.contains("5da29"));
        assert!(debug.contains("text_bytes"));
    }

    #[test]
    fn credentials_wrong_operations_and_invalid_selection_fail_closed() {
        let observation = observation();
        let current = frames(&observation);
        assert_eq!(
            SemanticActionBatch::bind(
                SemanticActionBatchId::new(10).expect("batch"),
                &observation,
                &current,
                vec![proposal(
                    SemanticActionIntent::Fill {
                        target: SemanticReferenceId::new(4).expect("password"),
                        value: SemanticActionText::try_new("ordinary-value".to_owned())
                            .expect("text"),
                    },
                    SemanticEffectClass::LocalWrite,
                    SemanticVerification::TargetValueMatchesInput,
                )],
            ),
            Err(SemanticActionBindingError::CredentialBoundary)
        );
        assert!(matches!(
            SemanticActionBatch::bind(
                SemanticActionBatchId::new(11).expect("batch"),
                &observation,
                &current,
                vec![proposal(
                    SemanticActionIntent::Fill {
                        target: SemanticReferenceId::new(2).expect("button"),
                        value: SemanticActionText::try_new("x".to_owned()).expect("text"),
                    },
                    SemanticEffectClass::LocalWrite,
                    SemanticVerification::TargetValueMatchesInput,
                )],
            ),
            Err(SemanticActionBindingError::Reference(
                SemanticReferenceError::OperationDenied
            ))
        ));
        assert_eq!(
            SemanticActionBatch::bind(
                SemanticActionBatchId::new(12).expect("batch"),
                &observation,
                &current,
                vec![proposal(
                    SemanticActionIntent::Select {
                        target: SemanticReferenceId::new(5).expect("target"),
                        option: SemanticReferenceId::new(7).expect("option"),
                    },
                    SemanticEffectClass::LocalWrite,
                    SemanticVerification::TargetSelectionMatchesOption,
                )],
            ),
            Err(SemanticActionBindingError::SelectionTarget)
        );
    }

    #[test]
    fn batch_effect_time_count_and_current_frame_bounds_are_enforced() {
        let observation = observation();
        let current = frames(&observation);
        let click = || {
            proposal(
                SemanticActionIntent::Click {
                    target: SemanticReferenceId::new(2).expect("button"),
                },
                SemanticEffectClass::Read,
                SemanticVerification::TargetState {
                    state: SemanticState::Focused,
                    present: true,
                },
            )
        };
        assert_eq!(
            SemanticActionBatch::bind(
                SemanticActionBatchId::new(20).expect("batch"),
                &observation,
                &current,
                Vec::new(),
            ),
            Err(SemanticActionBindingError::Empty)
        );
        assert_eq!(
            SemanticActionBatch::bind(
                SemanticActionBatchId::new(21).expect("batch"),
                &observation,
                &current,
                (0..=MAX_SEMANTIC_ACTIONS_PER_BATCH)
                    .map(|_| click())
                    .collect(),
            ),
            Err(SemanticActionBindingError::ActionLimit)
        );
        assert_eq!(
            SemanticActionBatch::bind(
                SemanticActionBatchId::new(22).expect("batch"),
                &observation,
                &[],
                vec![click()],
            ),
            Err(SemanticActionBindingError::CurrentFrameCohort)
        );
        assert_eq!(
            SemanticActionBatch::bind(
                SemanticActionBatchId::new(25).expect("batch"),
                &observation,
                &current,
                vec![
                    click(),
                    proposal(
                        SemanticActionIntent::Click {
                            target: SemanticReferenceId::new(2).expect("button"),
                        },
                        SemanticEffectClass::LocalWrite,
                        SemanticVerification::TargetState {
                            state: SemanticState::Focused,
                            present: true
                        },
                    ),
                ],
            ),
            Err(SemanticActionBindingError::MixedEffectBoundary)
        );

        let full_text = || {
            proposal(
                SemanticActionIntent::Fill {
                    target: SemanticReferenceId::new(3).expect("textbox"),
                    value: SemanticActionText::try_new("x".repeat(MAX_SEMANTIC_ACTION_TEXT_BYTES))
                        .expect("text"),
                },
                SemanticEffectClass::LocalWrite,
                SemanticVerification::TargetValueMatchesInput,
            )
        };
        assert_eq!(
            SemanticActionBatch::bind(
                SemanticActionBatchId::new(26).expect("batch"),
                &observation,
                &current,
                (0..5).map(|_| full_text()).collect(),
            ),
            Err(SemanticActionBindingError::TextLimit)
        );

        let external = |id| {
            proposal(
                SemanticActionIntent::Click { target: id },
                SemanticEffectClass::ExternalWrite,
                SemanticVerification::TargetState {
                    state: SemanticState::Focused,
                    present: true,
                },
            )
        };
        assert_eq!(
            SemanticActionBatch::bind(
                SemanticActionBatchId::new(23).expect("batch"),
                &observation,
                &current,
                vec![
                    external(SemanticReferenceId::new(2).expect("button")),
                    external(SemanticReferenceId::new(2).expect("button")),
                ],
            ),
            Err(SemanticActionBindingError::EffectBatchLimit)
        );

        let slow = || {
            SemanticActionProposal::try_new(
                SemanticActionIntent::Click {
                    target: SemanticReferenceId::new(2).expect("button"),
                },
                SemanticEffectClass::Read,
                SemanticWaitCondition::Immediate,
                SemanticVerification::TargetState {
                    state: SemanticState::Focused,
                    present: true,
                },
                SemanticSettleBudget::try_new(10_000).expect("budget"),
            )
            .expect("proposal")
        };
        assert_eq!(
            SemanticActionBatch::bind(
                SemanticActionBatchId::new(24).expect("batch"),
                &observation,
                &current,
                (0..7).map(|_| slow()).collect(),
            ),
            Err(SemanticActionBindingError::SettleLimit)
        );
    }

    #[test]
    fn outcome_contracts_reject_blind_or_incompatible_settlement() {
        assert_eq!(
            SemanticMutationQuietPeriod::try_new(0),
            Err(SemanticActionContractError::QuietPeriod)
        );
        assert_eq!(
            SemanticSettleBudget::try_new(MAX_SEMANTIC_ACTION_SETTLE_MILLIS + 1),
            Err(SemanticActionContractError::SettleBudget)
        );
        assert_eq!(
            SemanticActionProposal::try_new(
                SemanticActionIntent::Fill {
                    target: SemanticReferenceId::new(3).expect("textbox"),
                    value: SemanticActionText::try_new("bounded value".to_owned()).expect("value"),
                },
                SemanticEffectClass::LocalWrite,
                SemanticWaitCondition::MutationQuiet(
                    SemanticMutationQuietPeriod::try_new(200).expect("quiet")
                ),
                SemanticVerification::TargetValueMatchesInput,
                SemanticSettleBudget::try_new(100).expect("budget"),
            ),
            Err(SemanticActionContractError::OutcomeContract)
        );
        assert_eq!(
            SemanticActionProposal::try_new(
                SemanticActionIntent::Scroll {
                    target: SemanticReferenceId::new(1).expect("document"),
                    direction: SemanticScrollDirection::Down,
                    amount: SemanticScrollAmount::Page,
                },
                SemanticEffectClass::Read,
                SemanticWaitCondition::SemanticChange,
                SemanticVerification::TargetState {
                    state: SemanticState::Focused,
                    present: true
                },
                SemanticSettleBudget::try_new(100).expect("budget"),
            ),
            Err(SemanticActionContractError::OutcomeContract)
        );
        let observation = observation();
        assert_eq!(
            SemanticActionBatch::bind(
                SemanticActionBatchId::new(28).expect("batch"),
                &observation,
                &frames(&observation),
                vec![proposal(
                    SemanticActionIntent::Click {
                        target: SemanticReferenceId::new(2).expect("button"),
                    },
                    SemanticEffectClass::Read,
                    SemanticVerification::PageDialogClosed,
                )],
            ),
            Err(SemanticActionBindingError::OutcomeContract)
        );
        assert_eq!(
            SemanticActionBatch::bind(
                SemanticActionBatchId::new(29).expect("batch"),
                &observation,
                &frames(&observation),
                vec![proposal(
                    SemanticActionIntent::Press {
                        target: SemanticReferenceId::new(3).expect("textbox"),
                        key: SemanticPressKey::ArrowDown,
                    },
                    SemanticEffectClass::LocalWrite,
                    SemanticVerification::TargetSelectionChanged,
                )],
            ),
            Err(SemanticActionBindingError::OutcomeContract)
        );
        assert_eq!(
            SemanticActionProposal::try_new(
                SemanticActionIntent::Click {
                    target: SemanticReferenceId::new(2).expect("button"),
                },
                SemanticEffectClass::Read,
                SemanticWaitCondition::Immediate,
                SemanticVerification::NavigationCommitted,
                SemanticSettleBudget::try_new(100).expect("budget"),
            ),
            Err(SemanticActionContractError::OutcomeContract)
        );
    }

    #[test]
    fn revalidation_follows_stable_identity_and_ignores_safe_mutable_fields() {
        let observation = observation();
        let batch = SemanticActionBatch::bind(
            SemanticActionBatchId::new(30).expect("batch"),
            &observation,
            &frames(&observation),
            vec![proposal(
                SemanticActionIntent::Click {
                    target: SemanticReferenceId::new(2).expect("button"),
                },
                SemanticEffectClass::Read,
                SemanticVerification::TargetState {
                    state: SemanticState::Focused,
                    present: true,
                },
            )],
        )
        .expect("batch");
        let action = &batch.actions()[0];

        let reordered = current_snapshot(
            &observation,
            8,
            10,
            json!([
                {"k": 1, "r": "document", "o": 16},
                {"k": 99, "p": 0, "r": "paragraph", "n": "Inserted sibling"},
                {"k": 2, "p": 0, "r": "button", "n": "Save private draft", "s": 64, "o": 9,
                 "b": {"x": 40, "y": 30, "w": 120, "h": 40}}
            ]),
        );
        assert_eq!(action.revalidate(&reordered), Ok(()));

        let renamed = current_snapshot(
            &observation,
            9,
            10,
            json!([
                {"k": 1, "r": "document", "o": 16},
                {"k": 2, "p": 0, "r": "button", "n": "Publish private draft", "o": 9}
            ]),
        );
        assert_eq!(
            action.revalidate(&renamed),
            Err(SemanticActionRevalidationError::TargetChanged)
        );

        let state_changed = current_snapshot(
            &observation,
            16,
            10,
            json!([
                {"k": 1, "r": "document", "o": 16},
                {"k": 2, "p": 0, "r": "button", "n": "Save private draft", "s": 4, "o": 9}
            ]),
        );
        assert_eq!(
            action.revalidate(&state_changed),
            Err(SemanticActionRevalidationError::TargetChanged)
        );

        let missing = current_snapshot(
            &observation,
            10,
            10,
            json!([{"k": 1, "r": "document", "o": 16}]),
        );
        assert_eq!(
            action.revalidate(&missing),
            Err(SemanticActionRevalidationError::TargetMissing)
        );

        let operation_removed = current_snapshot(
            &observation,
            11,
            10,
            json!([
                {"k": 1, "r": "document", "o": 16},
                {"k": 2, "p": 0, "r": "button", "n": "Save private draft"}
            ]),
        );
        assert_eq!(
            action.revalidate(&operation_removed),
            Err(SemanticActionRevalidationError::OperationDenied)
        );

        let disabled = current_snapshot(
            &observation,
            12,
            10,
            json!([
                {"k": 1, "r": "document", "o": 16},
                {"k": 2, "p": 0, "r": "button", "n": "Save private draft", "s": 8}
            ]),
        );
        assert_eq!(
            action.revalidate(&disabled),
            Err(SemanticActionRevalidationError::TargetDisabled)
        );

        let older = current_snapshot(
            &observation,
            13,
            8,
            json!([
                {"k": 1, "r": "document", "o": 16},
                {"k": 2, "p": 0, "r": "button", "n": "Save private draft", "o": 9}
            ]),
        );
        assert_eq!(
            action.revalidate(&older),
            Err(SemanticActionRevalidationError::StaleAuthority)
        );
    }

    #[test]
    fn revalidation_refuses_credential_escalation_and_option_drift() {
        let observation = observation();
        let fill = SemanticActionBatch::bind(
            SemanticActionBatchId::new(31).expect("batch"),
            &observation,
            &frames(&observation),
            vec![proposal(
                SemanticActionIntent::Fill {
                    target: SemanticReferenceId::new(3).expect("textbox"),
                    value: SemanticActionText::try_new("ordinary-value".to_owned()).expect("text"),
                },
                SemanticEffectClass::LocalWrite,
                SemanticVerification::TargetValueMatchesInput,
            )],
        )
        .expect("fill");
        let credential = current_snapshot(
            &observation,
            14,
            10,
            json!([
                {"k": 1, "r": "document", "o": 16},
                {"k": 3, "p": 0, "r": "textbox", "n": "Title",
                 "v": {"k": "redacted"}, "o": 11, "q": "secret"}
            ]),
        );
        assert_eq!(
            fill.actions()[0].revalidate(&credential),
            Err(SemanticActionRevalidationError::CredentialBoundary)
        );

        let select = SemanticActionBatch::bind(
            SemanticActionBatchId::new(32).expect("batch"),
            &observation,
            &frames(&observation),
            vec![proposal(
                SemanticActionIntent::Select {
                    target: SemanticReferenceId::new(5).expect("combobox"),
                    option: SemanticReferenceId::new(6).expect("option"),
                },
                SemanticEffectClass::LocalWrite,
                SemanticVerification::TargetSelectionMatchesOption,
            )],
        )
        .expect("select");
        let detached = current_snapshot(
            &observation,
            15,
            10,
            json!([
                {"k": 1, "r": "document", "o": 16},
                {"k": 5, "p": 0, "r": "combobox", "n": "Priority",
                 "v": {"k": "ordinal", "value": 0}, "o": 13},
                {"k": 6, "p": 0, "r": "option", "n": "High",
                 "v": {"k": "ordinal", "value": 1}, "o": 9}
            ]),
        );
        assert_eq!(
            select.actions()[0].revalidate(&detached),
            Err(SemanticActionRevalidationError::SelectionTarget)
        );
    }
}
