//! Nonterminal reads use the real actor, transport, runtime and form predicate.
use super::*;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(super) enum ReadFault {
    None,
    LocateMiss,
    NoProgress,
    AlreadySatisfied,
    LocateMissCeiling,
    Extraction,
    LongExtraction,
    AfterActionExtraction,
    Disabled,
    Subtree,
    Ceiling,
    CountRefused,
    StreamRefused,
    CancelCount,
    TakeoverStream,
    SuspendCount,
    ActionLost,
    AuditLost,
}
impl ReadFault {
    pub(super) fn requests(self) -> u8 {
        match self {
            Self::NoProgress => 10,
            Self::LongExtraction => 48,
            Self::AfterActionExtraction => 8,
            Self::Disabled | Self::Subtree => 2,
            Self::Ceiling | Self::LocateMissCeiling => 16,
            Self::CountRefused | Self::CancelCount | Self::SuspendCount => 3,
            Self::StreamRefused | Self::TakeoverStream => 4,
            _ => 6,
        }
    }
    pub(super) fn stop(self, turns: u8, count: bool) -> Option<AgentRuntimeStopReason> {
        match (self, turns, count) {
            (Self::CancelCount, 1, true) => Some(AgentRuntimeStopReason::Cancelled),
            (Self::TakeoverStream, 1, false) => Some(AgentRuntimeStopReason::HumanTakeover),
            (Self::SuspendCount, 1, true) => Some(AgentRuntimeStopReason::Suspend),
            _ => None,
        }
    }
    pub(super) fn refused(self, turns: u8, count: bool) -> bool {
        turns == 1
            && matches!(
                (self, count),
                (Self::CountRefused, true) | (Self::StreamRefused, false)
            )
    }
    pub(super) fn stream(self, turn: u8) -> String {
        if self == Self::AlreadySatisfied {
            let stream = tool_stream(turn, true);
            return if turn <= 2 {
                stream.replace("fixture value", "")
            } else {
                stream
            };
        }
        if self == Self::NoProgress {
            return match turn {
                1 | 3 => named_tool_stream(
                    turn,
                    "locate",
                    r#"{\"semantic_query\":\"missing specifications\",\"scope\":{\"kind\":\"initial\"}}"#,
                ),
                2 => named_tool_stream(turn, "read", r#"{\"scope\":{\"kind\":\"initial\"}}"#),
                4 => named_tool_stream(
                    turn,
                    "locate",
                    r#"{\"semantic_query\":\"Field\",\"scope\":{\"kind\":\"initial\"}}"#,
                ),
                _ => tool_stream(turn, true),
            };
        }
        if self == Self::LongExtraction {
            return if turn < 23 {
                named_tool_stream(turn, "read", r#"{\"scope\":{\"kind\":\"initial\"}}"#)
            } else if turn == 23 {
                named_tool_stream(
                    turn,
                    "extract",
                    r#"{\"scope\":{\"kind\":\"initial\"},\"schema_id\":1}"#,
                )
            } else {
                extraction_stream(ExtractionFault::None)
                    .replace("resp_2", &format!("resp_{turn}"))
                    .replace("msg_2", &format!("msg_{turn}"))
            };
        }
        if self == Self::LocateMissCeiling || (self == Self::LocateMiss && turn == 1) {
            return named_tool_stream(
                turn,
                "locate",
                &r#"{\"semantic_query\":\"missing specifications\",\"scope\":{\"kind\":\"initial\"}}"#.replace("missing specifications", &format!("missing specifications {turn}")),
            );
        }
        if matches!(self, Self::Extraction | Self::AfterActionExtraction) {
            let turn_in_read = if self == Self::AfterActionExtraction {
                if turn == 1 {
                    return tool_stream(turn, true);
                }
                turn - 1
            } else {
                turn
            };
            return match turn_in_read {
                1 => named_tool_stream(turn, "read", r#"{\"scope\":{\"kind\":\"initial\"}}"#),
                2 => named_tool_stream(
                    turn,
                    "extract",
                    r#"{\"scope\":{\"kind\":\"initial\"},\"schema_id\":1}"#,
                ),
                _ => extraction_stream(ExtractionFault::None)
                    .replace("resp_2", &format!("resp_{turn}"))
                    .replace("msg_2", &format!("msg_{turn}")),
            };
        }
        if self == Self::Subtree {
            named_tool_stream(
                turn,
                "read",
                r#"{\"scope\":{\"kind\":\"subtree\",\"target\":\"@a2\"}}"#,
            )
        } else if turn <= 2 || self == Self::Ceiling {
            named_tool_stream(turn, "read", r#"{\"scope\":{\"kind\":\"initial\"}}"#)
        } else {
            tool_stream(turn, true)
        }
    }
    pub(super) fn check_request(self, body: &[u8], turns: u8) {
        if self == Self::AlreadySatisfied {
            if turns != 0 {
                let parsed: serde_json::Value = serde_json::from_slice(body).unwrap();
                let result = parsed["input"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .rfind(|item| item["type"] == "function_call_output")
                    .unwrap();
                let output: serde_json::Value =
                    serde_json::from_str(result["output"].as_str().unwrap()).unwrap();
                assert_eq!(
                    output["code"],
                    if turns == 1 {
                        "outcome_already_satisfied"
                    } else {
                        "no_progress"
                    }
                );
                assert_eq!(output["executed"], false);
            }
            return;
        }
        if self == Self::NoProgress {
            let parsed: serde_json::Value = serde_json::from_slice(body).unwrap();
            if turns > 0 {
                let result = parsed["input"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .rfind(|item| item["type"] == "function_call_output")
                    .unwrap();
                assert_eq!(result["call_id"], format!("call_{turns}"));
                let output = result["output"].as_str().unwrap();
                match turns {
                    1 | 4 => assert!(output.contains("ZLOC1 content=untrusted")),
                    2 => assert!(output.contains("ZREAD3 content=untrusted")),
                    3 => {
                        let refused: serde_json::Value = serde_json::from_str(output).unwrap();
                        assert_eq!(refused["code"], "no_progress");
                        assert_eq!(refused["executed"], false);
                        assert_eq!(refused["observation_unchanged"], true);
                    }
                    _ => unreachable!(),
                }
            }
            return;
        }
        let body = std::str::from_utf8(body).unwrap();
        if turns == 0 {
            assert_eq!(body.contains("\"name\":\"read\""), self != Self::Disabled);
        }
        if turns > 0 && matches!(self, Self::LocateMiss | Self::LocateMissCeiling) {
            assert!(body.contains("ZLOC1 content=untrusted"));
            assert!(body.contains("matches=0 matched=0"));
            assert!(body.contains("No matches is limited to this observation"));
        }
        if turns > u8::from(self == Self::AfterActionExtraction)
            && self != Self::LocateMissCeiling
            && !(self == Self::LocateMiss && turns == 1)
        {
            assert!(body.contains("ZREAD3 content=untrusted"));
            assert!(body.contains("Field"));
        }
    }
}

pub(super) struct ReadTask {
    inner: Box<dyn AgentWorkTask>,
    enabled: bool,
}
impl ReadTask {
    pub(super) fn new(input: &AgentWorkRunInput, fault: ReadFault) -> Self {
        let form = crate::AgentWorkFormTask::try_new_local_preparation(
            input.context.identity,
            input.context.origin.clone(),
            AgentAccountScope::Anonymous,
            vec![
                crate::AgentWorkFormPhase::try_new(vec![crate::AgentWorkFormGoal::fill(
                    Some("Field".into()),
                    "fixture value".into(),
                )
                .unwrap()])
                .unwrap(),
            ],
        )
        .unwrap()
        .with_baseline_read();
        assert!(form.allows_baseline_read());
        let extraction = || {
            AgentWorkExtractionTask::try_new(
                vec![SemanticExtractionFieldSchema::try_text("label".into(), true, 64).unwrap()],
                AgentAccountScope::Anonymous,
            )
            .unwrap()
        };
        let inner: Box<dyn AgentWorkTask> = match fault {
            ReadFault::AfterActionExtraction => Box::new(CombinedTask {
                extraction: extraction(),
                fault: CombinedFault::None,
                ready: None,
            }),
            ReadFault::Extraction | ReadFault::LongExtraction => {
                Box::new(extraction().with_baseline_read())
            }
            _ => Box::new(form),
        };
        Self {
            inner,
            enabled: fault != ReadFault::Disabled,
        }
    }
}
impl AgentWorkTask for ReadTask {
    fn allows_actions_before_extraction(&self) -> bool {
        self.inner.allows_actions_before_extraction()
    }
    fn extraction_schema(&self) -> Option<&SemanticExtractionSchema> {
        self.inner.extraction_schema()
    }
    fn model_action_operations(
        &self,
        node: &SemanticNode,
        observation: &SemanticObservation,
    ) -> Result<SemanticOperations, AgentWorkFailure> {
        self.inner.model_action_operations(node, observation)
    }
    fn accept_extraction(
        &mut self,
        result: &SemanticExtractionResult<'_>,
    ) -> Result<AgentWorkTaskProgress, AgentWorkFailure> {
        self.inner.accept_extraction(result)
    }
    fn allows_baseline_read(&self) -> bool {
        self.enabled
    }
    fn evaluate(
        &mut self,
        observation: &SemanticObservation,
    ) -> Result<AgentWorkTaskProgress, AgentWorkFailure> {
        self.inner.evaluate(observation)
    }
    fn assess(
        &self,
        action: &SemanticPreparedAction,
    ) -> Result<AgentEffectAssessment, AgentWorkFailure> {
        self.inner.assess(action)
    }
    fn attest_account(
        &self,
        context: ContextJoin,
        now: AgentPolicyInstant,
    ) -> Result<AgentContextAccountBinding, AgentWorkFailure> {
        self.inner.attest_account(context, now)
    }
}

#[test]
fn long_read_workflow_closes_original_accounting_after_mid_run_audit_delivery() {
    let _serial = lock(&SERIAL);
    // Match the production 24-call ceiling, forcing acknowledged audit
    // delivery during the run before its final extraction and metric closure.
    provider_fixture(ProviderFault::Read(ReadFault::LongExtraction));
}

#[test]
fn satisfied_actions_cannot_repeat_but_a_new_value_can_still_be_filled() {
    let _serial = lock(&SERIAL);
    provider_fixture(ProviderFault::Read(ReadFault::AlreadySatisfied));
}

#[test]
fn no_progress_feedback_survives_a_cached_read_and_allows_a_different_operation() {
    let _serial = lock(&SERIAL);
    provider_fixture(ProviderFault::Read(ReadFault::NoProgress));
}

#[test]
fn read_continuations_preserve_baseline_budget_stop_and_cleanup_ownership() {
    let _serial = lock(&SERIAL);
    for fault in [
        ReadFault::None,
        ReadFault::LocateMiss,
        ReadFault::LocateMissCeiling,
        ReadFault::Extraction,
        ReadFault::AfterActionExtraction,
        ReadFault::Disabled,
        ReadFault::Subtree,
        ReadFault::Ceiling,
        ReadFault::CountRefused,
        ReadFault::StreamRefused,
        ReadFault::CancelCount,
        ReadFault::TakeoverStream,
        ReadFault::SuspendCount,
        ReadFault::ActionLost,
        ReadFault::AuditLost,
    ] {
        provider_fixture(ProviderFault::Read(fault));
    }
}
pub(super) fn assert_outcome(
    fault: ReadFault,
    outcome: AgentWorkOutcome,
    shutdown: AgentBrowserShutdownOutcome,
    calls: &[u8],
    events: &[AgentWorkEvent],
) {
    if matches!(fault, ReadFault::NoProgress | ReadFault::AlreadySatisfied) {
        let AgentWorkOutcome::Succeeded(success) = outcome else {
            panic!("{fault:?}: {outcome:?}")
        };
        assert_eq!(
            success.closure().model_calls(),
            if fault == ReadFault::NoProgress { 5 } else { 3 }
        );
        assert_eq!(success.closure().effects(), 1);
        assert_eq!(calls, [1, 2, 3, 7, 3, 4, 5, 6]);
        assert!(matches!(shutdown, AgentBrowserShutdownOutcome::Clean(_)));
        assert_eq!(
            events
                .iter()
                .filter(|event| event.kind() == AgentWorkEventKind::InspectionRefused)
                .count(),
            1
        );
        return;
    }
    if matches!(
        fault,
        ReadFault::Extraction | ReadFault::AfterActionExtraction | ReadFault::LongExtraction
    ) {
        let AgentWorkOutcome::Succeeded(mut success) = outcome else {
            panic!("{fault:?}: {outcome:?}")
        };
        let actions = u32::from(fault == ReadFault::AfterActionExtraction);
        assert_eq!(success.closure().effects(), actions);
        assert_eq!(
            success.closure().model_calls(),
            if fault == ReadFault::LongExtraction {
                24
            } else {
                3 + actions
            }
        );
        let result = success.take_extraction().unwrap();
        if actions == 1 {
            assert_ne!(result.observation(), SemanticObservationId::new(1).unwrap());
        }
        assert_eq!(
            calls.iter().filter(|call| **call == 3).count(),
            1 + actions as usize
        );
        assert_eq!(
            calls.iter().filter(|call| **call == 7).count(),
            actions as usize
        );
        assert!(matches!(shutdown, AgentBrowserShutdownOutcome::Clean(_)));
    } else if matches!(fault, ReadFault::None | ReadFault::LocateMiss) {
        let AgentWorkOutcome::Succeeded(success) = outcome else {
            panic!("{fault:?}: {outcome:?}")
        };
        assert_eq!(success.closure().model_calls(), 3);
        assert_eq!(success.closure().effects(), 1);
        assert_eq!(calls, [1, 2, 3, 7, 3, 4, 5, 6]);
        assert!(matches!(shutdown, AgentBrowserShutdownOutcome::Clean(_)));
        assert_eq!(
            events
                .iter()
                .filter(|event| event.kind()
                    == AgentWorkEventKind::ToolProposed(AgentBrowserToolKind::Read))
                .count(),
            if fault == ReadFault::LocateMiss { 1 } else { 2 }
        );
        if fault == ReadFault::LocateMiss {
            assert_eq!(
                events
                    .iter()
                    .filter(|event| event.kind()
                        == AgentWorkEventKind::ToolProposed(AgentBrowserToolKind::Locate))
                    .count(),
                1
            );
        }
    } else if matches!(fault, ReadFault::ActionLost | ReadFault::AuditLost) {
        let AgentWorkOutcome::Recovery(recovery) = outcome else {
            panic!("{fault:?}: {outcome:?}")
        };
        assert!(matches!(shutdown, AgentBrowserShutdownOutcome::Unclean));
        assert!(!events
            .iter()
            .any(|event| event.kind() == AgentWorkEventKind::Terminal));
        if fault == ReadFault::ActionLost {
            assert!(
                recovery.retained_callbacks() > 0
                    || recovery
                        .state
                        .session
                        .as_ref()
                        .is_some_and(|session| session.action.is_some())
            );
        } else {
            assert!(
                recovery
                    .state
                    .drained
                    .as_ref()
                    .unwrap()
                    .journal
                    .as_ref()
                    .unwrap()
                    .audit
                    .status()
                    .in_flight()
                    > 0
            );
        }
    } else {
        let AgentWorkOutcome::ClosedUnsuccessfully(closed) = outcome else {
            panic!("{fault:?}: {outcome:?}")
        };
        assert_eq!(closed.policy_settlement().closure().effects(), 0);
        assert!(matches!(shutdown, AgentBrowserShutdownOutcome::Clean(_)));
        assert_eq!(calls.iter().filter(|call| **call == 3).count(), 1);
        assert!(!calls.contains(&7));
        let stop = match fault {
            ReadFault::CancelCount => Some(AgentWorkFailure::Cancelled),
            ReadFault::TakeoverStream => Some(AgentWorkFailure::HumanTakeover),
            ReadFault::SuspendCount => Some(AgentWorkFailure::SuspendRequested),
            _ => None,
        };
        if let Some(stop) = stop {
            assert_eq!(closed.failure(), stop);
        }
        if matches!(fault, ReadFault::Ceiling | ReadFault::LocateMissCeiling) {
            assert_eq!(
                closed.failure(),
                AgentWorkFailure::Browser(AgentBrowserProviderError::TurnLimit)
            );
            assert_eq!(closed.policy_settlement().closure().model_calls(), 8);
        }
    }
}
