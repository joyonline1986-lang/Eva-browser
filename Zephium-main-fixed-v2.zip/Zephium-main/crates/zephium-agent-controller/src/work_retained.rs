//! Retained observation, navigation and authorized-action backing for Work.

use super::*;
use std::task::Waker;

/// How long one look may stay unanswered, queued behind other pages' looks
/// included, before the page ends as too slow instead of waiting out the
/// run's whole deadline.
const OBSERVATION_STALL: Duration = Duration::from_secs(90);
/// How long a page load may stay unsettled; slow sites settle well inside.
const NAVIGATION_STALL: Duration = Duration::from_secs(90);

/// Narrow application-owned lease adapter. The implementation retains original
/// operation slots outside the worker; no native port or registry is exposed.
/// Registration is immutable, bounded and precedes every native dispatch.
pub trait AgentWorkRetainedBrowser: Send {
    /// Returns only the original lease-bound image source broker. Registration
    /// precedes the first provider call and cannot select another native owner.
    fn screenshot_source_port(
        &self,
    ) -> Option<std::sync::Arc<dyn zephium_agentic::SemanticScreenshotSourcePort>> {
        None
    }
    /// Whether this exact retained backing can own a bounded native viewport
    /// capture callback for its leased document.
    fn supports_screenshots(&self) -> bool {
        false
    }
    /// Dispatches one already policy-bound native screenshot half. Returning
    /// `Scheduled` transfers exactly one completion obligation.
    fn dispatch_screenshot(
        &mut self,
        _request: SemanticScreenshotNativeRequest,
        _completion: SemanticScreenshotNativeCompletion,
        _now: AgentPolicyInstant,
    ) -> ContextDispatch {
        ContextDispatch::Unsupported
    }
    /// Accounts the exact screenshot callback after the runtime mailbox has
    /// transferred its terminal. This releases retained-resource exclusion;
    /// it does not validate or disclose image bytes.
    fn account_screenshot_terminal(
        &mut self,
        _now: AgentPolicyInstant,
    ) -> Result<(), AgentWorkFailure> {
        Err(crate::contract!())
    }
    /// Whether the exact backing owns authorized semantic action callbacks.
    /// This is ownership support only; the task and policy still approve
    /// effects, and the native platform may reject an unsupported recipe.
    fn supports_actions(&self) -> bool {
        false
    }
    /// Dispatches one existing policy-authorized recipe under the current lease.
    /// Synchronous refusal transfers no native callback obligation.
    fn dispatch_action(
        &mut self,
        _request: SemanticActionNativeRequest,
        _now: AgentPolicyInstant,
    ) -> ContextDispatch {
        ContextDispatch::Unsupported
    }
    /// Accounts the resource callback and returns the original native terminal
    /// to the independent policy owner, including after lease revocation.
    fn poll_action(
        &mut self,
        _now: AgentPolicyInstant,
    ) -> Result<Option<SemanticActionNativeSettlement>, AgentWorkFailure> {
        Err(crate::contract!())
    }
    /// Original-row description only; this is not read admission.
    fn binding(&self) -> &WorkBrowserReadBinding;
    /// Installs the one original worker listener, without replacing the Work sink.
    fn register_listener(&mut self, waker: Waker) -> Result<(), AgentWorkFailure>;
    /// Rearms notifications and checks exact lease, deadline and sticky health.
    fn check_health(&self, now: AgentPolicyInstant) -> Result<(), AgentWorkFailure>;
    /// Whether this exact backing supports policy-bound document transitions.
    fn supports_navigation(&self) -> bool {
        false
    }
    /// Whether the retained backing implements exact run-local native Back.
    fn supports_history_back(&self) -> bool {
        false
    }
    /// Current acknowledged observation authority, not a navigation permit.
    fn automation_state(
        &self,
        _now: AgentPolicyInstant,
    ) -> Result<ContextAutomationState, AgentWorkFailure> {
        Err(crate::contract!())
    }
    /// Retires old read authority and reserves one original successor owner.
    fn prepare_navigation(
        &mut self,
        _source: ContextJoin,
        _now: AgentPolicyInstant,
    ) -> Result<ContextOperationJoin, AgentWorkFailure> {
        Err(crate::contract!())
    }
    /// Explicitly accounts an original preparation that never reached dispatch.
    fn cancel_navigation_preparation(&mut self) -> Result<(), AgentWorkFailure> {
        Err(crate::contract!())
    }
    /// Binds only the original policy's active operation; no arbitrary URL port.
    fn dispatch_navigation(&mut self, _active: &AgentActiveNavigation) -> ContextDispatch {
        ContextDispatch::Unsupported
    }
    /// Dispatches an argument-free native Back bound to the policy's exact
    /// run-enrolled predecessor. The prepared navigation owner is shared with
    /// ordinary loads, so polling/terminal accounting stays identical.
    fn dispatch_history_back(&mut self, _active: &AgentActiveNavigation) -> ContextDispatch {
        ContextDispatch::Unsupported
    }
    /// Returns the original core-accounted terminal, including after revocation.
    /// The caller must settle its independent policy/audit owner before closure.
    fn poll_navigation(
        &mut self,
        _now: AgentPolicyInstant,
    ) -> Result<Option<ContextNavigationSettlement>, AgentWorkFailure> {
        Err(crate::contract!())
    }
    /// Whether a pre-dispatch NotReady may consume another initial read.
    /// One-shot capture adapters refuse retries without replacing that receipt.
    fn allows_readiness_retry(&self) -> bool {
        true
    }
    /// Reserves and dispatches one exact bounded initial read.
    fn begin_observation(&mut self, now: AgentPolicyInstant) -> Result<(), AgentWorkFailure>;
    /// Reserves an initial read with one immutable host-derived disclosure
    /// capability. Legacy adapters remain restricted by default.
    fn begin_observation_with_capability(
        &mut self,
        capability: WorkBrowserObservationCapability,
        now: AgentPolicyInstant,
    ) -> Result<(), AgentWorkFailure> {
        if capability != WorkBrowserObservationCapability::RESTRICTED {
            return Err(crate::contract!());
        }
        self.begin_observation(now)
    }
    /// Whether the original observation owner supports acknowledged expansions.
    fn supports_expansion(&self) -> bool {
        false
    }
    /// One exact same-document capture; no ordinary read or native effect.
    fn begin_expansion(
        &mut self,
        _previous: &SemanticObservation,
        _acknowledgement: &SemanticObservationAcknowledgement,
        _target: SemanticReferenceId,
        _kind: SemanticExpansionKind,
        _now: AgentPolicyInstant,
    ) -> Result<(), AgentWorkFailure> {
        Err(crate::contract!())
    }
    /// Reserves an expansion with the same immutable disclosure capability.
    /// Legacy adapters remain restricted by default.
    fn begin_expansion_with_capability(
        &mut self,
        previous: &SemanticObservation,
        acknowledgement: &SemanticObservationAcknowledgement,
        target: SemanticReferenceId,
        kind: SemanticExpansionKind,
        capability: WorkBrowserObservationCapability,
        now: AgentPolicyInstant,
    ) -> Result<(), AgentWorkFailure> {
        if capability != WorkBrowserObservationCapability::RESTRICTED {
            return Err(crate::contract!());
        }
        self.begin_expansion(previous, acknowledgement, target, kind, now)
    }
    /// Accounts the original terminal and returns its original observation.
    /// `InspectionAnchorLost` is reserved for an accounted, anchored expansion
    /// whose exact native result is AnchorMissing and whose original lease and
    /// document binding remain live. Initial reads, dispatch refusals and stale
    /// callbacks must not use that recoverable classification.
    fn poll_observation(
        &mut self,
        now: AgentPolicyInstant,
    ) -> Result<Option<SemanticObservation>, AgentWorkFailure>;
    /// Seals this lease before dispatch; never stops loading or destroys the page.
    fn begin_revocation(&mut self) -> Result<(), AgentWorkFailure>;
    /// Drains original read/revocation/delivery owners after the caller consumed
    /// any original navigation/action terminal. Wake is not a receipt.
    fn poll_revocation(
        &mut self,
        now: AgentPolicyInstant,
    ) -> Result<Option<WorkBrowserLeaseDeliveryProof>, AgentWorkFailure>;
}

/// Same controller algorithm on the scoped runtime, without native ownership.
pub struct AgentWorkRetainedController(pub(super) AgentWorkController);

/// Non-durable result of a scoped controller. It grants neither successor
/// admission nor global browser closure; actual worker drain is still separate.
#[must_use]
pub enum AgentWorkRetainedOutcome {
    /// Trusted task acceptance and exact accounting, not factual verification.
    Accepted {
        /// Original run accounting, not a Store acknowledgement.
        settlement: AgentRunPolicySettlement,
        /// Bounded, source-bound but explicitly model-mapped data.
        extraction: Box<SemanticOwnedExtractionResult>,
    },
    /// The run cleanly relinquished its lease after requesting a person. The
    /// application still owns the retained page, but no actor authority.
    WaitingForHuman(AgentWorkWaitingForHuman),
    /// An unsuccessful run whose original scoped operands were consumed.
    ClosedUnsuccessfully(AgentWorkClosedUnsuccessfully),
    /// Run-scoped uncertainty; the original application retains page cleanup.
    Recovery(AgentWorkRetainedRecovery),
}

/// Opaque scoped recovery, with no durable-record or native-shutdown adapter.
#[must_use]
pub struct AgentWorkRetainedRecovery(pub(super) AgentWorkRecovery);
impl AgentWorkRetainedRecovery {
    /// Prepares one explicit read of a separately constructed, freshly admitted
    /// resource in the same run/profile. The trusted application must authorize
    /// that exact document/read/account independently. This neither reuses the
    /// quarantined page nor resumes this sealed controller or its model context.
    pub fn prepare_effect_reinspection(
        &mut self,
        resources: &mut WorkBrowserResources,
        lease: &WorkBrowserExecutionLease,
        target: crate::AgentWorkEffectReadTarget,
        now: AgentPolicyInstant,
    ) -> Result<
        (
            crate::AgentWorkEffectReinspection,
            WorkBrowserObservationRequest,
        ),
        crate::AgentWorkEffectReinspectionError,
    > {
        use crate::AgentWorkEffectReinspectionError as Error;
        if self.0.state.native.action_pending || self.0.state.native_terminal.is_some() {
            return Err(Error::Unavailable);
        }
        let source = self
            .0
            .state
            .native
            .retained
            .as_ref()
            .ok_or(Error::Unavailable)?
            .binding()
            .lease()
            .resource();
        // Stable Work IDs are not registry authority. The original private
        // resource allocation must still belong to this exact registry.
        resources.phase(source).map_err(Error::Resource)?;
        let source = source.identity();
        if lease.resource().identity().work() != source.work()
            || lease.resource().identity().resource() == source.resource()
        {
            return Err(Error::Binding);
        }
        let session = self.0.state.session.as_mut().ok_or(Error::Unavailable)?;
        let account = session.account;
        session
            .action
            .as_mut()
            .ok_or(Error::Unavailable)?
            .prepare_reinspection(account, resources, lease, target, now)
    }

    /// Attaches one exact current-state record while retaining all original
    /// failed effect, policy, audit and resource owners. Foreign records return
    /// unchanged. No successful effect receipt or continuation is minted.
    pub fn record_effect_reobservation(
        &mut self,
        result: crate::AgentWorkEffectReobservation,
    ) -> Result<(), Box<crate::AgentWorkEffectReobservation>> {
        let Some(action) = self
            .0
            .state
            .session
            .as_mut()
            .and_then(|session| session.action.as_mut())
        else {
            return Err(Box::new(result));
        };
        action.record_reinspection(result)
    }

    /// Original independently observed state record, still requiring explicit
    /// reconciliation and fresh authorization before any further execution.
    pub fn effect_reobservation(&self) -> Option<&crate::AgentWorkEffectReobservation> {
        self.0
            .state
            .session
            .as_ref()?
            .action
            .as_ref()?
            .reinspection_result()
    }

    /// Content-free cause; original unresolved run owners remain retained.
    pub const fn failure(&self) -> AgentWorkFailure {
        self.0.failure
    }
    /// Closed reason the original unsuccessful cleanup could not settle.
    pub fn cleanup_failure(&self) -> Option<AgentWorkFailure> {
        self.0.state.cleanup_failure
    }
    /// Content-free original audit debt; not reconciliation or closure authority.
    pub fn audit_status(&mut self) -> Result<AgentAuditLedgerStatus, AgentWorkFailure> {
        self.0.audit_reconciliation_status()
    }
}

/// Content-free progress plus a move-only non-durable scoped outcome.
pub struct AgentWorkRetainedHandle {
    pub(super) events: Arc<Mutex<WorkEvents>>,
    pub(super) terminal: Arc<Mutex<Option<AgentWorkRetainedOutcome>>>,
}
impl AgentWorkRetainedHandle {
    /// Registers the application's bounded progress wake, without native authority.
    pub fn set_waker(&self, waker: Waker) {
        let mut events = lock(&self.events);
        events.waker = Some(waker);
        if !events.queue.is_empty() {
            events.wake();
        }
    }
    /// Queue drain status only; not scoped closure or successor permission.
    pub fn has_pending_events(&self) -> bool {
        !lock(&self.events).queue.is_empty()
    }
    /// Removes one bounded content-free event.
    pub fn take_event(&self) -> Option<AgentWorkEvent> {
        lock(&self.events).queue.pop_front()
    }
    /// Moves the original result once; not product publication/admission.
    pub fn take_outcome(&mut self) -> Option<AgentWorkRetainedOutcome> {
        lock(&self.terminal).take()
    }
}

/// No dummy port implements the retained branch. Legacy effects are absent.
pub(super) enum WorkBrowser<'a> {
    Legacy(&'a AgentRuntimeBrowser),
    Retained,
}
impl WorkBrowser<'_> {
    pub(super) fn dispatch(&self, request: ContextNativeRequest) -> ContextDispatch {
        match self {
            Self::Legacy(browser) => browser.dispatch(request),
            Self::Retained => ContextDispatch::Unsupported,
        }
    }
    pub(super) fn invoke_semantic(&self, invocation: SemanticRuntimeInvocation) -> ContextDispatch {
        match self {
            Self::Legacy(browser) => browser.invoke_semantic(invocation),
            Self::Retained => ContextDispatch::Unsupported,
        }
    }
    pub(super) fn execute_semantic_action(
        &self,
        request: SemanticActionNativeRequest,
        completion: SemanticActionNativeCompletion,
    ) -> ContextDispatch {
        match self {
            Self::Legacy(browser) => browser.execute_semantic_action(request, completion),
            Self::Retained => ContextDispatch::Unsupported,
        }
    }
    pub(super) fn capture_semantic_screenshot(
        &self,
        request: SemanticScreenshotNativeRequest,
        completion: SemanticScreenshotNativeCompletion,
    ) -> ContextDispatch {
        match self {
            Self::Legacy(browser) => browser.capture_semantic_screenshot(request, completion),
            Self::Retained => ContextDispatch::Unsupported,
        }
    }
    pub(super) fn seal_for_shutdown(
        &self,
        audit: ContextResourceAuditId,
    ) -> Result<ContextShutdownDispatch, AgentWorkFailure> {
        match self {
            Self::Legacy(browser) => Ok(browser.seal_for_shutdown(audit)),
            Self::Retained => Err(crate::contract!()),
        }
    }
}

pub(super) enum TerminalClaim {
    Legacy(zephium_agent_runtime::AgentRuntimeControllerTerminalClaim),
    Scoped(zephium_agent_runtime::AgentRuntimeScopedClaim),
}

impl AgentWorkRetainedController {
    /// Starts a trusted successor after a clean human handoff.
    ///
    /// The waiting outcome is consumed, the original run must differ, and the
    /// application must supply a freshly acquired lease for the exact retained
    /// resource. Normal constructor validation then requires a fresh initial
    /// observation and creates a new provider session; no old continuation or
    /// semantic reference can cross this boundary.
    #[allow(clippy::too_many_arguments)]
    pub fn try_new_after_human(
        waiting: AgentWorkWaitingForHuman,
        input: AgentWorkRunInput,
        browser: Box<dyn AgentWorkRetainedBrowser>,
        transport: AgentProviderTransportConfig,
        access: impl Into<super::super::AgentBrowserModelAccess>,
        audit: Arc<dyn AgentAuditPort>,
        task: Box<dyn AgentWorkTask>,
    ) -> Result<
        (
            Self,
            AgentWorkRetainedHandle,
            zephium_agent_runtime::AgentRuntimeScopedBinding,
        ),
        AgentWorkFailure,
    > {
        Self::validate_human_successor(waiting, browser.as_ref())?;
        Self::try_new(input, browser, transport, access, audit, task)
    }

    #[cfg(feature = "probe-harness")]
    #[allow(clippy::too_many_arguments)]
    /// Release-excluded successor adapter with the same one-use handoff checks.
    pub fn try_new_after_human_for_probe(
        waiting: AgentWorkWaitingForHuman,
        input: AgentWorkRunInput,
        browser: Box<dyn AgentWorkRetainedBrowser>,
        transport: AgentProviderTransport,
        access: impl Into<super::super::AgentBrowserModelAccess>,
        audit: Arc<dyn AgentAuditPort>,
        task: Box<dyn AgentWorkTask>,
    ) -> Result<
        (
            Self,
            AgentWorkRetainedHandle,
            zephium_agent_runtime::AgentRuntimeScopedBinding,
        ),
        AgentWorkFailure,
    > {
        Self::validate_human_successor(waiting, browser.as_ref())?;
        Self::try_new_for_probe(input, browser, transport, access, audit, task)
    }

    fn validate_human_successor(
        waiting: AgentWorkWaitingForHuman,
        browser: &dyn AgentWorkRetainedBrowser,
    ) -> Result<(), AgentWorkFailure> {
        let prior = waiting.request();
        let expected_resource = prior
            .retained_resource()
            .ok_or_else(|| crate::contract!())?;
        let binding = browser.binding();
        if binding.lease().resource().identity() != expected_resource
            || binding.lease().run() == prior.context().identity().owner()
            || binding.frame().context().identity().owner() != binding.lease().run()
        {
            return Err(crate::contract!());
        }
        Ok(())
    }

    /// Original dormant hard deadline, including the retained lease intersection.
    pub fn deadline(&self) -> Result<Instant, AgentWorkFailure> {
        self.0.deadline()
    }
    /// Dormant admission intent from the original approved manifest. A trusted
    /// application must receive exact Admitted and Running acknowledgements
    /// before releasing this controller's scoped runtime startup gate.
    pub fn journal_admission(
        &self,
        owner: AgentWorkIncarnation,
    ) -> Result<AgentWorkJournalMutation, AgentWorkFailure> {
        self.0.journal_admission(owner)
    }
    /// Uses a dedicated original provider transport and the same session loop.
    /// This is primitive composition, not product or durable admission.
    pub fn try_new(
        input: AgentWorkRunInput,
        browser: Box<dyn AgentWorkRetainedBrowser>,
        transport: AgentProviderTransportConfig,
        access: impl Into<super::super::AgentBrowserModelAccess>,
        audit: Arc<dyn AgentAuditPort>,
        task: Box<dyn AgentWorkTask>,
    ) -> Result<
        (
            Self,
            AgentWorkRetainedHandle,
            zephium_agent_runtime::AgentRuntimeScopedBinding,
        ),
        AgentWorkFailure,
    > {
        let transport = AgentProviderTransport::try_new(transport)
            .map_err(|_| AgentWorkFailure::Browser(AgentBrowserProviderError::Transport))?;
        Self::with_transport(
            input,
            browser,
            transport,
            access.into(),
            audit,
            task,
            AgentBrowserRetention::Stateless,
        )
    }

    /// Release-excluded loopback adapter, with the same exact original transport.
    #[cfg(feature = "probe-harness")]
    pub fn try_new_for_probe(
        input: AgentWorkRunInput,
        browser: Box<dyn AgentWorkRetainedBrowser>,
        transport: AgentProviderTransport,
        access: impl Into<super::super::AgentBrowserModelAccess>,
        audit: Arc<dyn AgentAuditPort>,
        task: Box<dyn AgentWorkTask>,
    ) -> Result<
        (
            Self,
            AgentWorkRetainedHandle,
            zephium_agent_runtime::AgentRuntimeScopedBinding,
        ),
        AgentWorkFailure,
    > {
        Self::with_transport(
            input,
            browser,
            transport,
            access.into(),
            audit,
            task,
            AgentBrowserRetention::Stateless,
        )
    }

    /// Explicit public-data diagnostic retention; absent from production builds.
    #[cfg(feature = "probe-harness")]
    pub fn try_new_for_public_probe(
        input: AgentWorkRunInput,
        browser: Box<dyn AgentWorkRetainedBrowser>,
        transport: AgentProviderTransportConfig,
        access: impl Into<super::super::AgentBrowserModelAccess>,
        audit: Arc<dyn AgentAuditPort>,
        task: Box<dyn AgentWorkTask>,
    ) -> Result<
        (
            Self,
            AgentWorkRetainedHandle,
            zephium_agent_runtime::AgentRuntimeScopedBinding,
        ),
        AgentWorkFailure,
    > {
        let transport = AgentProviderTransport::try_new(transport)
            .map_err(|_| AgentWorkFailure::Browser(AgentBrowserProviderError::Transport))?;
        Self::with_transport(
            input,
            browser,
            transport,
            access.into(),
            audit,
            task,
            AgentBrowserRetention::InspectablePublicData,
        )
    }

    #[allow(clippy::too_many_arguments)]
    fn with_transport(
        mut input: AgentWorkRunInput,
        browser: Box<dyn AgentWorkRetainedBrowser>,
        transport: AgentProviderTransport,
        access: super::super::AgentBrowserModelAccess,
        audit: Arc<dyn AgentAuditPort>,
        task: Box<dyn AgentWorkTask>,
        retention: AgentBrowserRetention,
    ) -> Result<
        (
            Self,
            AgentWorkRetainedHandle,
            zephium_agent_runtime::AgentRuntimeScopedBinding,
        ),
        AgentWorkFailure,
    > {
        let sampled_at = Instant::now();
        let now = input.settings.clock.now().map_err(|_| crate::contract!())?;
        browser.check_health(now)?;
        let binding = browser.binding();
        let origin_admitted = settled_origin_admitted(
            input.context.document_policy,
            &input.context.origin,
            binding.frame().origin(),
            binding.document(),
        );
        if binding.frame().context().identity() != input.context.identity
            || !origin_admitted
            || binding.requested_document() != &input.context.target
            || binding.document_policy() != input.context.document_policy
            || !input
                .context
                .document_policy
                .admits_final_document(binding.requested_document(), binding.document())
            || binding.storage() != input.context.storage
            || binding.isolated_public() != input.retained_resource_spec()?.isolated_public
            || binding.lease().deadline()
                > input
                    .manifest
                    .plan_node(input.lease.node())
                    .ok_or_else(|| crate::contract!())?
                    .expires_at()
            || binding.lease().deadline() <= now
        {
            return Err(crate::contract!());
        }
        input.settings.deadline = input.settings.deadline.min(
            sampled_at + Duration::from_millis(binding.lease().deadline().millis() - now.millis()),
        );
        let snapshot = transport.snapshot().map_err(|_| crate::contract!())?;
        if snapshot.is_sealed() || !snapshot.is_idle() {
            return Err(crate::contract!());
        }
        let scope = zephium_agent_runtime::AgentRuntimeScopedBinding::try_new(
            binding.lease().clone(),
            &input.manifest,
        )
        .map_err(|_| crate::contract!())?;
        let (mut controller, handle) = AgentWorkController::with_transport(
            input,
            transport,
            access,
            audit,
            task,
            retention,
            Some(browser),
        )?;
        let terminal = Arc::new(Mutex::new(None));
        controller.retained_terminal = Some(terminal.clone());
        Ok((
            Self(controller),
            AgentWorkRetainedHandle {
                events: handle.events,
                terminal,
            },
            scope,
        ))
    }
}

/// The frame a retained page starts on: the requested origin, or for a site
/// session or a results page another origin of its site the load settled on
/// (a consent or locale host), when the frame stands for that settled document.
fn settled_origin_admitted(
    policy: zephium_agentic::WorkBrowserDocumentPolicy,
    requested: &SemanticOrigin,
    frame: &SemanticOrigin,
    document: &ContextNavigationTarget,
) -> bool {
    frame == requested
        || (policy.follows_site_loads()
            && SemanticOrigin::parse(document.as_url().as_str())
                .is_ok_and(|origin| &origin == frame))
}

impl zephium_agent_runtime::AgentRuntimeScopedController for AgentWorkRetainedController {
    fn run(self: Box<Self>, mut worker: AgentRuntimeWorker) -> AgentRuntimeControllerFuture {
        Box::pin(async move {
            let mut controller = self.0;
            let registered = std::future::poll_fn(|cx| {
                std::task::Poll::Ready(
                    controller
                        .state
                        .as_mut()
                        .ok_or_else(|| crate::contract!())
                        .and_then(|state| {
                            state
                                .native
                                .retained
                                .as_mut()
                                .ok_or_else(|| crate::contract!())
                        })
                        .and_then(|browser| browser.register_listener(cx.waker().clone())),
                )
            })
            .await;
            let result = match registered {
                Ok(()) => {
                    controller
                        .execute(&mut worker, &WorkBrowser::Retained)
                        .await
                }
                Err(error) => Err(error),
            };
            if let Err(failure) = result {
                if let Some(state) = controller.state.as_mut() {
                    state.record_failure(failure);
                    let _ = state.native.revoke(&WorkBrowser::Retained);
                    if let Some(session) = &state.session {
                        session.cancel();
                    }
                }
                // Closing the session already transferred its original owners
                // into WorkDrained before audit dispatch. Always reconcile that
                // accepted callback, including after control/mailbox failure.
                let deadline = controller
                    .drain_recovery(&mut worker, &WorkBrowser::Retained)
                    .await;
                if controller
                    .state
                    .as_ref()
                    .is_some_and(|state| state.drained.is_some())
                {
                    // The initial ordinary close already chose its supervisor
                    // outcome. Do not complete it again or relabel it on stop.
                    // Original metric/audit/runtime guards may still refuse.
                    if Instant::now() < deadline
                        && controller.state.as_mut().is_some_and(|state| {
                            state
                                .journal_mut()
                                .is_ok_and(|journal| journal.audit.is_quiescent())
                        })
                    {
                        let cleanup = controller.publish_terminal(&mut worker).await;
                        if let (Err(failure), Some(state)) = (cleanup, controller.state.as_mut()) {
                            state.cleanup_failure = Some(failure);
                        }
                    }
                } else {
                    let cleanup = controller.close_retained(&mut worker, Some(deadline)).await;
                    if let (Err(failure), Some(state)) = (cleanup, controller.state.as_mut()) {
                        state.cleanup_failure = Some(failure);
                    }
                }
            }
        })
    }
}

impl WorkNative {
    pub(super) async fn next_navigation_event(
        &mut self,
        worker: &mut AgentRuntimeWorker,
        browser: &WorkBrowser<'_>,
    ) -> Result<AgentRuntimeEvent, AgentWorkFailure> {
        if self.retained.is_none() {
            return self.next_event(worker, browser).await;
        }
        self.next_retained_operation_event(worker, browser, None)
            .await
    }
    pub(super) async fn next_action_event(
        &mut self,
        worker: &mut AgentRuntimeWorker,
        browser: &WorkBrowser<'_>,
        deadline: SemanticActionExecutionInstant,
    ) -> Result<AgentRuntimeEvent, AgentWorkFailure> {
        if self.retained.is_none() {
            return self.next_event(worker, browser).await;
        }
        self.next_retained_operation_event(worker, browser, Some(deadline))
            .await
    }
    async fn next_retained_operation_event(
        &mut self,
        worker: &mut AgentRuntimeWorker,
        browser: &WorkBrowser<'_>,
        action: Option<SemanticActionExecutionInstant>,
    ) -> Result<AgentRuntimeEvent, AgentWorkFailure> {
        // Both operations already own native callback debt. Revoked document
        // health cannot prevent reconciliation of their original terminal.
        self.check_stop(worker, browser)?;
        let clock = self
            .clock
            .as_ref()
            .ok_or_else(|| crate::contract!())?
            .clone();
        let retained = self.retained.as_mut().ok_or_else(|| crate::contract!())?;
        let deadline = if let Some(deadline) = action {
            let now = clock.now().map_err(|_| crate::contract!())?;
            Instant::now()
                .checked_add(Duration::from_millis(
                    deadline.millis().saturating_sub(now.millis()),
                ))
                .ok_or_else(|| crate::contract!())?
                .min(self.deadline)
        } else {
            Instant::now()
                .checked_add(NAVIGATION_STALL)
                .map_or(self.deadline, |stall| stall.min(self.deadline))
        };
        let result = tokio::time::timeout_at(tokio::time::Instant::from_std(deadline), async {
            let event = worker.next_event();
            tokio::pin!(event);
            std::future::poll_fn(|cx| {
                // Control wins even over an already available terminal.
                if let std::task::Poll::Ready(event) = std::future::Future::poll(event.as_mut(), cx)
                {
                    return std::task::Poll::Ready(Err(event));
                }
                match clock.now().map_err(|_| crate::contract!()).and_then(|now| {
                    if action.is_some() {
                        // The original action is evidence debt, not a
                        // new admission. Poll before observing health,
                        // including when terminal publication wins the
                        // race with the resource-health notification.
                        retained
                            .poll_action(now)
                            .map(|terminal| terminal.map(AgentRuntimeEvent::SemanticActionTerminal))
                    } else {
                        // As with actions, wait for the original receipt even
                        // if health failed before its publication. Absence
                        // remains pending under the original deadline.
                        retained.poll_navigation(now).map(|terminal| {
                            terminal.map(|terminal| {
                                AgentRuntimeEvent::NativeTerminal(
                                    ContextNativeEvent::NavigationSettled(terminal),
                                )
                            })
                        })
                    }
                }) {
                    Ok(None) => std::task::Poll::Pending,
                    Ok(Some(terminal)) => std::task::Poll::Ready(Ok(Ok(terminal))),
                    Err(error) => std::task::Poll::Ready(Ok(Err(error))),
                }
            })
            .await
        })
        .await;
        match result {
            Ok(Ok(Ok(terminal))) => Ok(terminal),
            Ok(Ok(Err(error))) => Err(error),
            Ok(Err(Ok(
                AgentRuntimeEvent::CancellationRequested | AgentRuntimeEvent::ShutdownRequested,
            ))) => {
                self.check_control(worker, browser)?;
                Err(AgentWorkFailure::Mailbox)
            }
            Ok(Err(Ok(event))) => {
                self.retain(event)?;
                Err(AgentWorkFailure::Mailbox)
            }
            Ok(Err(Err(_))) => Err(AgentWorkFailure::Mailbox),
            Err(_) => Err(AgentWorkFailure::Deadline),
        }
    }
    pub(super) fn check_retained_health(&self) -> Result<(), AgentWorkFailure> {
        if let Some(browser) = &self.retained {
            let now = self
                .clock
                .as_ref()
                .ok_or_else(|| crate::contract!())?
                .now()
                .map_err(|_| crate::contract!())?;
            browser.check_health(now)?;
        }
        Ok(())
    }

    pub(super) async fn observe_retained(
        &mut self,
        worker: &mut AgentRuntimeWorker,
        capability: WorkBrowserObservationCapability,
    ) -> Result<SemanticObservation, AgentWorkFailure> {
        self.observe_retained_scope(worker, None, capability).await
    }

    pub(super) async fn observe_retained_scope(
        &mut self,
        worker: &mut AgentRuntimeWorker,
        expansion: Option<(
            &SemanticObservation,
            &SemanticObservationAcknowledgement,
            SemanticReferenceId,
            SemanticExpansionKind,
        )>,
        capability: WorkBrowserObservationCapability,
    ) -> Result<SemanticObservation, AgentWorkFailure> {
        self.check_control(worker, &WorkBrowser::Retained)?;
        let clock = self
            .clock
            .as_ref()
            .ok_or_else(|| crate::contract!())?
            .clone();
        let browser = self.retained.as_mut().ok_or_else(|| crate::contract!())?;
        let now = clock.now().map_err(|_| crate::contract!())?;
        match expansion {
            Some((previous, acknowledgement, target, kind)) => browser
                .begin_expansion_with_capability(
                    previous,
                    acknowledgement,
                    target,
                    kind,
                    capability,
                    now,
                )?,
            None => browser.begin_observation_with_capability(capability, now)?,
        }
        let stall = Instant::now()
            .checked_add(OBSERVATION_STALL)
            .map_or(self.deadline, |stall| stall.min(self.deadline));
        let result = tokio::time::timeout_at(tokio::time::Instant::from_std(stall), async {
            let event = worker.next_event();
            tokio::pin!(event);
            std::future::poll_fn(|cx| {
                if let std::task::Poll::Ready(event) = std::future::Future::poll(event.as_mut(), cx)
                {
                    return std::task::Poll::Ready(Err(event));
                }
                let result = clock.now().map_err(|_| crate::contract!()).and_then(|now| {
                    browser.check_health(now)?;
                    browser.poll_observation(now)
                });
                match result {
                    Ok(None) => std::task::Poll::Pending,
                    Ok(Some(observation)) => std::task::Poll::Ready(Ok(Ok(observation))),
                    Err(error) => std::task::Poll::Ready(Ok(Err(error))),
                }
            })
            .await
        })
        .await;
        match result {
            Ok(Ok(result)) => result,
            Ok(Err(Ok(
                AgentRuntimeEvent::CancellationRequested | AgentRuntimeEvent::ShutdownRequested,
            ))) => {
                self.check_control(worker, &WorkBrowser::Retained)?;
                Err(AgentWorkFailure::Mailbox)
            }
            Ok(Err(Ok(event))) => {
                self.retain(event)?;
                Err(AgentWorkFailure::Mailbox)
            }
            Ok(Err(Err(_))) => Err(AgentWorkFailure::Mailbox),
            Err(_) => Err(AgentWorkFailure::Deadline),
        }
    }
}

impl AgentWorkController {
    /// Reconcile resource debt after stop without inventing effect verification.
    /// The original policy owner and native terminal remain in recovery whenever
    /// cancellation prevents fresh post-action verification.
    pub(super) async fn drain_retained_action(state: &mut WorkState, deadline: Instant) {
        if state.native.retained.is_none() || !state.native.action_pending {
            return;
        }
        let Some(clock) = state.native.clock.clone() else {
            return;
        };
        let Some(browser) = state.native.retained.as_mut() else {
            return;
        };
        let terminal = tokio::time::timeout_at(
            tokio::time::Instant::from_std(deadline),
            std::future::poll_fn(|_| {
                match clock
                    .now()
                    .map_err(|_| crate::contract!())
                    .and_then(|now| browser.poll_action(now))
                {
                    Ok(None) => std::task::Poll::Pending,
                    Ok(Some(terminal)) => std::task::Poll::Ready(Some(terminal)),
                    Err(_) => std::task::Poll::Ready(None),
                }
            }),
        )
        .await
        .ok()
        .flatten();
        if let Some(terminal) = terminal {
            if state.session.as_ref().is_some_and(|session| {
                session.action.as_ref().is_some_and(|action| {
                    action.accepts_settlement(&session.action_executions, &terminal)
                })
            }) {
                state.native.action_pending = false;
            }
            let _ = state
                .native
                .retain(AgentRuntimeEvent::SemanticActionTerminal(terminal));
        }
    }
    /// Resource receipt and policy/audit receipt are two independent owners.
    /// Stop cannot discard the former while leaving the latter unaccounted.
    pub(super) async fn drain_retained_navigation(state: &mut WorkState, deadline: Instant) {
        if state.native.retained.is_none() || state.native.operation.is_none() {
            return;
        }
        let operation = state.native.operation;
        let deferred = state.native.deferred.iter().position(|event| {
            matches!(event,
            AgentRuntimeEvent::NativeTerminal(ContextNativeEvent::NavigationSettled(terminal))
            if Some(terminal.operation()) == operation)
        });
        let terminal = if let Some(index) = deferred {
            match state.native.deferred.remove(index) {
                AgentRuntimeEvent::NativeTerminal(ContextNativeEvent::NavigationSettled(
                    terminal,
                )) => Some(terminal),
                _ => None,
            }
        } else {
            let Some(clock) = state.native.clock.clone() else {
                return;
            };
            let Some(browser) = state.native.retained.as_mut() else {
                return;
            };
            tokio::time::timeout_at(
                tokio::time::Instant::from_std(deadline),
                std::future::poll_fn(|_| {
                    match clock
                        .now()
                        .map_err(|_| crate::contract!())
                        .and_then(|now| browser.poll_navigation(now))
                    {
                        Ok(None) => std::task::Poll::Pending,
                        Ok(Some(terminal)) => std::task::Poll::Ready(Some(terminal)),
                        Err(_) => std::task::Poll::Ready(None),
                    }
                }),
            )
            .await
            .ok()
            .flatten()
        };
        let Some(terminal) = terminal else {
            return;
        };
        if Some(terminal.operation()) == operation
            && state
                .session
                .as_mut()
                .is_some_and(|session| session.settle_navigation_terminal(&terminal).is_ok())
        {
            state.native.operation = None;
        } else {
            let _ = state.native.retain(AgentRuntimeEvent::NativeTerminal(
                ContextNativeEvent::NavigationSettled(terminal),
            ));
        }
    }
    pub(super) async fn close_retained(
        &mut self,
        worker: &mut AgentRuntimeWorker,
        cleanup: Option<Instant>,
    ) -> Result<(), AgentWorkFailure> {
        let state = self.state.as_mut().ok_or_else(|| crate::contract!())?;
        if state.drained.is_some() || state.native.resources.is_some() {
            return Err(crate::contract!());
        }
        let terminal_intent = match cleanup {
            Some(_) => WorkTerminalIntent::ClosedUnsuccessfully(
                state.failure.ok_or_else(|| crate::contract!())?,
            ),
            None => state.model_human_request.map_or(
                WorkTerminalIntent::Succeeded,
                WorkTerminalIntent::WaitingForHuman,
            ),
        };
        // A retained accepted outcome must contain the independently accepted
        // source-bound result; task `Complete` before mapping is insufficient.
        let waiting = matches!(terminal_intent, WorkTerminalIntent::WaitingForHuman(_));
        if cleanup.is_none() && state.extraction.is_none() && !waiting {
            return Err(crate::contract!());
        }
        if cleanup.is_none() {
            state.native.check_control(worker, &WorkBrowser::Retained)?;
        }
        state.native.revoke(&WorkBrowser::Retained)?;
        let deadline = cleanup.unwrap_or(state.native.deadline);
        let clock = state
            .native
            .clock
            .as_ref()
            .ok_or_else(|| crate::contract!())?
            .clone();
        let browser = state
            .native
            .retained
            .as_mut()
            .ok_or_else(|| crate::contract!())?;
        if state.native.retained_delivery.is_none() {
            let delivery = tokio::time::timeout_at(
                tokio::time::Instant::from_std(deadline),
                std::future::poll_fn(|_| {
                    match clock
                        .now()
                        .map_err(|_| crate::contract!())
                        .and_then(|now| browser.poll_revocation(now))
                    {
                        Ok(None) => std::task::Poll::Pending,
                        Ok(Some(proof)) => std::task::Poll::Ready(Ok(proof)),
                        Err(error) => std::task::Poll::Ready(Err(error)),
                    }
                }),
            )
            .await
            .map_err(|_| AgentWorkFailure::Deadline)??;
            state.native.retained_delivery = Some(delivery);
        }
        let session = state.session.take().ok_or_else(|| crate::contract!())?;
        let terminal = match if !matches!(terminal_intent, WorkTerminalIntent::Succeeded) {
            session.try_finish_unsuccessful()
        } else {
            session.try_finish()
        } {
            Ok(terminal) => terminal,
            Err(refusal) => {
                let error = refusal.error();
                state.session = Some(refusal.into_session());
                return Err(AgentWorkFailure::Browser(error));
            }
        };
        if state.terminal_intent.replace(terminal_intent).is_some() {
            state.session = Some(*terminal.session);
            return Err(crate::contract!());
        }
        state.model_human_request = None;
        // Mirror the legacy closure boundary: an accepted model handoff whose
        // provider session is now closed wins over a later stop, while exact
        // retained/audit debt must still settle within the original deadline.
        let cleanup = cleanup.or_else(|| waiting.then_some(state.native.deadline));
        let AgentBrowserSession {
            policy,
            journal,
            action_proposal_failure,
            ..
        } = *terminal.session;
        state.drained = Some(WorkDrained {
            proposal_refusal: action_proposal_failure,
            policy: Some(policy),
            journal,
            provider: Some(terminal.provider),
            native: None,
            resources: None,
            proof: None,
            delivery: state.native.retained_delivery.take(),
            scoped_refusal: None,
        });
        self.finish_accounting(
            worker,
            &WorkBrowser::Retained,
            Some(deadline).filter(|_| cleanup.is_some()),
        )
        .await
    }
}

#[cfg(test)]
mod settled_origin_tests {
    use super::*;

    #[test]
    fn a_site_session_starts_on_the_origin_its_load_settled_on() {
        use zephium_agentic::WorkBrowserDocumentPolicy as Policy;
        let origin = |url: &str| SemanticOrigin::parse(url).unwrap();
        let target = |url: &str| ContextNavigationTarget::parse(url).unwrap();
        let requested = origin("https://www.google.com/");
        let consent = target("https://consent.google.com/m?hl=en");
        assert!(settled_origin_admitted(
            Policy::SiteSession,
            &requested,
            &origin("https://consent.google.com/"),
            &consent
        ));
        // The frame must stand for the settled document.
        assert!(!settled_origin_admitted(
            Policy::SiteSession,
            &requested,
            &origin("https://accounts.google.com/"),
            &consent
        ));
        assert!(settled_origin_admitted(
            Policy::PublicResultsPage,
            &requested,
            &origin("https://consent.google.com/"),
            &consent
        ));
        // Other policies keep the exact origin.
        assert!(!settled_origin_admitted(
            Policy::Exact,
            &requested,
            &origin("https://consent.google.com/"),
            &consent
        ));
        assert!(settled_origin_admitted(
            Policy::Exact,
            &requested,
            &requested,
            &target("https://www.google.com/travel/flights")
        ));
    }
}
