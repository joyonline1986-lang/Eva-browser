//! Real Store acknowledgements held independently of committed durable facts.
use super::*;
use crate::work_resources::application::*;
use std::collections::VecDeque;

#[derive(Default)]
struct ReviewJournal(Mutex<VecDeque<(AgentWorkJournalRequest, AgentWorkJournalCompletion)>>);
impl AgentAuditPort for ReviewJournal {
    fn append(&self, _: AgentAuditDelivery, _: AgentAuditCompletion) -> AgentAuditDispatch {
        panic!("historical review must not dispatch an audit or execute")
    }
}
impl AgentWorkJournalPort for ReviewJournal {
    fn dispatch(
        &self,
        request: AgentWorkJournalRequest,
        completion: AgentWorkJournalCompletion,
    ) -> Result<(), AgentWorkJournalError> {
        self.0.lock().unwrap().push_back((request, completion));
        Ok(())
    }
}
fn interrupted_record(owner: AgentWorkIncarnation, index: u8) -> AgentWorkRecord {
    let mut bytes = [0; AGENT_WORK_RECORD_BYTES];
    bytes[0] = 1;
    bytes[1] = AgentWorkDisposition::Interrupted as u8;
    bytes[2] = AgentWorkDebt::UNKNOWN.bits();
    bytes[15] = 3;
    bytes[16..32].copy_from_slice(&owner.bytes());
    bytes[47] = index;
    AgentWorkRecord::decode(bytes).unwrap()
}
fn review_coordinator(
    records: Vec<AgentWorkRecord>,
    incarnation: AgentWorkIncarnation,
) -> (RetainedWork, Arc<Native>, Arc<ReviewJournal>) {
    let (owner, native, resource) = construct_fixture(
        ContextProfileStorageClass::Ephemeral,
        WorkBrowserDocumentPolicy::Exact,
        None,
    );
    native.allow_global_shutdown.store(true, Ordering::Release);
    let journal = Arc::new(ReviewJournal::default());
    let mut work = RetainedWork::new(owner, resource, journal.clone(), journal.clone())
        .unwrap_or_else(|_| panic!("fixture construction"));
    let (request, completion) = journal.0.lock().unwrap().pop_front().unwrap();
    assert!(matches!(request, AgentWorkJournalRequest::Claim));
    completion(Ok(AgentWorkJournalReply::Claimed {
        owner: incarnation,
        records,
    }));
    work.poll(now());
    (work, native, journal)
}

#[test]
fn historical_review_requires_each_exact_ack_and_never_settles_debt_or_executes() {
    let incarnation = AgentWorkIncarnation::generate();
    let first = interrupted_record(incarnation, 1);
    let second = interrupted_record(incarnation, 2);
    let (mut work, native, journal) = review_coordinator(vec![first, second], incarnation);
    assert_eq!(work.phase(), AdmissionPhase::NeedsReview);
    assert!(!work.ready());
    let foreign = interrupted_record(AgentWorkIncarnation::generate(), 1);
    work.review(foreign, crate::AgentWorkReviewDecision::Reject);
    assert_eq!(
        work.last_review(),
        Some(Err(AgentWorkJournalError::Conflict))
    );
    assert!(journal.0.lock().unwrap().is_empty());
    for (record, decision, remaining) in [
        (
            first,
            crate::AgentWorkReviewDecision::AcceptFreshAdmission,
            true,
        ),
        (second, crate::AgentWorkReviewDecision::Reject, false),
    ] {
        work.review(record, decision);
        assert_eq!(work.phase(), AdmissionPhase::Reviewing);
        assert!(!work.ready());
        work.review(record, decision);
        assert_eq!(journal.0.lock().unwrap().len(), 1);
        let (request, completion) = journal.0.lock().unwrap().pop_front().unwrap();
        let AgentWorkJournalRequest::CompareAndSet(mutation) = request else {
            panic!("review CAS");
        };
        assert_eq!(mutation.expected(), Some(record));
        let next = mutation.next();
        assert_eq!(next.debt(), AgentWorkDebt::UNKNOWN);
        assert_eq!(next.revision(), record.revision() + 1);
        assert!(
            work.records().contains(&record),
            "a committed write without ACK is not admission"
        );
        completion(Ok(AgentWorkJournalReply::Record(Some(next))));
        work.poll(now());
        assert_eq!(work.last_review(), Some(Ok(next)));
        assert_eq!(work.ready(), !remaining);
        work.review(record, decision);
        assert!(
            work.last_review().unwrap().is_err(),
            "stale review cannot replay"
        );
        assert!(journal.0.lock().unwrap().is_empty());
    }
    assert!(
        work.record().is_none(),
        "review does not become the new actor record"
    );
    assert_eq!(native.acquisitions.load(Ordering::Acquire), 0);
    assert_eq!(native.reads.load(Ordering::Acquire), 0);
    assert_eq!(native.actions.load(Ordering::Acquire), 0);
}

#[test]
fn reviewed_history_allows_fresh_resources_but_unreviewed_or_foreign_history_does_not() {
    let prior = AgentWorkIncarnation::generate();
    let current = AgentWorkIncarnation::generate();
    let interrupted = interrupted_record(prior, 1);
    // FailedClosed is the coordinator's own terminal classification of an
    // actor that never started; no review can follow it.
    for disposition in [
        AgentWorkDisposition::FreshAdmissionRequired,
        AgentWorkDisposition::Rejected,
        AgentWorkDisposition::FailedClosed,
    ] {
        let reviewed = interrupted.transition(disposition).unwrap();
        let (work, native, _) = review_coordinator(vec![reviewed], current);
        assert!(work.ready());
        assert_eq!(work.records(), &[reviewed]);
        assert_eq!(reviewed.debt(), AgentWorkDebt::UNKNOWN);
        assert_eq!(native.acquisitions.load(Ordering::Acquire), 0);
    }
    for disposition in [
        AgentWorkDisposition::Interrupted,
        AgentWorkDisposition::RecoveryRequired,
        AgentWorkDisposition::NeedsApproval,
    ] {
        let mut bytes = *interrupted.as_bytes();
        bytes[1] = disposition as u8;
        let record = AgentWorkRecord::decode(bytes).unwrap();
        let (work, native, _) = review_coordinator(vec![record], current);
        assert!(!work.ready());
        assert_eq!(work.phase(), AdmissionPhase::Uncertain);
        assert_eq!(native.acquisitions.load(Ordering::Acquire), 0);
    }
}

#[test]
fn own_recovery_record_is_reviewable_like_an_interruption() {
    let current = AgentWorkIncarnation::generate();
    let mut bytes = *interrupted_record(current, 1).as_bytes();
    bytes[1] = AgentWorkDisposition::RecoveryRequired as u8;
    let record = AgentWorkRecord::decode(bytes).unwrap();
    let (mut work, native, journal) = review_coordinator(vec![record], current);
    assert_eq!(work.phase(), AdmissionPhase::NeedsReview);
    work.review(record, crate::AgentWorkReviewDecision::AcceptFreshAdmission);
    assert_eq!(work.phase(), AdmissionPhase::Reviewing);
    let (request, completion) = journal.0.lock().unwrap().pop_front().unwrap();
    let AgentWorkJournalRequest::CompareAndSet(mutation) = request else {
        panic!("review CAS");
    };
    assert_eq!(
        mutation.next().disposition(),
        AgentWorkDisposition::FreshAdmissionRequired
    );
    assert_eq!(mutation.next().debt(), AgentWorkDebt::UNKNOWN);
    completion(Ok(AgentWorkJournalReply::Record(Some(mutation.next()))));
    work.poll(now());
    assert!(work.ready());
    assert_eq!(native.acquisitions.load(Ordering::Acquire), 0);
}

#[test]
fn group_pages_share_one_review_of_the_same_recovery_row() {
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    let current = AgentWorkIncarnation::generate();
    let mut bytes = *interrupted_record(current, 1).as_bytes();
    bytes[1] = AgentWorkDisposition::RecoveryRequired as u8;
    let record = AgentWorkRecord::decode(bytes).unwrap();
    let group = RetainedWorkGroup::try_new(WorkId::generate(), 2).unwrap();
    let (mut first, _, first_journal) = review_coordinator(vec![record], current);
    let (mut second, native, second_journal) = review_coordinator(vec![record], current);
    first.set_runtime_group(group.clone());
    second.set_runtime_group(group);
    let accept = crate::AgentWorkReviewDecision::AcceptFreshAdmission;
    first.review(record, accept);
    assert_eq!(first.phase(), AdmissionPhase::Reviewing);
    second.review(record, accept);
    assert_eq!(
        second.last_review(),
        Some(Err(AgentWorkJournalError::Unavailable))
    );
    assert_eq!(second.phase(), AdmissionPhase::NeedsReview);
    let (request, completion) = first_journal.0.lock().unwrap().pop_front().unwrap();
    let AgentWorkJournalRequest::CompareAndSet(mutation) = request else {
        panic!("review CAS");
    };
    let next = mutation.next();
    completion(Ok(AgentWorkJournalReply::Record(Some(next))));
    first.poll(now());
    assert!(first.ready());
    // The peer takes the acknowledged row; it never races a second CAS.
    second.review(record, accept);
    assert!(second_journal.0.lock().unwrap().is_empty());
    assert_eq!(second.last_review(), Some(Ok(next)));
    assert_eq!(second.records(), &[next]);
    assert!(second.ready());
    assert_eq!(native.acquisitions.load(Ordering::Acquire), 0);
}

#[test]
fn historical_review_bad_ack_and_stop_cannot_reopen_admission() {
    for stop in [false, true] {
        let incarnation = AgentWorkIncarnation::generate();
        let record = interrupted_record(incarnation, 1);
        let (mut work, native, journal) = review_coordinator(vec![record], incarnation);
        work.review(record, crate::AgentWorkReviewDecision::AcceptFreshAdmission);
        let (request, completion) = journal.0.lock().unwrap().pop_front().unwrap();
        let AgentWorkJournalRequest::CompareAndSet(mutation) = request else {
            panic!("review CAS");
        };
        if stop {
            work.cancel();
        }
        completion(Ok(AgentWorkJournalReply::Record(Some(if stop {
            mutation.next()
        } else {
            record
        }))));
        work.poll(now());
        assert_eq!(work.phase(), AdmissionPhase::Uncertain);
        assert!(!work.ready());
        assert_eq!(native.acquisitions.load(Ordering::Acquire), 0);
    }
}

type Held = (
    Result<AgentWorkJournalReply, AgentWorkJournalError>,
    AgentWorkJournalCompletion,
);
type HeldArtifact = (
    Result<AgentWorkArtifactReply, AgentWorkJournalError>,
    AgentWorkArtifactCompletion,
);
struct GatedStore {
    store: Arc<zephium_store::SqliteStore>,
    hold: Arc<AtomicU8>,
    pending: Arc<Mutex<Option<Held>>>,
    resent: Arc<Mutex<Vec<Held>>>,
    // Answers the first CAS to this disposition Uncertain without writing it.
    refuse_once: AtomicU8,
    pending_artifact: Arc<Mutex<Option<HeldArtifact>>>,
    refuse_artifact_read: AtomicBool,
    wakes: Arc<AtomicUsize>,
    held_signal: Arc<Mutex<Option<mpsc::SyncSender<()>>>>,
}
impl AgentAuditPort for GatedStore {
    fn append(
        &self,
        delivery: AgentAuditDelivery,
        completion: AgentAuditCompletion,
    ) -> AgentAuditDispatch {
        self.store.append(delivery, completion)
    }
}
impl AgentWorkJournalPort for GatedStore {
    fn artifact(
        &self,
        request: AgentWorkArtifactRequest,
        completion: AgentWorkArtifactCompletion,
    ) -> Result<(), AgentWorkJournalError> {
        if matches!(request, AgentWorkArtifactRequest::Read { .. })
            && self.refuse_artifact_read.load(Ordering::Acquire)
        {
            return Err(AgentWorkJournalError::Unavailable);
        }
        let held = matches!(request, AgentWorkArtifactRequest::Publish(_))
            && self.hold.load(Ordering::Acquire) == AgentWorkDisposition::Succeeded as u8;
        let pending = self.pending_artifact.clone();
        self.store.artifact(
            request,
            Box::new(move |reply| {
                if held {
                    assert!(pending
                        .lock()
                        .unwrap()
                        .replace((reply, completion))
                        .is_none());
                } else {
                    completion(reply);
                }
            }),
        )
    }
    fn dispatch(
        &self,
        request: AgentWorkJournalRequest,
        completion: AgentWorkJournalCompletion,
    ) -> Result<(), AgentWorkJournalError> {
        if let AgentWorkJournalRequest::CompareAndSet(mutation) = &request {
            let disposition = mutation.next().disposition() as u8;
            if self
                .refuse_once
                .compare_exchange(disposition, 0, Ordering::AcqRel, Ordering::Acquire)
                .is_ok()
            {
                completion(Err(AgentWorkJournalError::Uncertain));
                return Ok(());
            }
        }
        let held = match &request {
            AgentWorkJournalRequest::CompareAndSet(mutation) => {
                self.hold.load(Ordering::Acquire) == mutation.next().disposition() as u8
            }
            _ => false,
        };
        let pending = self.pending.clone();
        let resent = self.resent.clone();
        let held_signal = self.held_signal.clone();
        self.store.dispatch(
            request,
            Box::new(move |reply| {
                if held {
                    let mut slot = pending.lock().unwrap();
                    // The coordinator resends an uncertain request on its own.
                    if slot.is_some() {
                        resent.lock().unwrap().push((reply, completion));
                    } else {
                        *slot = Some((reply, completion));
                    }
                    drop(slot);
                    if let Some(signal) = held_signal.lock().unwrap().as_ref() {
                        signal.send(()).unwrap();
                    }
                } else {
                    completion(reply);
                }
            }),
        )
    }
}
impl GatedStore {
    fn release(&self, next: u8) {
        self.hold.store(next, Ordering::Release);
        let (reply, completion) = self.pending.lock().unwrap().take().unwrap();
        completion(reply);
    }
}
fn child(test: &str) -> bool {
    const CHILD: &str = "ZEPHIUM_RETAINED_ADMISSION_CHILD";
    if std::env::var_os(CHILD).is_some() {
        return false;
    }
    let result = std::process::Command::new(std::env::current_exe().unwrap())
        .args([
            "--exact",
            &format!("work_resources::controller::tests::application_tests::{test}"),
            "--nocapture",
        ])
        .env(CHILD, "1")
        .output()
        .unwrap();
    assert!(
        result.status.success(),
        "retained admission child: {result:?}"
    );
    true
}

/// A second page claiming from the same open Store, as a later page does.
fn coordinator_beside(store: &Arc<GatedStore>) -> (RetainedWork, Arc<Native>) {
    let (owner, native, resource) = construct_fixture_with_wake(
        ContextProfileStorageClass::Ephemeral,
        WorkBrowserDocumentPolicy::Exact,
        None,
        Arc::new(|| true),
    );
    native.allow_global_shutdown.store(true, Ordering::Release);
    let work = RetainedWork::new(owner, resource, store.clone(), store.clone())
        .unwrap_or_else(|_| panic!("original owner and Store join"));
    (work, native)
}

fn coordinator(directory: &std::path::Path) -> (RetainedWork, Arc<Native>, Arc<GatedStore>) {
    coordinator_with_wake(directory, Arc::new(|| true))
}

fn coordinator_with_wake(
    directory: &std::path::Path,
    wake: WakeApplication,
) -> (RetainedWork, Arc<Native>, Arc<GatedStore>) {
    coordinator_with_storage(directory, wake, ContextProfileStorageClass::Ephemeral)
}

fn coordinator_with_storage(
    directory: &std::path::Path,
    wake: WakeApplication,
    storage: ContextProfileStorageClass,
) -> (RetainedWork, Arc<Native>, Arc<GatedStore>) {
    let store = Arc::new(GatedStore {
        store: Arc::new(zephium_store::SqliteStore::open(directory).unwrap()),
        hold: Arc::new(AtomicU8::new(0)),
        pending: Arc::new(Mutex::new(None)),
        resent: Arc::new(Mutex::new(Vec::new())),
        refuse_once: AtomicU8::new(0),
        pending_artifact: Arc::new(Mutex::new(None)),
        refuse_artifact_read: AtomicBool::new(false),
        wakes: Arc::new(AtomicUsize::new(0)),
        held_signal: Arc::new(Mutex::new(None)),
    });
    let wakes = store.wakes.clone();
    let (owner, native, resource) = construct_fixture_with_wake(
        storage,
        WorkBrowserDocumentPolicy::Exact,
        None,
        Arc::new(move || {
            wakes.fetch_add(1, Ordering::AcqRel);
            wake()
        }),
    );
    native.allow_global_shutdown.store(true, Ordering::Release);
    if storage == ContextProfileStorageClass::Durable {
        use zephium_core::{
            ports::store::Store,
            profiles::ProfileKind,
            session::{PersistedProfile, PersistedSpace, SessionState},
        };
        let profile = resource.identity().profile();
        let space = zephium_core::ids::SpaceId::generate();
        store.store.save_session(SessionState {
            profiles: vec![PersistedProfile {
                id: profile,
                name: "Fixture".into(),
                kind: ProfileKind::Default,
            }],
            spaces: vec![PersistedSpace {
                id: space,
                profile,
                name: "Fixture".into(),
                look: Default::default(),
            }],
            items: vec![],
            active_space: Some(space),
            active_item: None,
            splits: None,
            recently_closed: vec![],
        });
        assert!(store.store.flush());
    }
    let work = RetainedWork::new(owner, resource, store.clone(), store.clone())
        .unwrap_or_else(|_| panic!("original owner and Store join"));
    (work, native, store)
}

struct TaskExitGate {
    task: AgentWorkExtractionTask,
    entered: mpsc::SyncSender<()>,
    release: mpsc::Receiver<()>,
}
impl AgentWorkTask for TaskExitGate {
    fn extraction_schema(&self) -> Option<&SemanticExtractionSchema> {
        self.task.extraction_schema()
    }
    fn accept_extraction(
        &mut self,
        result: &SemanticExtractionResult<'_>,
    ) -> Result<AgentWorkTaskProgress, AgentWorkFailure> {
        self.task.accept_extraction(result)
    }
    fn evaluate(
        &mut self,
        observation: &SemanticObservation,
    ) -> Result<AgentWorkTaskProgress, AgentWorkFailure> {
        self.task.evaluate(observation)
    }
    fn assess(
        &self,
        action: &SemanticPreparedAction,
    ) -> Result<AgentEffectAssessment, AgentWorkFailure> {
        self.task.assess(action)
    }
    fn attest_account(
        &self,
        context: ContextJoin,
        now: AgentPolicyInstant,
    ) -> Result<AgentContextAccountBinding, AgentWorkFailure> {
        self.task.attest_account(context, now)
    }
}
impl Drop for TaskExitGate {
    fn drop(&mut self) {
        // The common controller publishes Terminal, then drops its task, and
        // only afterwards can the original worker publish completion.
        self.entered.send(()).unwrap();
        self.release.recv_timeout(Duration::from_secs(5)).unwrap();
    }
}

#[test]
fn worker_exit_wakes_application_after_last_progress_wake_was_consumed() {
    if child("worker_exit_wakes_application_after_last_progress_wake_was_consumed") {
        return;
    }
    worker_exit_wake(false, false);
}

#[test]
fn blocking_shutdown_joins_original_worker_store_and_native_wakes_without_shell_commands() {
    if child(
        "blocking_shutdown_joins_original_worker_store_and_native_wakes_without_shell_commands",
    ) {
        return;
    }
    worker_exit_wake(true, false);
}

#[test]
fn shutdown_passes_its_deadline_through_post_completion_scoped_thread_join() {
    if child("shutdown_passes_its_deadline_through_post_completion_scoped_thread_join") {
        return;
    }
    worker_exit_wake(false, true);
}

fn worker_exit_wake(blocking_shutdown: bool, post_completion: bool) {
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let directory = tempfile::tempdir().unwrap();
    let (wake, wakes) = mpsc::sync_channel(1);
    let hold_completion = Arc::new(AtomicBool::new(false));
    let holding_completion = hold_completion.clone();
    let (completion_entered, completion_entering) = mpsc::sync_channel(1);
    let (completion_release, completion_releasing) = mpsc::sync_channel(1);
    let completion_releasing = Mutex::new(completion_releasing);
    let (mut work, native, store) = coordinator_with_wake(
        directory.path(),
        Arc::new(move || {
            if holding_completion.swap(false, Ordering::AcqRel) {
                completion_entered.send(()).unwrap();
                completion_releasing
                    .lock()
                    .unwrap()
                    .recv_timeout(Duration::from_secs(2))
                    .unwrap();
            }
            match wake.try_send(()) {
                Ok(()) | Err(mpsc::TrySendError::Full(())) => true,
                Err(mpsc::TrySendError::Disconnected(())) => false,
            }
        }),
    );
    // No periodic/blind polling. Every poll below is driven by the exact
    // original application wake, with timeout used only as test failure.
    while !work.ready() {
        wakes
            .recv_timeout(Duration::from_secs(2))
            .expect("Store claim wake");
        work.poll(now());
    }
    let (entered, entering) = mpsc::sync_channel(1);
    let (release, releasing) = mpsc::sync_channel(1);
    let (server_tx, server_rx) = mpsc::sync_channel(1);
    let request = ActorRequest {
        run: ContextRunId::generate(),
        deadline: AgentPolicyInstant::from_millis(600_002),
        prepare: Box::new(move |browser, audit, waiting| {
            if waiting.is_some() {
                return Err(AgentWorkFailure::Contract);
            }
            let input = input(browser.binding(), Arc::new(Clock(AtomicU64::new(2))));
            let (transport, server) =
                fixture_provider_responses(vec![response_stream(1), response_stream(2)]);
            server_tx.send(server).unwrap();
            StagedActor::for_probe(
                input,
                browser,
                transport,
                AgentProviderCredential::try_new(
                    AgentProviderKind::OpenAiResponses,
                    "fixture-not-a-secret".into(),
                )
                .unwrap(),
                audit,
                Box::new(TaskExitGate {
                    task: task(),
                    entered,
                    release: releasing,
                }),
            )
        }),
    };
    assert!(work.submit(request, now()).is_ok());
    let mut terminal = false;
    while !terminal {
        wakes
            .recv_timeout(Duration::from_secs(2))
            .expect("original progress wake");
        work.poll(now());
        while let Some(event) = work.take_event() {
            terminal |= matches!(event.kind(), AgentWorkEventKind::Terminal);
        }
    }
    entering.recv_timeout(Duration::from_secs(2)).unwrap();
    native.join();
    assert_eq!(
        server_rx
            .recv_timeout(Duration::from_secs(2))
            .unwrap()
            .join()
            .unwrap(),
        2
    );
    while wakes.try_recv().is_ok() {
        work.poll(now());
        drain_events(&mut work);
    }
    assert_eq!(work.phase(), AdmissionPhase::Running);
    assert_eq!(
        work.record().unwrap().disposition(),
        AgentWorkDisposition::Running
    );
    assert!(
        work.next_deadline().is_none(),
        "no timer may hide the missing completion wake"
    );
    if post_completion {
        // All progress/native wakes have been consumed. The next notification
        // is completion.mark_stopped's own Waker, invoked after stopped=true
        // but before worker_main/Tokio/thread-local teardown can return.
        hold_completion.store(true, Ordering::Release);
        release.send(()).unwrap();
        completion_entering
            .recv_timeout(Duration::from_secs(2))
            .unwrap();
        let result = std::thread::scope(|scope| {
            let (finished, finishing) = mpsc::channel();
            let work = &mut work;
            scope.spawn(move || {
                let result = work.shutdown_until(
                    &Clock(AtomicU64::new(2)),
                    Instant::now() + Duration::from_millis(10),
                );
                let _ = finished.send(result);
            });
            let result = finishing.recv_timeout(Duration::from_millis(70));
            completion_release.send(()).unwrap();
            result
        });
        assert!(
            matches!(result, Ok(false)),
            "caller deadline must cap scoped join, not a fresh 100 ms window: {result:?}"
        );
        assert_eq!(work.phase(), AdmissionPhase::Uncertain);
        return;
    }
    if blocking_shutdown {
        assert!(!work.shutdown_until(
            &Clock(AtomicU64::new(2)),
            Instant::now() + Duration::from_millis(20)
        ));
        assert!(
            !work.resource_destroyed(),
            "unfinished original worker stays owned"
        );
        assert_eq!(native.destructions.load(Ordering::Acquire), 0);
        let (held, holding) = mpsc::sync_channel(1);
        *store.held_signal.lock().unwrap() = Some(held);
        store
            .hold
            .store(AgentWorkDisposition::Succeeded as u8, Ordering::Release);
        let deliver = std::thread::spawn(move || {
            release.send(()).unwrap();
            holding
                .recv_timeout(Duration::from_secs(2))
                .expect("original terminal CAS callback");
            store.release(0);
        });
        assert!(work.shutdown_until(
            &Clock(AtomicU64::new(2)),
            Instant::now() + Duration::from_secs(3)
        ));
        deliver.join().unwrap();
        assert!(work.resource_destroyed());
        assert_eq!(native.global_audits.load(Ordering::Acquire), 1);
        assert_eq!(
            work.record().unwrap().disposition(),
            AgentWorkDisposition::Succeeded
        );
        assert!(work.take_extraction().is_some());
        return;
    }
    release.send(()).unwrap();
    while work.phase() != AdmissionPhase::Terminal {
        wakes
            .recv_timeout(Duration::from_secs(2))
            .expect("worker completion or terminal Store ACK wake");
        work.poll(now());
        drain_events(&mut work);
    }
    assert!(work.take_extraction().is_some());
    work.begin_shutdown();
    while !work.poll_shutdown(now()).unwrap() {
        wakes
            .recv_timeout(Duration::from_secs(2))
            .expect("original native seal/audit wake");
    }
}

type Servers = Arc<Mutex<Vec<std::thread::JoinHandle<usize>>>>;

#[test]
fn retained_result_requires_atomic_ack_and_remains_readable_after_handoff() {
    if child("retained_result_requires_atomic_ack_and_remains_readable_after_handoff") {
        return;
    }
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, store) = coordinator_with_storage(
        directory.path(),
        Arc::new(|| true),
        ContextProfileStorageClass::Durable,
    );
    let servers = Servers::default();
    poll_until(&mut work, RetainedWork::ready);
    store
        .hold
        .store(AgentWorkDisposition::Succeeded as u8, Ordering::Release);
    assert!(work
        .submit(
            request_with_result(
                ContextRunId::generate(),
                vec![response_stream(1), response_stream(2)],
                servers.clone(),
                true
            ),
            now()
        )
        .is_ok());
    poll_until(&mut work, |_| {
        store.pending_artifact.lock().unwrap().is_some()
    });
    assert_eq!(work.phase(), AdmissionPhase::Closing);
    assert!(work.take_extraction().is_none());
    assert!(work.artifact().is_none());
    let (reply, completion) = store.pending_artifact.lock().unwrap().take().unwrap();
    let AgentWorkArtifactReply::Published { record, descriptor } = reply.unwrap() else {
        panic!("atomic publication");
    };
    completion(Ok(AgentWorkArtifactReply::Published { record, descriptor }));
    poll_until(&mut work, |work| work.phase() == AdmissionPhase::Terminal);
    assert_eq!(work.artifact(), Some(descriptor));
    assert!(work.take_extraction().is_some());
    assert!(work.take_extraction().is_none());
    assert!(work.read_artifact(record));
    assert!(!work.read_artifact(record), "one archived read at a time");
    poll_until(&mut work, |work| work.artifact_read().is_some());
    let archived = work.take_archived_extraction().unwrap();
    assert_eq!(archived.descriptor(), descriptor);
    assert_eq!(archived.trust(), SemanticExtractionTrust::ModelMapped);
    assert_eq!(archived.fields()[0].name(), "label");
    assert_eq!(work.record(), Some(record));
    store.refuse_artifact_read.store(true, Ordering::Release);
    assert!(work.read_artifact(record));
    poll_until(&mut work, |work| work.artifact_read().is_some());
    assert_eq!(
        work.artifact_read(),
        Some(Err(AgentWorkJournalError::Unavailable))
    );
    assert_eq!(work.phase(), AdmissionPhase::Terminal);
    assert_eq!(
        work.record(),
        Some(record),
        "a failed archive read cannot rewrite a completed run"
    );
    assert_eq!(
        native.reads.load(Ordering::Acquire),
        1,
        "archive read never dispatches a browser read"
    );
    for server in servers.lock().unwrap().drain(..) {
        assert_eq!(server.join().unwrap(), 2);
    }
    native.join();
    assert!(work.shutdown_until(
        &Clock(AtomicU64::new(2)),
        Instant::now() + Duration::from_secs(2)
    ));
}

#[test]
fn unarchivable_result_classifies_its_row_and_the_page_still_closes() {
    if child("unarchivable_result_classifies_its_row_and_the_page_still_closes") {
        return;
    }
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, store) = coordinator_with_storage(
        directory.path(),
        Arc::new(|| true),
        ContextProfileStorageClass::Durable,
    );
    let servers = Servers::default();
    poll_until(&mut work, RetainedWork::ready);
    REFUSE_PUBLICATION.store(true, Ordering::Release);
    assert!(work
        .submit(
            request_with_result(
                ContextRunId::generate(),
                vec![response_stream(1), response_stream(2)],
                servers.clone(),
                true
            ),
            now()
        )
        .is_ok());
    poll_until(&mut work, |work| {
        work.record()
            .is_some_and(|record| record.disposition() == AgentWorkDisposition::FailedClosed)
    });
    assert!(!REFUSE_PUBLICATION.load(Ordering::Acquire));
    assert_eq!(work.phase(), AdmissionPhase::Uncertain);
    assert_eq!(
        work.failures(),
        (
            Some(AgentWorkFailure::ArtifactPublication(
                AgentWorkJournalError::Uncertain
            )),
            None
        )
    );
    assert!(work.artifact().is_none());
    assert!(work.take_extraction().is_none());
    assert!(store.pending_artifact.lock().unwrap().is_none());
    // A later page of this process claims beside the classified row and runs.
    let (mut later, _later_native) = coordinator_beside(&store);
    run_fresh_read(&mut later, &servers);
    assert!(later.shutdown_until(
        &Clock(AtomicU64::new(2)),
        Instant::now() + Duration::from_secs(2)
    ));
    native.join();
    assert!(work.shutdown_until(
        &Clock(AtomicU64::new(2)),
        Instant::now() + Duration::from_secs(2)
    ));
    assert_eq!(native.global_audits.load(Ordering::Acquire), 1);
    for server in servers.lock().unwrap().drain(..) {
        assert_eq!(server.join().unwrap(), 2);
    }
}

fn request(run: ContextRunId, responses: Vec<String>, servers: Servers) -> ActorRequest {
    request_with_result(run, responses, servers, false)
}

fn request_with_result(
    run: ContextRunId,
    responses: Vec<String>,
    servers: Servers,
    persist: bool,
) -> ActorRequest {
    ActorRequest {
        run,
        deadline: AgentPolicyInstant::from_millis(600_002),
        prepare: Box::new(move |browser, audit, waiting| {
            if waiting.is_some() {
                return Err(AgentWorkFailure::Contract);
            }
            let input = input(browser.binding(), Arc::new(Clock(AtomicU64::new(2))));
            let input = if persist {
                input.persist_extraction_result().unwrap()
            } else {
                input
            };
            let (transport, server) = fixture_provider_responses(responses);
            servers.lock().unwrap().push(server);
            StagedActor::for_probe(
                input,
                browser,
                transport,
                AgentProviderCredential::try_new(
                    AgentProviderKind::OpenAiResponses,
                    "fixture-not-a-secret".into(),
                )
                .unwrap(),
                audit,
                Box::new(task()),
            )
        }),
    }
}
fn poll_until(work: &mut RetainedWork, mut predicate: impl FnMut(&RetainedWork) -> bool) {
    wait_until(|| {
        work.poll(now());
        predicate(work)
    });
}
fn drain_events(work: &mut RetainedWork) {
    while work.take_event().is_some() {}
}

fn start_held_read_recovery(work: &mut RetainedWork, native: &Arc<Native>, servers: &Servers) {
    native.hold_read.store(true, Ordering::Release);
    assert!(work
        .submit(
            request(ContextRunId::generate(), Vec::new(), servers.clone()),
            now(),
        )
        .is_ok());
    poll_until(work, |_| native.read.lock().unwrap().is_some());
    native
        .reporters
        .lock()
        .unwrap()
        .values()
        .next()
        .expect("retained resource health reporter")
        .invalidate();
}

#[test]
fn recovery_classification_acknowledgement_gates_global_native_shutdown() {
    if child("recovery_classification_acknowledgement_gates_global_native_shutdown") {
        return;
    }
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, store) = coordinator(directory.path());
    let servers = Servers::default();
    poll_until(&mut work, RetainedWork::ready);
    store.hold.store(
        AgentWorkDisposition::RecoveryRequired as u8,
        Ordering::Release,
    );
    start_held_read_recovery(&mut work, &native, &servers);
    poll_until(&mut work, |_| store.pending.lock().unwrap().is_some());
    let running = work.record().unwrap();
    assert_eq!(running.disposition(), AgentWorkDisposition::Running);
    assert_eq!(running.debt(), AgentWorkDebt::UNKNOWN);
    assert!(work.take_extraction().is_none());

    let (read, callback) = native.read.lock().unwrap().take().unwrap();
    Native::read_result(read, callback);
    native.join();
    work.begin_shutdown();
    assert!(!work.poll_shutdown(now()).unwrap());
    assert!(work.resource_destroyed());
    assert_eq!(
        native.global_audits.load(Ordering::Acquire),
        0,
        "global native proof cannot precede the original recovery CAS ACK"
    );

    store.release(0);
    let deadline = Instant::now() + Duration::from_secs(2);
    assert!(!work.shutdown_until(&Clock(AtomicU64::new(2)), deadline));
    assert!(
        Instant::now() < deadline,
        "classified recovery has no clean-state notification to wait for"
    );
    assert_eq!(work.phase(), AdmissionPhase::Uncertain);
    assert_eq!(
        work.record().unwrap(),
        AgentWorkJournalMutation::transition(running, AgentWorkDisposition::RecoveryRequired,)
            .unwrap()
            .next()
    );
    assert_eq!(work.record().unwrap().debt(), AgentWorkDebt::UNKNOWN);
    assert!(work.take_extraction().is_none());
    assert_eq!(native.global_audits.load(Ordering::Acquire), 1);
    assert!(native.global_sealed.load(Ordering::Acquire));
    for server in servers.lock().unwrap().drain(..) {
        assert_eq!(server.join().unwrap(), 0);
    }
}

#[test]
fn recovery_shutdown_waits_for_original_late_read_then_returns_unclean_promptly() {
    if child("recovery_shutdown_waits_for_original_late_read_then_returns_unclean_promptly") {
        return;
    }
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, _) = coordinator(directory.path());
    let servers = Servers::default();
    poll_until(&mut work, RetainedWork::ready);
    start_held_read_recovery(&mut work, &native, &servers);
    poll_until(&mut work, |work| {
        work.record()
            .is_some_and(|record| record.disposition() == AgentWorkDisposition::RecoveryRequired)
    });
    assert_eq!(work.record().unwrap().debt(), AgentWorkDebt::UNKNOWN);

    work.begin_shutdown();
    assert!(!work.poll_shutdown(now()).unwrap());
    assert!(
        !work.resource_destroyed(),
        "an outstanding original read callback must remain physically owned"
    );
    assert_eq!(native.destructions.load(Ordering::Acquire), 1);
    assert_eq!(native.global_audits.load(Ordering::Acquire), 0);

    let (read, callback) = native.read.lock().unwrap().take().unwrap();
    let deliver = std::thread::spawn(move || {
        std::thread::sleep(Duration::from_millis(40));
        Native::read_result(read, callback);
    });
    let deadline = Instant::now() + Duration::from_secs(2);
    assert!(!work.shutdown_until(&Clock(AtomicU64::new(2)), deadline));
    deliver.join().unwrap();
    native.join();
    assert!(
        Instant::now() < deadline,
        "the returned callback permits cleanup but cannot turn Recovery clean"
    );
    assert!(work.resource_destroyed());
    assert_eq!(native.destructions.load(Ordering::Acquire), 1);
    assert_eq!(native.global_audits.load(Ordering::Acquire), 1);
    assert_eq!(
        work.record().unwrap().disposition(),
        AgentWorkDisposition::RecoveryRequired
    );
    assert_eq!(work.record().unwrap().debt(), AgentWorkDebt::UNKNOWN);
    assert!(work.take_extraction().is_none());
    for server in servers.lock().unwrap().drain(..) {
        assert_eq!(server.join().unwrap(), 0);
    }
}

#[test]
fn drained_failed_mapping_projects_original_typed_failure_through_terminal_ack() {
    if child("drained_failed_mapping_projects_original_typed_failure_through_terminal_ack") {
        return;
    }
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    failed_mapping_projection(
        "sk-fixture-not-a-secret",
        SemanticExtractionError::SecretValue,
    );
}

fn failed_mapping_projection(value: &str, error: SemanticExtractionError) {
    use zephium_agent_controller::AgentBrowserProviderError;
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, store) = coordinator(directory.path());
    let servers = Servers::default();
    poll_until(&mut work, RetainedWork::ready);
    store
        .hold
        .store(AgentWorkDisposition::Failed as u8, Ordering::Release);
    let mapping = response_stream(2).replace("Fixture result", value);
    assert!(work
        .submit(
            request(
                ContextRunId::generate(),
                vec![response_stream(1), mapping],
                servers.clone()
            ),
            now()
        )
        .is_ok());
    poll_until(&mut work, |work| {
        work.phase() == AdmissionPhase::Closing && store.pending.lock().unwrap().is_some()
    });
    let expected = AgentWorkFailure::Browser(AgentBrowserProviderError::Extraction(
        AgentProviderExtractionOutputError::Extraction(error),
    ));
    assert_eq!(work.phase(), AdmissionPhase::Closing);
    assert_eq!(work.failures(), (Some(expected), None));
    assert!(work.take_extraction().is_none());
    assert!(
        work.usage().is_none(),
        "unacknowledged terminal has no usage"
    );
    store.release(0);
    poll_until(&mut work, |work| work.phase() == AdmissionPhase::Terminal);
    assert_eq!(
        work.record().unwrap().disposition(),
        AgentWorkDisposition::Failed
    );
    assert_eq!(work.record().unwrap().debt(), AgentWorkDebt::NONE);
    let usage = work
        .usage()
        .expect("original terminal ACK exposes closed ledger");
    assert_eq!(usage.model_tokens, 40);
    assert!(usage.cost_micro_usd > 0 && usage.cost_micro_usd < 250_000);
    assert!(usage.operations > 0 && usage.operations < 64);
    assert_eq!(
        usage.accounting,
        zephium_core::work::runtime::WorkUsageAccounting::ConservativeReservation,
        "provider tokens are exact but catalog-priced cost is a ceiling"
    );
    assert_eq!(work.failures(), (Some(expected), None));
    assert!(work.take_extraction().is_none());
    assert!(!native.global_sealed.load(Ordering::Acquire));
    assert_eq!(native.destructions.load(Ordering::Acquire), 0);
    for server in servers.lock().unwrap().drain(..) {
        assert_eq!(server.join().unwrap(), 2);
    }
    assert!(work.shutdown_until(
        &Clock(AtomicU64::new(2)),
        Instant::now() + Duration::from_secs(2)
    ));
}

#[test]
fn original_acknowledgements_gate_retained_workers_results_and_successors() {
    if child("original_acknowledgements_gate_retained_workers_results_and_successors") {
        return;
    }
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, store) = coordinator(directory.path());
    let servers = Servers::default();
    let first = ContextRunId::generate();
    let mut second = Some(request(ContextRunId::generate(), vec![], servers.clone()));
    assert_eq!(work.phase(), AdmissionPhase::Loading);
    assert!(!work.ready());
    poll_until(&mut work, |work| work.ready());
    let wake_before_acquire = store.wakes.load(Ordering::Acquire);
    store
        .hold
        .store(AgentWorkDisposition::Admitted as u8, Ordering::Release);
    assert!(work
        .submit(
            request(
                first,
                vec![response_stream(1), response_stream(2)],
                servers.clone()
            ),
            now()
        )
        .is_ok());
    poll_until(&mut work, |_| store.pending.lock().unwrap().is_some());
    assert_eq!(work.phase(), AdmissionPhase::Admitting);
    assert_eq!(native.acquisitions.load(Ordering::Acquire), 1);
    assert!(
        store.wakes.load(Ordering::Acquire) > wake_before_acquire,
        "original resource lane was rearmed before acquisition"
    );
    assert_eq!(native.reads.load(Ordering::Acquire), 0);
    assert!(work.take_extraction().is_none());
    second = Some(work.submit(second.take().unwrap(), now()).err().unwrap());
    assert_eq!(native.acquisitions.load(Ordering::Acquire), 1);

    let wake_before_ack = store.wakes.load(Ordering::Acquire);
    store.release(AgentWorkDisposition::Running as u8);
    assert!(
        store.wakes.load(Ordering::Acquire) > wake_before_ack,
        "original Store ACK uses the same rearmed application wake"
    );
    poll_until(&mut work, |_| store.pending.lock().unwrap().is_some());
    assert_eq!(work.phase(), AdmissionPhase::Starting);
    assert_eq!(
        native.reads.load(Ordering::Acquire),
        0,
        "durable Running is not its ACK"
    );
    second = Some(work.submit(second.take().unwrap(), now()).err().unwrap());
    store.release(AgentWorkDisposition::Succeeded as u8);
    poll_until(&mut work, |_| store.pending.lock().unwrap().is_some());
    native.join();
    assert_eq!(work.phase(), AdmissionPhase::Closing);
    assert_eq!(native.reads.load(Ordering::Acquire), 1);
    assert_eq!(
        work.record().unwrap().disposition(),
        AgentWorkDisposition::Running
    );
    assert!(
        work.take_extraction().is_none(),
        "result cannot precede terminal ACK"
    );
    second = Some(work.submit(second.take().unwrap(), now()).err().unwrap());
    assert_eq!(
        native.acquisitions.load(Ordering::Acquire),
        1,
        "native reuse is not B admission"
    );
    let (reply, _) = store
        .pending
        .lock()
        .unwrap()
        .as_ref()
        .map(|(reply, _)| {
            let Ok(AgentWorkJournalReply::Record(Some(record))) = reply else {
                panic!("original committed terminal");
            };
            (*record, ())
        })
        .unwrap();
    assert_eq!(reply.disposition(), AgentWorkDisposition::Succeeded);
    store.release(0);
    poll_until(&mut work, |work| work.phase() == AdmissionPhase::Terminal);
    second = Some(work.submit(second.take().unwrap(), now()).err().unwrap());
    drain_events(&mut work);
    assert!(!work.ready(), "unread result stays owned");
    assert_eq!(work.take_extraction().unwrap().stats().source_edges(), 1);
    assert!(work.take_extraction().is_none());
    assert!(work.ready());
    assert!(
        work.submit(request(first, vec![], servers.clone()), now())
            .is_err(),
        "old actor ID is not resumed"
    );

    native.hold_read.store(true, Ordering::Release);
    assert!(work.submit(second.take().unwrap(), now()).is_ok());
    poll_until(&mut work, |_| native.read.lock().unwrap().is_some());
    assert_eq!(
        native.reads.load(Ordering::Acquire),
        2,
        "fresh successor read, no A snapshot replay"
    );
    work.cancel();
    let (read, callback) = native.read.lock().unwrap().take().unwrap();
    Native::read_result(read, callback);
    poll_until(&mut work, |work| work.phase() == AdmissionPhase::Terminal);
    native.join();
    assert_eq!(
        work.record().unwrap().disposition(),
        AgentWorkDisposition::Cancelled
    );
    assert_eq!(work.record().unwrap().debt(), AgentWorkDebt::NONE);
    assert!(work.take_extraction().is_none());
    drain_events(&mut work);
    assert!(work.ready());
    assert_eq!(native.acquisitions.load(Ordering::Acquire), 2);
    assert_eq!(native.destructions.load(Ordering::Acquire), 0);
    assert_eq!(
        native.global_audits.load(Ordering::Acquire),
        0,
        "the retained page cannot enter global shutdown between actors"
    );
    work.begin_shutdown();
    wait_until(|| work.poll_shutdown(now()).unwrap());
    assert!(!work.ready());
    assert_eq!(native.destructions.load(Ordering::Acquire), 1);
    assert_eq!(native.global_audits.load(Ordering::Acquire), 1);
    let calls: Vec<_> = servers
        .lock()
        .unwrap()
        .drain(..)
        .map(|server| server.join().unwrap())
        .collect();
    assert_eq!(calls, [2, 0]);
}

#[test]
fn mismatched_original_acknowledgement_cannot_start_worker_and_cleanup_stays_owned() {
    if child("mismatched_original_acknowledgement_cannot_start_worker_and_cleanup_stays_owned") {
        return;
    }
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, store) = coordinator(directory.path());
    let servers = Servers::default();
    poll_until(&mut work, |work| work.ready());
    store
        .hold
        .store(AgentWorkDisposition::Running as u8, Ordering::Release);
    assert!(work
        .submit(
            request(ContextRunId::generate(), vec![], servers.clone()),
            now()
        )
        .is_ok());
    poll_until(&mut work, |_| store.pending.lock().unwrap().is_some());
    let (reply, completion) = store.pending.lock().unwrap().take().unwrap();
    let Ok(AgentWorkJournalReply::Record(Some(record))) = reply else {
        panic!("Running ACK");
    };
    let mut wrong = *record.as_bytes();
    wrong[64] ^= 1;
    completion(Ok(AgentWorkJournalReply::Record(AgentWorkRecord::decode(
        wrong,
    ))));
    work.poll(now());
    assert_eq!(work.phase(), AdmissionPhase::Uncertain);
    assert!(!work.ready());
    assert_eq!(native.reads.load(Ordering::Acquire), 0);
    assert!(work
        .submit(
            request(ContextRunId::generate(), vec![], servers.clone()),
            now()
        )
        .is_err());
    assert_eq!(native.acquisitions.load(Ordering::Acquire), 1);
    work.begin_shutdown();
    wait_until(|| {
        let settled = work.poll_shutdown(now()).unwrap();
        assert!(!settled);
        work.resource_destroyed()
    });
    assert_eq!(native.destructions.load(Ordering::Acquire), 1);
    assert!(!work.ready(), "cleanup does not clear durable uncertainty");
    // The exact Running CAS is resent on its own once its backoff is due;
    // it may already be held by the fixture.
    store.hold.store(0, Ordering::Release);
    if store.pending.lock().unwrap().is_some() {
        store.release(0);
    }
    poll_until(&mut work, |work| {
        work.record()
            .is_some_and(|record| record.disposition() == AgentWorkDisposition::FailedClosed)
    });
    assert!(
        !work.poll_shutdown(now()).unwrap(),
        "pre-start recovery owner was not a scoped drain"
    );
    assert!(!work.reconcile(), "original exact CAS has now settled");
    for server in servers.lock().unwrap().drain(..) {
        assert_eq!(server.join().unwrap(), 0);
    }
}

/// Runs a fresh read to its acknowledged success.
fn run_fresh_read(work: &mut RetainedWork, servers: &Servers) {
    poll_until(work, RetainedWork::ready);
    assert!(work
        .submit(
            request(
                ContextRunId::generate(),
                vec![response_stream(1), response_stream(2)],
                servers.clone()
            ),
            now()
        )
        .is_ok());
    poll_until(work, |work| {
        matches!(
            work.phase(),
            AdmissionPhase::Terminal | AdmissionPhase::Uncertain
        )
    });
    assert_eq!(work.phase(), AdmissionPhase::Terminal);
    assert_eq!(
        work.record().unwrap().disposition(),
        AgentWorkDisposition::Succeeded
    );
    drain_events(work);
    assert!(work.take_extraction().is_some());
}

#[test]
fn fail_closed_admission_never_refuses_later_claims_or_a_reopened_store() {
    const PHASE: &str = "ZEPHIUM_FAIL_CLOSED_PHASE";
    const DIRECTORY: &str = "ZEPHIUM_FAIL_CLOSED_DIRECTORY";
    let Some(phase) = std::env::var_os(PHASE) else {
        // The Store fences one claimant per process: reopening it takes a
        // second process, as a relaunch does.
        let directory = tempfile::tempdir().unwrap();
        for phase in ["create", "reopen"] {
            let result = std::process::Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "work_resources::controller::tests::application_tests::fail_closed_admission_never_refuses_later_claims_or_a_reopened_store",
                    "--nocapture",
                ])
                .env(PHASE, phase)
                .env(DIRECTORY, directory.path())
                .output()
                .unwrap();
            assert!(result.status.success(), "{phase}: {result:?}");
        }
        return;
    };
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let directory = std::path::PathBuf::from(std::env::var_os(DIRECTORY).unwrap());
    let servers = Servers::default();
    if phase == "reopen" {
        let (mut work, _native, _store) = coordinator(&directory);
        run_fresh_read(&mut work, &servers);
        let history: Vec<_> = work
            .records()
            .iter()
            .map(|record| (record.disposition(), record.debt()))
            .collect();
        assert!(history.contains(&(AgentWorkDisposition::FailedClosed, AgentWorkDebt::UNKNOWN)));
        assert_eq!(history.len(), 3);
        assert!(work.shutdown_until(
            &Clock(AtomicU64::new(2)),
            Instant::now() + Duration::from_secs(2)
        ));
        for server in servers.lock().unwrap().drain(..) {
            assert_eq!(server.join().unwrap(), 2);
        }
        return;
    }
    let (mut work, native, store) = coordinator(&directory);
    poll_until(&mut work, RetainedWork::ready);
    store
        .hold
        .store(AgentWorkDisposition::Running as u8, Ordering::Release);
    assert!(work
        .submit(
            request(ContextRunId::generate(), vec![], servers.clone()),
            now()
        )
        .is_ok());
    poll_until(&mut work, |_| store.pending.lock().unwrap().is_some());
    // Stopped between the Admitted and Running acknowledgements.
    work.cancel();
    store.release(0);
    poll_until(&mut work, |work| {
        work.record()
            .is_some_and(|record| record.disposition() == AgentWorkDisposition::FailedClosed)
    });
    let closed = work.record().unwrap();
    assert_eq!(closed.debt(), AgentWorkDebt::UNKNOWN);
    assert_eq!(native.reads.load(Ordering::Acquire), 0);
    // A later page of this process claims beside the row and runs.
    let (mut later, _later_native) = coordinator_beside(&store);
    run_fresh_read(&mut later, &servers);
    assert!(later.records().contains(&closed));
    assert!(later.shutdown_until(
        &Clock(AtomicU64::new(2)),
        Instant::now() + Duration::from_secs(2)
    ));
    assert!(
        !work.shutdown_until(
            &Clock(AtomicU64::new(2)),
            Instant::now() + Duration::from_secs(2)
        ),
        "a never-started actor still ends unclean"
    );
    for server in servers.lock().unwrap().drain(..) {
        server.join().unwrap();
    }
}

#[test]
fn refused_terminal_write_is_resent_until_acknowledged_and_the_page_closes() {
    if child("refused_terminal_write_is_resent_until_acknowledged_and_the_page_closes") {
        return;
    }
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, store) = coordinator(directory.path());
    let servers = Servers::default();
    poll_until(&mut work, RetainedWork::ready);
    // The Store answers the terminal write Uncertain and never again: the
    // original callback is spent, so only a resend can settle the row.
    store
        .refuse_once
        .store(AgentWorkDisposition::Succeeded as u8, Ordering::Release);
    assert!(work
        .submit(
            request(
                ContextRunId::generate(),
                vec![response_stream(1), response_stream(2)],
                servers.clone()
            ),
            now()
        )
        .is_ok());
    poll_until(&mut work, |work| {
        work.failures().1 == Some(AgentWorkJournalError::Uncertain)
    });
    assert!(work.next_deadline().is_some(), "the resend is owed a wake");
    poll_until(&mut work, |work| work.phase() == AdmissionPhase::Terminal);
    assert_eq!(
        work.record().unwrap().disposition(),
        AgentWorkDisposition::Succeeded
    );
    assert_eq!(work.failures(), (Some(AgentWorkFailure::Contract), None));
    assert!(!work.ready(), "a resend keeps the sticky execution stop");
    assert!(work.take_extraction().is_none());
    native.join();
    assert!(work.shutdown_until(
        &Clock(AtomicU64::new(2)),
        Instant::now() + Duration::from_secs(2)
    ));
    assert_eq!(native.global_audits.load(Ordering::Acquire), 1);
    for server in servers.lock().unwrap().drain(..) {
        assert_eq!(server.join().unwrap(), 2);
    }
}

#[test]
fn timed_out_terminal_acknowledgement_never_reopens_retained_execution() {
    if child("timed_out_terminal_acknowledgement_never_reopens_retained_execution") {
        return;
    }
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, store) = coordinator(directory.path());
    let servers = Servers::default();
    poll_until(&mut work, |work| work.ready());
    store
        .hold
        .store(AgentWorkDisposition::Succeeded as u8, Ordering::Release);
    assert!(work
        .submit(
            request(
                ContextRunId::generate(),
                vec![response_stream(1), response_stream(2)],
                servers.clone()
            ),
            now()
        )
        .is_ok());
    poll_until(&mut work, |_| store.pending.lock().unwrap().is_some());
    native.join();
    poll_until(&mut work, |work| work.phase() == AdmissionPhase::Uncertain);
    assert!(!work.ready());
    assert!(
        work.usage().is_none(),
        "missing terminal ACK retains original debt"
    );
    assert!(work.take_extraction().is_none());
    assert!(work
        .submit(
            request(ContextRunId::generate(), vec![], servers.clone()),
            now()
        )
        .is_err());
    assert_eq!(native.acquisitions.load(Ordering::Acquire), 1);
    work.begin_shutdown();
    wait_until(|| {
        let settled = work.poll_shutdown(now()).unwrap();
        assert!(!settled);
        work.resource_destroyed()
    });
    assert_eq!(native.destructions.load(Ordering::Acquire), 1);
    // Production resends the exact terminal CAS on its own once its backoff
    // is due; nothing asks for it.
    wait_until(|| {
        assert!(!work.poll_shutdown(now()).unwrap());
        !store.resent.lock().unwrap().is_empty()
    });
    assert_eq!(
        native.global_audits.load(Ordering::Acquire),
        0,
        "native global seal cannot precede the unresolved terminal ACK, even resent"
    );
    store.hold.store(0, Ordering::Release);
    let (reply, completion) = store.resent.lock().unwrap().remove(0);
    completion(reply);
    poll_until(&mut work, |work| work.phase() == AdmissionPhase::Terminal);
    assert!(
        !work.ready(),
        "reconciliation never clears the sticky execution stop"
    );
    assert!(work.take_extraction().is_none());
    wait_until(|| work.poll_shutdown(now()).unwrap());
    let closed_usage = work
        .usage()
        .expect("exact reconciliation retains joined usage");
    store.release(0); // The old callback cannot select/rewrite the reconciled lane.
    work.poll(now());
    assert_eq!(
        work.usage(),
        Some(closed_usage),
        "stale callback cannot rewrite usage"
    );
    assert!(work.poll_shutdown(now()).unwrap());
    for server in servers.lock().unwrap().drain(..) {
        assert_eq!(server.join().unwrap(), 2);
    }
}

#[test]
fn shutdown_deadline_caps_native_retry_without_consuming_the_original_coordinator() {
    if child("shutdown_deadline_caps_native_retry_without_consuming_the_original_coordinator") {
        return;
    }
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, _) = coordinator(directory.path());
    poll_until(&mut work, |work| work.ready());
    native.global_queued_debt.store(1, Ordering::Release);
    let clock = Clock(AtomicU64::new(2));
    let deadline = Instant::now() + Duration::from_millis(40);
    assert!(!work.shutdown_until(&clock, deadline));
    assert!(Instant::now() >= deadline);
    assert!(Instant::now() < deadline + Duration::from_secs(1));
    assert!(work.resource_destroyed());
    assert!(!work.ready());
    assert_eq!(native.global_audits.load(Ordering::Acquire), 1);
    assert!(work.next_deadline().unwrap() > deadline);
    native.global_queued_debt.store(0, Ordering::Release);
    assert!(work.shutdown_until(&clock, Instant::now() + Duration::from_secs(2)));
    assert_eq!(native.global_audits.load(Ordering::Acquire), 2);
}

#[test]
fn shutdown_timeout_retains_the_exact_pending_native_terminal() {
    if child("shutdown_timeout_retains_the_exact_pending_native_terminal") {
        return;
    }
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, _) = coordinator(directory.path());
    poll_until(&mut work, |work| work.ready());
    native.hold_global_audit.store(true, Ordering::Release);
    let clock = Clock(AtomicU64::new(2));
    assert!(!work.shutdown_until(&clock, Instant::now() + Duration::from_millis(30)));
    assert!(native.pending_global_audit.lock().unwrap().is_some());
    assert!(work.resource_destroyed());
    assert_eq!(native.global_audits.load(Ordering::Acquire), 1);
    native.release_global_audit();
    assert!(work.shutdown_until(&clock, Instant::now() + Duration::from_secs(1)));
    assert_eq!(native.global_audits.load(Ordering::Acquire), 1);
}

#[test]
fn shutdown_timeout_retains_the_original_terminal_store_acknowledgement() {
    if child("shutdown_timeout_retains_the_original_terminal_store_acknowledgement") {
        return;
    }
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, store) = coordinator(directory.path());
    let servers = Servers::default();
    poll_until(&mut work, |work| work.ready());
    store
        .hold
        .store(AgentWorkDisposition::Succeeded as u8, Ordering::Release);
    assert!(work
        .submit(
            request(
                ContextRunId::generate(),
                vec![response_stream(1), response_stream(2)],
                servers.clone()
            ),
            now()
        )
        .is_ok());
    poll_until(&mut work, |_| store.pending.lock().unwrap().is_some());
    native.join();
    let clock = Clock(AtomicU64::new(2));
    assert!(!work.shutdown_until(&clock, Instant::now() + Duration::from_millis(30)));
    assert!(store.pending.lock().unwrap().is_some());
    assert!(work.resource_destroyed());
    assert_eq!(native.global_audits.load(Ordering::Acquire), 0);
    assert_eq!(
        work.record().unwrap().disposition(),
        AgentWorkDisposition::Running
    );
    assert!(!work.ready());
    assert!(work.take_extraction().is_none());
    native.hold_global_audit.store(true, Ordering::Release);
    let deliver = std::thread::spawn(move || {
        std::thread::sleep(Duration::from_millis(20));
        store.release(0);
    });
    let deadline = Instant::now() + Duration::from_millis(120);
    assert!(!work.shutdown_until(&clock, deadline));
    deliver.join().unwrap();
    assert!(Instant::now() >= deadline);
    assert!(Instant::now() < deadline + Duration::from_secs(1));
    assert_eq!(native.global_audits.load(Ordering::Acquire), 1);
    assert_eq!(
        work.record().unwrap().disposition(),
        AgentWorkDisposition::Succeeded
    );
    native.release_global_audit();
    assert!(work.shutdown_until(&clock, Instant::now() + Duration::from_secs(1)));
    assert_eq!(
        work.record().unwrap().disposition(),
        AgentWorkDisposition::Succeeded
    );
    assert!(work.take_extraction().is_some());
    assert!(!work.ready());
    for server in servers.lock().unwrap().drain(..) {
        assert_eq!(server.join().unwrap(), 2);
    }
}

#[test]
fn expired_shutdown_deadline_stops_admission_without_dispatching_cleanup() {
    if child("expired_shutdown_deadline_stops_admission_without_dispatching_cleanup") {
        return;
    }
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, _) = coordinator(directory.path());
    poll_until(&mut work, |work| work.ready());
    let clock = Clock(AtomicU64::new(2));
    assert!(!work.shutdown_until(&clock, Instant::now()));
    assert!(!work.ready());
    assert_eq!(native.destructions.load(Ordering::Acquire), 0);
    assert_eq!(native.global_audits.load(Ordering::Acquire), 0);
    assert!(work.shutdown_until(&clock, Instant::now() + Duration::from_secs(1)));
}

#[test]
fn shutdown_deadline_is_rechecked_after_the_policy_clock_returns() {
    if child("shutdown_deadline_is_rechecked_after_the_policy_clock_returns") {
        return;
    }
    struct DelayedClock;
    impl TerraControllerClock for DelayedClock {
        fn now(&self) -> Result<AgentPolicyInstant, TerraControllerClockError> {
            std::thread::sleep(Duration::from_millis(30));
            Ok(now())
        }
    }
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, _) = coordinator(directory.path());
    poll_until(&mut work, |work| work.ready());
    assert!(!work.shutdown_until(&DelayedClock, Instant::now() + Duration::from_millis(10)));
    assert_eq!(native.destructions.load(Ordering::Acquire), 0);
    assert_eq!(native.global_audits.load(Ordering::Acquire), 0);
    assert!(work.shutdown_until(
        &Clock(AtomicU64::new(2)),
        Instant::now() + Duration::from_secs(1)
    ));
}

#[test]
fn local_resource_destruction_waits_for_original_global_native_zero_audit() {
    if child("local_resource_destruction_waits_for_original_global_native_zero_audit") {
        return;
    }
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, _) = coordinator(directory.path());
    poll_until(&mut work, |work| work.ready());
    native.hold_global_audit.store(true, Ordering::Release);
    work.begin_shutdown();
    assert!(!work.poll_shutdown(now()).unwrap());
    assert!(work.resource_destroyed());
    assert_eq!(native.destructions.load(Ordering::Acquire), 1);
    assert_eq!(native.global_audits.load(Ordering::Acquire), 1);
    assert!(
        !work.poll_shutdown(now()).unwrap(),
        "scheduled/held native audit is not proof"
    );
    native.release_global_audit();
    assert!(work.poll_shutdown(now()).unwrap());
    assert!(work.poll_shutdown(now()).unwrap());
    assert_eq!(
        native.global_audits.load(Ordering::Acquire),
        1,
        "seal/proof are consumed once"
    );
}

#[test]
fn duplicate_native_zero_terminal_is_retained_before_shutdown_can_complete() {
    if child("duplicate_native_zero_terminal_is_retained_before_shutdown_can_complete") {
        return;
    }
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, _) = coordinator(directory.path());
    poll_until(&mut work, |work| work.ready());
    native.hold_global_audit.store(true, Ordering::Release);
    work.begin_shutdown();
    assert!(!work.poll_shutdown(now()).unwrap());
    native.hold_global_audit.store(false, Ordering::Release);
    native.release_global_audit();
    native.global_audit(ContextResourceAuditId::new(1).unwrap(), true);
    assert!(!work.poll_shutdown(now()).unwrap());
    assert_eq!(work.phase(), AdmissionPhase::Uncertain);
    assert!(!work.poll_shutdown(now()).unwrap());
}

#[test]
fn synchronous_native_refusals_arm_retry_without_an_extra_poll_or_callback() {
    if child("synchronous_native_refusals_arm_retry_without_an_extra_poll_or_callback") {
        return;
    }
    let directory = tempfile::tempdir().unwrap();
    let (wake, wakes) = mpsc::channel();
    let (mut work, native, _) =
        coordinator_with_wake(directory.path(), Arc::new(move || wake.send(()).is_ok()));
    poll_until(&mut work, |work| work.ready());
    native
        .synchronous_global_seal
        .store(true, Ordering::Release);
    native.reject_global_audit.store(true, Ordering::Release);
    work.begin_shutdown();
    assert!(!work.poll_shutdown(now()).unwrap());
    while wakes.try_recv().is_ok() {}
    let first = work
        .next_deadline()
        .expect("synchronous seal must arm retry immediately");
    std::thread::sleep(first.saturating_duration_since(Instant::now()));
    assert!(!work.poll_shutdown(now()).unwrap());
    assert!(
        wakes.try_recv().is_err(),
        "unsupported audit has no callback wake"
    );
    let second = work
        .next_deadline()
        .expect("synchronous audit refusal must rearm retry immediately");
    assert!(second > first);
    native.reject_global_audit.store(false, Ordering::Release);
    std::thread::sleep(second.saturating_duration_since(Instant::now()));
    assert!(!work.poll_shutdown(now()).unwrap());
    wakes
        .recv_timeout(Duration::from_secs(2))
        .expect("original audit terminal wakes owner");
    assert!(work.poll_shutdown(now()).unwrap());
    assert_eq!(native.global_audits.load(Ordering::Acquire), 1);
}

#[test]
fn synchronous_native_exhaustion_returns_without_an_unavailable_final_wake() {
    if child("synchronous_native_exhaustion_returns_without_an_unavailable_final_wake") {
        return;
    }
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, _) = coordinator(directory.path());
    poll_until(&mut work, |work| work.ready());
    native
        .synchronous_global_seal
        .store(true, Ordering::Release);
    native.reject_global_audit.store(true, Ordering::Release);
    work.begin_shutdown();
    for attempt in 1..=8 {
        let result = work.poll_shutdown(now());
        if attempt == 8 {
            assert!(
                result.is_err(),
                "last synchronous refusal must fail in its dispatch poll"
            );
        } else {
            assert!(!result.unwrap());
            let retry = work
                .next_deadline()
                .expect("no callbacks exist; retry must be armed");
            std::thread::sleep(retry.saturating_duration_since(Instant::now()));
        }
    }
    assert!(work.next_deadline().is_none());
    assert_eq!(native.global_audits.load(Ordering::Acquire), 0);
    assert!(work.poll_shutdown(now()).is_err());
}

#[test]
fn retained_global_shutdown_reuses_nonzero_retry_cadence_and_exact_zero_predicate() {
    if child("retained_global_shutdown_reuses_nonzero_retry_cadence_and_exact_zero_predicate") {
        return;
    }
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, _) = coordinator(directory.path());
    poll_until(&mut work, |work| work.ready());
    native.global_queued_debt.store(1, Ordering::Release);
    work.begin_shutdown();
    assert!(!work.poll_shutdown(now()).unwrap());
    assert!(!work.poll_shutdown(now()).unwrap());
    assert!(work.resource_destroyed());
    assert_eq!(native.global_audits.load(Ordering::Acquire), 1);
    let retry = work
        .next_deadline()
        .expect("existing native retry cadence joins application timer");
    assert!(!work.poll_shutdown(now()).unwrap());
    assert_eq!(
        native.global_audits.load(Ordering::Acquire),
        1,
        "no tight native audit loop"
    );
    native.global_queued_debt.store(0, Ordering::Release);
    std::thread::sleep(retry.saturating_duration_since(Instant::now()));
    assert!(!work.poll_shutdown(now()).unwrap());
    assert!(work.poll_shutdown(now()).unwrap());
    assert_eq!(native.global_audits.load(Ordering::Acquire), 2);
}

fn wrong_native_audit(identity: bool) {
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, _) = coordinator(directory.path());
    poll_until(&mut work, |work| work.ready());
    if identity {
        native
            .wrong_global_audit_identity
            .store(true, Ordering::Release);
    } else {
        native
            .wrong_global_audit_kind
            .store(true, Ordering::Release);
    }
    work.begin_shutdown();
    assert!(!work.poll_shutdown(now()).unwrap());
    assert!(!work.poll_shutdown(now()).unwrap());
    assert!(work.resource_destroyed());
    assert_eq!(work.phase(), AdmissionPhase::Uncertain);
    assert!(!work.poll_shutdown(now()).unwrap());
    assert_eq!(
        native.global_audits.load(Ordering::Acquire),
        1,
        "mismatched original terminal stays retained"
    );
}

#[test]
fn ordinary_native_zero_cannot_replace_the_original_seal_barrier() {
    if child("ordinary_native_zero_cannot_replace_the_original_seal_barrier") {
        return;
    }
    wrong_native_audit(false);
}

#[test]
fn wrong_native_zero_identity_cannot_settle_the_original_seal_barrier() {
    if child("wrong_native_zero_identity_cannot_settle_the_original_seal_barrier") {
        return;
    }
    wrong_native_audit(true);
}

#[test]
fn retained_native_shutdown_never_exceeds_the_existing_eight_audit_ceiling() {
    if child("retained_native_shutdown_never_exceeds_the_existing_eight_audit_ceiling") {
        return;
    }
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, _) = coordinator(directory.path());
    poll_until(&mut work, |work| work.ready());
    native.global_queued_debt.store(1, Ordering::Release);
    work.begin_shutdown();
    loop {
        match work.poll_shutdown(now()) {
            Ok(false) => {}
            Ok(true) => panic!("nonzero native tasks cannot prove shutdown"),
            Err(Refusal::Uncertain) => break,
            Err(error) => panic!("unexpected native refusal: {error:?}"),
        }
        if let Some(deadline) = work.next_deadline() {
            std::thread::sleep(deadline.saturating_duration_since(Instant::now()));
        }
    }
    assert_eq!(
        native.global_audits.load(Ordering::Acquire),
        usize::from(MAX_AGENT_NATIVE_SHUTDOWN_AUDITS)
    );
    assert!(work.poll_shutdown(now()).is_err());
    assert_eq!(native.global_audits.load(Ordering::Acquire), 8);
}

fn stopped_before_start(expired: bool) {
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, store) = coordinator(directory.path());
    let servers = Servers::default();
    poll_until(&mut work, |work| work.ready());
    store.hold.store(
        if expired {
            AgentWorkDisposition::Running
        } else {
            AgentWorkDisposition::Admitted
        } as u8,
        Ordering::Release,
    );
    assert!(work
        .submit(
            request(ContextRunId::generate(), vec![], servers.clone()),
            now()
        )
        .is_ok());
    poll_until(&mut work, |_| store.pending.lock().unwrap().is_some());
    assert_eq!(native.acquisitions.load(Ordering::Acquire), 1);
    if expired {
        work.poll(AgentPolicyInstant::from_millis(600_003));
    } else {
        work.cancel();
    }
    assert_eq!(work.phase(), AdmissionPhase::Uncertain);
    assert_eq!(native.reads.load(Ordering::Acquire), 0);
    assert_eq!(
        native.destructions.load(Ordering::Acquire),
        0,
        "ordinary stop is not whole-resource destruction or proven revocation"
    );
    assert!(work
        .submit(
            request(ContextRunId::generate(), vec![], servers.clone()),
            now()
        )
        .is_err());
    store.release(0);
    poll_until(&mut work, |work| {
        work.record()
            .is_some_and(|record| record.disposition() == AgentWorkDisposition::FailedClosed)
    });
    assert_eq!(
        native.reads.load(Ordering::Acquire),
        0,
        "raced ACK cannot start expired/stopped staged actor"
    );
    assert_ne!(work.record().unwrap().debt(), AgentWorkDebt::NONE);
    work.begin_shutdown();
    wait_until(|| {
        assert!(!work.poll_shutdown(now()).unwrap());
        work.resource_destroyed()
    });
    assert_eq!(native.destructions.load(Ordering::Acquire), 1);
    assert!(!work.ready());
    for server in servers.lock().unwrap().drain(..) {
        assert_eq!(server.join().unwrap(), 0);
    }
}

#[test]
fn cancellation_after_acquisition_does_not_fake_revocation_or_start_on_late_ack() {
    if child("cancellation_after_acquisition_does_not_fake_revocation_or_start_on_late_ack") {
        return;
    }
    stopped_before_start(false);
}

#[test]
fn expired_lease_is_checked_before_raced_running_acknowledgement() {
    if child("expired_lease_is_checked_before_raced_running_acknowledgement") {
        return;
    }
    stopped_before_start(true);
}

#[test]
fn refused_scoped_worker_persists_failed_closed_after_running_ack() {
    if child("refused_scoped_worker_persists_failed_closed_after_running_ack") {
        return;
    }
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    // Hold the real process worker permit. No native port is bound and this
    // unrelated suspended worker is never allowed to run a controller.
    let occupied = PendingAgentRuntime::spawn_suspended(AgentRuntimeConfig::STANDARD).unwrap();
    let directory = tempfile::tempdir().unwrap();
    let (mut work, native, _) = coordinator(directory.path());
    let servers = Servers::default();
    poll_until(&mut work, |work| work.ready());
    assert!(work
        .submit(
            request(ContextRunId::generate(), vec![], servers.clone()),
            now()
        )
        .is_ok());
    poll_until(&mut work, |work| {
        work.record()
            .is_some_and(|record| record.disposition() == AgentWorkDisposition::FailedClosed)
    });
    assert_eq!(native.reads.load(Ordering::Acquire), 0);
    assert_eq!(native.acquisitions.load(Ordering::Acquire), 1);
    assert!(!work.ready());
    work.begin_shutdown();
    wait_until(|| {
        assert!(!work.poll_shutdown(now()).unwrap());
        work.resource_destroyed()
    });
    assert_ne!(work.record().unwrap().debt(), AgentWorkDebt::NONE);
    drop(occupied);
    for server in servers.lock().unwrap().drain(..) {
        assert_eq!(server.join().unwrap(), 0);
    }
}

/// Another page of the same Store, as the Shell seats one in a page group.
fn peer_coordinator(store: &Arc<GatedStore>) -> (RetainedWork, Arc<Native>) {
    let (owner, native, resource) = construct_fixture(
        ContextProfileStorageClass::Ephemeral,
        WorkBrowserDocumentPolicy::Exact,
        None,
    );
    native.allow_global_shutdown.store(true, Ordering::Release);
    let work = RetainedWork::new(owner, resource, store.clone(), store.clone())
        .unwrap_or_else(|_| panic!("original owner and Store join"));
    (work, native)
}

/// Admits the group's first page, then fails it before its actor starts:
/// its Running row is committed but unacknowledged, so the group fails.
fn fail_first_member(
    first: &mut RetainedWork,
    store: &GatedStore,
    group: &RetainedWorkGroup,
    servers: &Servers,
) {
    poll_until(first, RetainedWork::ready);
    store
        .hold
        .store(AgentWorkDisposition::Running as u8, Ordering::Release);
    assert!(first
        .submit(
            request(ContextRunId::generate(), vec![], servers.clone()),
            now()
        )
        .is_ok());
    poll_until(first, |_| store.pending.lock().unwrap().is_some());
    assert!(!group.is_failed());
    first.cancel();
    assert!(group.is_failed());
}

/// A grouped page that settled takes the group's native audit turn and
/// finishes it, so the Shell can free its seat and close the group.
fn audit_grouped(work: &mut RetainedWork, clean: bool) {
    work.begin_shutdown();
    wait_until(|| {
        assert!(!work.poll_shutdown(now()).unwrap());
        work.resource_destroyed()
    });
    assert!(
        work.awaits_group_audit(),
        "a settled page asks for its turn"
    );
    work.allow_group_shutdown();
    wait_until(|| match work.poll_shutdown(now()) {
        Ok(closed) => closed,
        Err(_) => !clean,
    });
    assert!(work.native_audit_settled());
    assert_eq!(work.locally_closed(), clean);
}

#[test]
fn failed_group_refuses_a_later_claim_and_both_pages_still_end() {
    if child("failed_group_refuses_a_later_claim_and_both_pages_still_end") {
        return;
    }
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let directory = tempfile::tempdir().unwrap();
    let (mut first, first_native, store) = coordinator(directory.path());
    let servers = Servers::default();
    let group = RetainedWorkGroup::try_new(WorkId::generate(), 3).unwrap();
    first.set_runtime_group(group.clone());
    fail_first_member(&mut first, &store, &group, &servers);

    // The next page claims while the failed peer's row is still Running.
    let (mut second, second_native) = peer_coordinator(&store);
    second.set_runtime_group(group.clone());
    poll_until(&mut second, |work| {
        work.phase() == AdmissionPhase::Uncertain
    });
    assert_eq!(
        second.failures(),
        (Some(AgentWorkFailure::Contract), None),
        "a settled claim the page may not run beside is a refusal, not an unsettled write"
    );
    assert!(second.record().is_none());
    assert!(!second.reconcile(), "no Store request is left to reconcile");
    assert_eq!(second_native.acquisitions.load(Ordering::Acquire), 0);
    audit_grouped(&mut second, true);
    assert!(second_native.global_sealed.load(Ordering::Acquire));

    // The failed page classifies its never-started actor and ends unclean.
    store.release(0);
    poll_until(&mut first, |work| {
        work.record()
            .is_some_and(|record| record.disposition() == AgentWorkDisposition::FailedClosed)
    });
    assert_eq!(first_native.reads.load(Ordering::Acquire), 0);
    audit_grouped(&mut first, false);
    assert_ne!(first.record().unwrap().debt(), AgentWorkDebt::NONE);
    assert!(first_native.global_sealed.load(Ordering::Acquire));
    for server in servers.lock().unwrap().drain(..) {
        assert_eq!(server.join().unwrap(), 0);
    }
}

#[test]
fn failed_group_refuses_a_staged_peer_and_releases_its_unadmitted_actor() {
    if child("failed_group_refuses_a_staged_peer_and_releases_its_unadmitted_actor") {
        return;
    }
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let directory = tempfile::tempdir().unwrap();
    let (mut first, _, store) = coordinator(directory.path());
    let servers = Servers::default();
    let group = RetainedWorkGroup::try_new(WorkId::generate(), 3).unwrap();
    first.set_runtime_group(group.clone());
    let (mut second, second_native) = peer_coordinator(&store);
    second.set_runtime_group(group.clone());
    poll_until(&mut second, RetainedWork::ready);
    fail_first_member(&mut first, &store, &group, &servers);

    // Its actor is staged on an acquired lease, then the failed group
    // refuses its admission: the journal never hears of it.
    assert!(second
        .submit(
            request(ContextRunId::generate(), vec![], servers.clone()),
            now()
        )
        .is_ok());
    poll_until(&mut second, |work| {
        work.phase() == AdmissionPhase::Uncertain
    });
    assert_eq!(second.failures(), (Some(AgentWorkFailure::Contract), None));
    assert!(second.record().is_none());
    assert_eq!(second_native.acquisitions.load(Ordering::Acquire), 1);
    assert_eq!(second_native.reads.load(Ordering::Acquire), 0);
    audit_grouped(&mut second, true);
    assert_eq!(second_native.destructions.load(Ordering::Acquire), 1);
    assert!(second_native.global_sealed.load(Ordering::Acquire));

    store.release(0);
    poll_until(&mut first, |work| {
        work.record()
            .is_some_and(|record| record.disposition() == AgentWorkDisposition::FailedClosed)
    });
    audit_grouped(&mut first, false);
    for server in servers.lock().unwrap().drain(..) {
        assert_eq!(server.join().unwrap(), 0);
    }
}

#[test]
fn pre_dispatch_failure_releases_unused_budget_only_after_exact_terminal_ack() {
    if child("pre_dispatch_failure_releases_unused_budget_only_after_exact_terminal_ack") {
        return;
    }
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|e| e.into_inner());
    let directory = tempfile::tempdir().unwrap();
    let (mut work, _native, store) = coordinator(directory.path());
    let servers = Servers::default();
    let completed_servers = servers.clone();
    poll_until(&mut work, RetainedWork::ready);
    store
        .hold
        .store(AgentWorkDisposition::Failed as u8, Ordering::Release);
    let request = ActorRequest {
        run: ContextRunId::generate(),
        deadline: AgentPolicyInstant::from_millis(600_002),
        prepare: Box::new(move |browser, audit, waiting| {
            if waiting.is_some() {
                return Err(AgentWorkFailure::Contract);
            }
            let input = input_with_budget(
                browser.binding(),
                Arc::new(Clock(AtomicU64::new(2))),
                browser.binding().storage(),
                browser.binding().document().clone(),
                AgentRunBudget::try_new(8, 100_000, 50_000, 1).unwrap(),
            );
            let (transport, server) = fixture_provider_responses(Vec::new());
            servers.lock().unwrap().push(server);
            StagedActor::for_probe(
                input,
                browser,
                transport,
                AgentProviderCredential::try_new(
                    AgentProviderKind::OpenAiResponses,
                    "fixture-not-a-secret".into(),
                )
                .unwrap(),
                audit,
                Box::new(task()),
            )
        }),
    };
    assert!(work.submit(request, now()).is_ok());
    poll_until(&mut work, |_| store.pending.lock().unwrap().is_some());
    assert!(work.usage().is_none());
    store.release(0);
    poll_until(&mut work, |work| work.phase() == AdmissionPhase::Terminal);
    assert_eq!(
        work.record().unwrap().disposition(),
        AgentWorkDisposition::Failed
    );
    let usage = work.usage().expect("original failed terminal ledger");
    assert_eq!(usage.model_tokens, 0);
    assert_eq!(usage.cost_micro_usd, 0);
    assert!(usage.operations < 8);
    assert_eq!(
        usage.accounting,
        zephium_core::work::runtime::WorkUsageAccounting::Exact
    );
    assert!(work.shutdown_until(
        &Clock(AtomicU64::new(2)),
        Instant::now() + Duration::from_secs(2)
    ));
    assert_eq!(work.usage(), Some(usage));
    for server in completed_servers.lock().unwrap().drain(..) {
        assert_eq!(server.join().unwrap(), 0);
    }
}

#[test]
fn human_handoff_waits_for_terminal_ack() {
    if child("human_handoff_waits_for_terminal_ack") {
        return;
    }
    human_handoff_contract(false);
}
#[test]
fn human_handoff_drains_cancelled_presentation() {
    if child("human_handoff_drains_cancelled_presentation") {
        return;
    }
    human_handoff_contract(true);
}
fn human_handoff_contract(cancel: bool) {
    let _serial = crate::WORK_RUNTIME_TEST_SERIAL
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    {
        let directory = tempfile::tempdir().unwrap();
        let (mut work, native, store) = coordinator(directory.path());
        wait_until(|| {
            work.poll(now());
            drain_events(&mut work);
            work.ready()
        });
        store.hold.store(
            AgentWorkDisposition::WaitingForHuman as u8,
            Ordering::Release,
        );
        let (sender, receiver) = mpsc::sync_channel(1);
        let actor = ActorRequest {
            run: ContextRunId::generate(),
            deadline: AgentPolicyInstant::from_millis(600_002),
            prepare: Box::new(move |browser, audit, waiting| {
                assert!(waiting.is_none());
                let input = input(browser.binding(), Arc::new(Clock(AtomicU64::new(2))));
                let response = response_stream(1)
                    .replace("\"name\":\"extract\"", "\"name\":\"show_for_human\"")
                    .replace(
                        r#"{\"scope\":{\"kind\":\"initial\"},\"schema_id\":1}"#,
                        r#"{\"reason\":\"sign_in\"}"#,
                    );
                let (transport, server) = fixture_provider_responses(vec![response]);
                sender.send(server).unwrap();
                StagedActor::for_probe(
                    input,
                    browser,
                    transport,
                    AgentProviderCredential::try_new(
                        AgentProviderKind::OpenAiResponses,
                        "fixture-not-a-secret".into(),
                    )
                    .unwrap(),
                    audit,
                    Box::new(HumanRequestTask(task())),
                )
            }),
        };
        assert!(work.submit(actor, now()).is_ok());
        wait_until(|| {
            work.poll(now());
            drain_events(&mut work);
            assert!(
                work.failures() == (None, None),
                "fixture failure: {:?} {:?}",
                work.phase(),
                work.failures()
            );
            store.pending.lock().unwrap().is_some()
        });
        let deadline = Instant::now() + Duration::from_secs(120);
        work.start_human_wait(deadline, now());
        assert!(
            work.human_snapshot().is_none(),
            "unacknowledged durable handoff is not presentation authority"
        );
        store.release(0);
        wait_until(|| {
            work.poll(now());
            drain_events(&mut work);
            work.ready()
        });
        work.start_human_wait(deadline, now());
        let human = work.human_snapshot().unwrap();
        assert_eq!(human.phase, RetainedHumanPhase::WaitingForHuman);
        assert_eq!(human.deadline, deadline);
        assert!(!work.ready());
        assert!(
            work.human_check_progress().is_none(),
            "unpresented pages cannot be checked"
        );
        let region = WorkBrowserHumanRegion::try_new(0, 0, 800, 600).unwrap();
        assert!(!work.present_human(human.generation + 1, Some(region), now()));
        native.hold_human.store(true, Ordering::Release);
        assert!(work.present_human(human.generation, Some(region), now()));
        assert!(!work.continue_human(human.generation, now()));
        if cancel {
            work.begin_shutdown();
        }
        let (request, callback) = native.human.lock().unwrap().take().unwrap();
        let human_progress = request.human_progress().unwrap();
        finish_human_fixture(request, callback);
        work.poll(now());
        assert_eq!(
            work.human_snapshot().unwrap().phase,
            if cancel {
                RetainedHumanPhase::Released
            } else {
                RetainedHumanPhase::Presented
            }
        );
        if cancel {
            assert!(
                work.human_check_progress().is_none(),
                "Stop revokes explicit checks"
            );
        }
        if !cancel {
            let check = work
                .human_check_progress()
                .unwrap()
                .request_wall_check()
                .unwrap();
            assert_eq!(
                check.state(human_progress.revision()),
                zephium_agentic::WorkBrowserHumanCheckState::Pending
            );
            assert_eq!(
                work.human_snapshot().unwrap().deadline,
                deadline,
                "checking cannot renew human time"
            );
            assert!(
                !work.human_snapshot().unwrap().can_continue,
                "navigation readiness alone cannot clear sign-in"
            );
            assert!(!work.continue_human(human.generation, now()));
            check.finish(Some(false));
            assert_eq!(
                check.state(human_progress.revision()),
                zephium_agentic::WorkBrowserHumanCheckState::Waiting
            );
            assert!(
                !work.human_snapshot().unwrap().can_continue,
                "an explicit check cannot manufacture proof"
            );
            human_progress.record_verified_wall_clear(true);
            assert!(work.human_snapshot().unwrap().can_continue);
            assert_eq!(native.acquisitions.load(Ordering::Acquire), 1);
            native.hold_human.store(false, Ordering::Release);
            assert!(work.continue_human(human.generation, now()));
            human_progress.record_verified_wall_clear(false);
            work.poll(now());
            assert!(work.ready());
            let resumed = work.human_resume().unwrap();
            assert_eq!(resumed.model_calls, 1);
            assert_eq!(resumed.actions, 0);
            assert!(resumed.verified_wall_clear, "successful native handback retains proof captured at Continue, not an expiring live flag");
            assert!(
                !work.continue_human(human.generation, now()),
                "continuation is consumed once"
            );
        }
        assert_eq!(
            receiver
                .recv_timeout(Duration::from_secs(2))
                .unwrap()
                .join()
                .unwrap(),
            1
        );
        native.join();
        if !cancel {
            let servers: Servers = Arc::new(Mutex::new(Vec::new()));
            let recorders = servers.clone();
            let successor = ActorRequest {
                run: ContextRunId::generate(),
                deadline: AgentPolicyInstant::from_millis(600_002),
                prepare: Box::new(move |browser, audit, waiting| {
                    assert!(waiting.is_some());
                    let input = input(browser.binding(), Arc::new(Clock(AtomicU64::new(2))));
                    let (transport, server) =
                        fixture_provider_responses(vec![response_stream(1), response_stream(2)]);
                    recorders.lock().unwrap().push(server);
                    StagedActor::for_probe_human(
                        input,
                        browser,
                        transport,
                        AgentProviderCredential::try_new(
                            AgentProviderKind::OpenAiResponses,
                            "fixture-not-a-secret".into(),
                        )
                        .unwrap(),
                        audit,
                        Box::new(task()),
                        waiting,
                    )
                }),
            };
            assert!(work.submit(successor, now()).is_ok());
            wait_until(|| {
                work.poll(now());
                drain_events(&mut work);
                work.phase() == AdmissionPhase::Terminal
            });
            assert_eq!(
                work.record().unwrap().disposition(),
                AgentWorkDisposition::Succeeded
            );
            assert!(work.take_extraction().is_some());
            assert!(work.human_snapshot().is_none());
            assert_eq!(native.acquisitions.load(Ordering::Acquire), 2);
            assert_eq!(native.reads.load(Ordering::Acquire), 2);
            for server in servers.lock().unwrap().drain(..) {
                assert_eq!(server.join().unwrap(), 2);
            }
            native.join();
        }
        assert!(work.shutdown_until(
            &Clock(AtomicU64::new(2)),
            Instant::now() + Duration::from_secs(2)
        ));
        assert_eq!(native.destructions.load(Ordering::Acquire), 1);
    }
}

#[test]
fn clean_history_never_fills_admission_and_full_recovery_history_says_so() {
    let prior = AgentWorkIncarnation::generate();
    let current = AgentWorkIncarnation::generate();
    let row = |key: u16, disposition: AgentWorkDisposition, debt: AgentWorkDebt| {
        let mut bytes = [0; AGENT_WORK_RECORD_BYTES];
        bytes[0] = 1;
        bytes[1] = disposition as u8;
        bytes[2] = debt.bits();
        bytes[15] = 3;
        bytes[16..32].copy_from_slice(&prior.bytes());
        bytes[46..48].copy_from_slice(&key.to_be_bytes());
        AgentWorkRecord::decode(bytes).unwrap()
    };
    let clean = (0..zephium_agentic::MAX_AGENT_WORK_INVENTORY as u16)
        .map(|key| row(key, AgentWorkDisposition::Failed, AgentWorkDebt::NONE))
        .collect();
    let (work, _, _) = review_coordinator(clean, current);
    assert!(work.ready());
    assert_eq!(work.failures().1, None);

    let debt = (0..MAX_DURABLE_AGENT_WORK_RUNS as u16)
        .map(|key| row(key, AgentWorkDisposition::Rejected, AgentWorkDebt::UNKNOWN))
        .collect();
    let (work, native, _) = review_coordinator(debt, current);
    assert!(!work.ready());
    assert_eq!(work.failures().1, Some(AgentWorkJournalError::Capacity));
    assert_eq!(native.acquisitions.load(Ordering::Acquire), 0);
}
